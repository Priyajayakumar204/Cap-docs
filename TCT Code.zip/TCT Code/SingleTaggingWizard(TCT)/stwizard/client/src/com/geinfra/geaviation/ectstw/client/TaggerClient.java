/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class TaggerClient {
	public static void main(String[] args) throws Exception {
		//URL url = new URL("http://webopsportal.tsg.ge.com/portal/auth/portal/main/webops-ApplicationReport/webops-ApplicationReportPortletWindow?action=e&windowstate=normal&javax.faces.portletbridge.STATE_ID=261742a2-f7f8-42a0-a5e0-33e3f86cb842%3Aview%3Ad6fe9b98-e831-477c-86a5-66521e423571&mode=view");
		URL url = new URL("http://localhost/ect-stw/service/ect-stw/classify");
		HttpURLConnection  con = (HttpURLConnection ) url.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setInstanceFollowRedirects(false);
		con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		con.setRequestProperty("Accept", "text/plain; q=0.5, text/html");		
		OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
		wr.write("client_type=Browser&appId=DRB&appType=Study&objectData=Demo-50.A$$Drawing0");
		wr.flush();
		BufferedReader rd = new BufferedReader(new InputStreamReader(con.getInputStream()));
		System.out.println("URL:" + con.getHeaderFields());		
		String line;
		StringBuilder resStr = new StringBuilder();
		while ((line = rd.readLine()) != null) {
			resStr.append(line + "\n");
			System.out.println(line);
		}		
		rd.close();
		wr.close();
		
		int startPos = resStr.indexOf("http://");
		String appUrl = resStr.substring(startPos, resStr.indexOf("\"", startPos));
		System.out.println("appUrl: " + appUrl);
		
		Process p = Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler " + appUrl);
    	p.waitFor();
    	System.out.println("Done.");		
	}
}
