function showMsg(msg){
	alert(msg);
}

function showImage(id, flag){
	var comp = document.getElementById(id);
	//alert('showImage called...');
	if(comp != null){
		if(flag){
			comp.style.visibility = 'visible';
			comp.style.display = 'inline';
			
			//alert('shown...');
		} else {
			comp.style.visibility = 'hidden';
			comp.style.display = 'none';
			
			//alert('hidden...');
		}
	}	
}

function disableComp(objArr, flag){
	for(var i in objArr) {
		var comp = document.getElementById(objArr[i]);
		comp.disabled = flag;
	}
}


//To move selected items from one list to another
function moveSelItems(fromList, toList){
    var fromVarList = document.getElementById(fromList);
        var toVarList = document.getElementById(toList);
            
        
        
    
    var items = new Array();
        for(i = 0; i < fromVarList.length; i++){    	
            	if(fromVarList.options.item(i).selected){
            	items[items.length] = fromVarList.item(i);
            	}
        }    
        
        for(j = 0; j < items.length; j++){    	
            addToList(items[j], toVarList);        
    }
    
    fromVarList.selectedIndex = -1;
    toVarList.selectedIndex = -1;
}

//To move all items from one list to another
function moveAllItems(fromList, toList){	
    var fromVarList = document.getElementById(fromList);
    var toVarList = document.getElementById(toList);
   
   var items = new Array();
    for(i = 0; i < fromVarList.length; i++){    	
        	items[items.length] = fromVarList.item(i);
    }    
    
    for(j = 0; j < items.length; j++){    	
        addToList(items[j], toVarList);        
    }
    
    fromVarList.selectedIndex = -1;
    toVarList.selectedIndex = -1;
}

//To add an item to a list in ascending order
function addToList(item, List){
  	var len = List.length;
  	
  	if(len == 0){
			//alert('empty');
			List.appendChild(item);	
			return true;
  	}
  	
  	for(i = 0; i < len; i++){    	
	    	if(List.options.item(i).value > item.value){
	        	break;
	        }
    }
    
    if(i < len){
    		//alert('mid');
    		//alert(List.item(i).nodeName);
    		List.insertBefore(item, List.item(i));	    		
  	} else {
  		//alert('last');
  		List.appendChild(item);	
  	}
  	  	
}

function openURL(url)
{
    myWindow = window.open(url);
}