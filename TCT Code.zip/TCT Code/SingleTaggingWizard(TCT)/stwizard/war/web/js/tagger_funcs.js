function setDNEAction()
{
    	frm = getDocForm();
    	if (frm.chkDNE.checked == true)
    	{
        document.getElementById('reasonDNE').disabled = false;
        
        frm.honda[0].checked = false;
        frm.honda[1].checked = false;

        frm.rdIden[0].checked = false;
        frm.rdIden[1].checked = false;

        frm.coMingle[0].checked = false;
        frm.coMingle[1].checked = false;

        frm.reviewSpec[0].checked = false;
        frm.reviewSpec[1].checked = false;

        frm.rdITAR[0].checked = false;
        frm.rdITAR[1].checked = false;

        getComp('selectITAR').disabled = true;
        getComp('selectITAR').selectedIndex = 0;

        frm.rdEAR[0].checked = false;
        frm.rdEAR[1].checked = false;

		
        getComp('selectEAR').disabled = true;
        getComp('selectEAR').selectedIndex = 0;
        frm.SubToReg.checked = false;


        getComp('ListUSML1').disabled = true;
        frm.ListUSML2.disabled = true;
        getComp('USMLFilter').disabled = true;
        getComp('USMLFilter').selectedIndex = 0;

        getComp('ListECCN1').disabled = true;
        frm.ListECCN2.disabled = true;
        getComp('ECCNFilter').disabled = true;
        getComp('ECCNFilter').selectedIndex = 0;

        moveAllItems('ListECCN2', getCompId('ListECCN1'));
        moveAllItems('ListUSML2', getCompId('ListUSML1'));

        HondaAero.disabled = 'disabled';
        IdenJur.disabled = 'disabled';
        IdenYesNo.disabled = 'disabled';
        Specs.disabled = 'disabled';
        ITAR.disabled = 'disabled';
        ReasonITAR.disabled = 'disabled';
        usmlCat.disabled = 'disabled';
        usmlFilt.disabled = 'disabled';
        EAR.disabled = 'disabled';
        ReasonEAR.disabled = 'disabled';
        EccnCat.disabled = 'disabled';
        EccnFilt.disabled = 'disabled';
    }
    else  // DNE not checked
    {
        reasonDNE.disabled = 'disabled';
      	reasonDNE.selectedIndex = 0;
        reasonDNE.disabled = true;

        frm.aviation[0].checked = false;
        frm.aviation[1].checked = false;
    }
}

function setAvCtrlAction()
{
	frm = getDocForm(); 
    if ( (frm.aviation[0].checked == true) || (frm.aviation[1].checked == true) )
    {
        if ( frm.chkDNE.checked == false )
        {
            HondaAero.disabled = '';
        }
    }
}

function setHondaAction()
{
    frm = getDocForm();
    IdenJur.disabled = '';
    if (frm.honda[0].checked)  // Yes checked
    {
        frm.rdIden[0].disabled = true;

        // Objects below honda should be disabled if previouly chosen
            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;

            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            frm.rdEAR[0].checked = false;
            frm.rdEAR[1].checked = false;
            getComp('selectEAR')[0].selected = true;
            getComp('selectEAR').disabled = true;
            frm.SubToReg.checked = false;

            moveAllItems('ListUSML2', getCompId('ListUSML1'));
            usmlCat.disabled = 'disabled';
            usmlFilt.disabled = 'disabled';
            getComp('ListUSML1').disabled = true;
            frm.ListUSML2.disabled = true;
            getComp('USMLFilter').disabled = true;
            getComp('USMLFilter').selectedIndex = 0;

            ITAR.disabled = 'disabled';
            frm.rdITAR[0].checked = false;
            frm.rdITAR[1].checked = false;
            ReasonITAR.disabled = 'disabled';
            getComp('selectITAR')[0].selected = true;
            getComp('selectITAR').disabled = true;

            frm.reviewSpec[0].checked = false;
            frm.reviewSpec[1].checked = false;
            Specs.disabled = 'disabled';

            frm.coMingle[0].checked = false;
            frm.coMingle[1].checked = false;
            IdenYesNo.disabled = 'disabled';

            frm.rdIden[0].checked = false;
            frm.rdIden[1].checked = false;
    }
    else // No checked
    {
        frm.rdIden[0].disabled = false;
        frm.rdIden[1].disabled = false;

        // Objects below honda should be disabled if previouly chosen
            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;

            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            frm.rdEAR[0].checked = false;
            frm.rdEAR[1].checked = false;
            getComp('selectEAR')[0].selected = true;
            getComp('selectEAR').disabled = true;
            frm.SubToReg.checked = false;

            frm.reviewSpec[0].checked = false;
            frm.reviewSpec[1].checked = false;
            Specs.disabled = 'disabled';

            frm.rdIden[0].checked = false;
            frm.rdIden[1].checked = false;
    }
}

function setIdenAction()
{
	frm = getDocForm();
    if (frm.rdIden[0].checked)  // State Department checked
    {
        IdenYesNo.disabled = '';

        // Objects below rdIden should be disabled if previouly chosen
            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;

            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            frm.rdEAR[0].checked = false;
            frm.rdEAR[1].checked = false;
            getComp('selectEAR')[0].selected = true;
            getComp('selectEAR').disabled = true;
            frm.SubToReg.checked = false;

            frm.reviewSpec[0].checked = false;
            frm.reviewSpec[1].checked = false;
            Specs.disabled = 'disabled';
    }

    if (frm.rdIden[1].checked)  // Commerce Department
    {
        IdenYesNo.disabled = 'disabled';

        // Objects below rdIden should be disabled if previouly chosen
            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;

            frm.rdEAR[0].checked = false;
            frm.rdEAR[1].checked = false;
            getComp('selectEAR')[0].selected = true;
            getComp('selectEAR').disabled = true;
            frm.SubToReg.checked = false;

            moveAllItems('ListUSML2', getCompId('ListUSML1'));
            usmlCat.disabled = 'disabled';
            usmlFilt.disabled = 'disabled';
            getComp('ListUSML1').disabled = true;
            frm.ListUSML2.disabled = true;
            getComp('USMLFilter').disabled = true;
            getComp('USMLFilter').selectedIndex = 0;

            ITAR.disabled = 'disabled';
            frm.rdITAR[0].checked = false;
            frm.rdITAR[1].checked = false;
            ReasonITAR.disabled = 'disabled';
            getComp('selectITAR')[0].selected = true;
            getComp('selectITAR').disabled = true;

            frm.reviewSpec[0].checked = false;
            frm.reviewSpec[1].checked = false;
            Specs.disabled = '';

            frm.coMingle[0].checked = false;
            frm.coMingle[1].checked = false;
    }
}

function setYesNoAction()
{
    frm = getDocForm();
    Specs.disabled = '';

    if (frm.coMingle[1].checked)  // No is checked
    {
        // Objects below coMingle should be disabled if previouly chosen
            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;

            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            frm.rdEAR[0].checked = false;
            frm.rdEAR[1].checked = false;
            getComp('selectEAR')[0].selected = true;
            getComp('selectEAR').disabled = true;
            frm.SubToReg.checked = false;
    }
    else  // Yes is checked
    {
        if ( frm.reviewSpec[0].checked || frm.reviewSpec[1].checked)
        {
            EAR.disabled = '';
        }
    }
}

function setSpecReview()
{
    frm = getDocForm();
    if (frm.rdIden[0].checked)  // State checked
    {
        ITAR.disabled = '';

        if ( frm.coMingle[0].checked)
        {
            EAR.disabled = '';
        }
    }
    else  // Commerce checked
    {
        EAR.disabled = '';
    }
}

function setITARAction()
{
	frm = getDocForm();
    if (frm.rdITAR[0].checked)  // Yes checked
    {
        ReasonITAR.disabled = 'disabled';
        getComp('selectITAR')[0].selected = true;
        getComp('selectITAR').disabled = true;

        usmlCat.disabled = '';
        usmlFilt.disabled = '';
        getComp('USMLFilter').disabled = false;
        getComp('ListUSML1').disabled = false;
        frm.ListUSML2.disabled = false;

        if (frm.coMingle[1].checked)  // No for Co-mingle checked
        {
            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            getComp('selectEAR').disabled = true;

            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
        }
        else  // Yes for Co-mingled checked
        {
            EAR.disabled = '';
        }

    }
    if (frm.rdITAR[1].checked)  // No checked
    {
        getComp('selectITAR').disabled = false;
        ReasonITAR.disabled = '';

        moveAllItems('ListUSML2', getCompId('ListUSML1'));
        getComp('ListUSML1').disabled = true;
        frm.ListUSML2.disabled = true;
        getComp('USMLFilter').disabled = true;
        getComp('USMLFilter').selectedIndex = 0;
        usmlCat.disabled = 'disabled';
        usmlFilt.disabled = 'disabled';

        if (frm.coMingle[1].checked)  // No for Co-mingle checked
        {
            EAR.disabled = 'disabled';
            ReasonEAR.disabled = 'disabled';
            getComp('selectEAR').disabled = true;

            moveAllItems('ListECCN2', getCompId('ListECCN1'));
            EccnCat.disabled = 'disabled';
            EccnFilt.disabled = 'disabled';
            getComp('ECCNFilter').disabled = true;
            getComp('ECCNFilter').selectedIndex = 0;
            getComp('ListECCN1').disabled = true;
            frm.ListECCN2.disabled = true;
        }
        else  // Yes for Co-mingled checked
        {
            EAR.disabled = '';
        }
    }
}
