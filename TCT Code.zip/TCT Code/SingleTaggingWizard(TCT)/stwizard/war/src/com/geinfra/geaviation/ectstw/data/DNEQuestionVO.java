/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

public class DNEQuestionVO extends BaseSTWVO {
	private boolean selected = false;
	private boolean reasonEnabled = false;

	private String selDNEReason = null;
	
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public boolean isReasonEnabled() {
		return reasonEnabled;
	}

	public void setReasonEnabled(boolean reasonEnabled) {
		this.reasonEnabled = reasonEnabled;
	}
	
	public String getSelDNEReason() {
		return selDNEReason;
	}

	public void setSelDNEReason(String selDNEReason) {
		this.selDNEReason = selDNEReason;
	}
}
