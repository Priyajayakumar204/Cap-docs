/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.EARQuestionDao;

public class EARQuestionService extends BaseSTWService {
	private EARQuestionDao earQuestionDao = null;

	public EARQuestionDao getEarQuestionDao() {
		return earQuestionDao;
	}

	public void setEarQuestionDao(EARQuestionDao earQuestionDao) {
		this.earQuestionDao = earQuestionDao;
	}
	
	public Map validate(Map compStatusMap){
		return getTagRulesService().validateEARQues(compStatusMap);
	}
	
	public List<String> getEARReasons() throws Exception {
		return earQuestionDao.getEARReasons();		
	}
	
	public List<String> getECCNCatagoriesSub() throws Exception {
		return earQuestionDao.getECCNCatagoriesSub();
	}	
}
