/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import java.util.List;

public class ExportObject {
	private String appId;
	private String appType;
	private String objectID;
	private String description;
	private String expStatus;
	private List classificationList;
	private String reasonForClassification;

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getAppType() {
		return appType;
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getExpStatus() {
		return expStatus;
	}

	public void setExpStatus(String expStatus) {
		this.expStatus = expStatus;
	}

	public List getClassificationList() {
		return classificationList;
	}

	public void setClassificationList(List classificationList) {
		this.classificationList = classificationList;
	}

	public String getReasonForClassification() {
		return reasonForClassification;
	}

	public void setReasonForClassification(String reasonForClassification) {
		this.reasonForClassification = reasonForClassification;
	}

}
