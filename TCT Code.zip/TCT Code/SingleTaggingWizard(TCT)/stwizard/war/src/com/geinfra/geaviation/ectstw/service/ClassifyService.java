/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

public class ClassifyService extends BaseSTWService {
	private ExportControlService exportControlService;

	public ExportControlService getExportControlService() {
		return exportControlService;
	}

	public void setExportControlService(ExportControlService exportControlService) {
		this.exportControlService = exportControlService;
	}
}
