/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import java.util.Map;

import com.geinfra.geaviation.ectstw.data.CtrlTechQuestionVO;
import com.geinfra.geaviation.ectstw.service.CtrlTechQuestionService;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class CtrlTechQuestionBean extends AbstractQuestionBean {
	private CtrlTechQuestionVO ctrlTechQuestionVO = null;
	private CtrlTechQuestionService ctrlTechQuestionService = null;
	
	public CtrlTechQuestionVO getCtrlTechQuestionVO() {
		return ctrlTechQuestionVO;
	}
	public void setCtrlTechQuestionVO(CtrlTechQuestionVO ctrlTechQuestionVO) {
		this.ctrlTechQuestionVO = ctrlTechQuestionVO;
	}
	public CtrlTechQuestionService getCtrlTechQuestionService() {
		return ctrlTechQuestionService;
	}
	public void setCtrlTechQuestionService(CtrlTechQuestionService ctrlTechQuestionService) {
		this.ctrlTechQuestionService = ctrlTechQuestionService;
	}
	
	public Map getComponentStatusMap(Map compStatusMap){
		return ctrlTechQuestionService.validate(compStatusMap);
	}
}
