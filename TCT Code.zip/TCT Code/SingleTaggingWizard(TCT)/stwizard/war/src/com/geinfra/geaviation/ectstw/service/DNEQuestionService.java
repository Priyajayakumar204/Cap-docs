/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.DNEQuestionDao;

public class DNEQuestionService extends BaseSTWService {
	private DNEQuestionDao dneQuestionDao = null;
	
	public DNEQuestionDao getDneQuestionDao() {
		return dneQuestionDao;
	}

	public void setDneQuestionDao(DNEQuestionDao dneQuestionDao) {
		this.dneQuestionDao = dneQuestionDao;
	}

	public List<String> getDNEReasons() throws Exception {
		return dneQuestionDao.getDNEReasons();
	}
	
	public Map validate(Map compStatusMap){
		return getTagRulesService().validateDNEQuestion(compStatusMap);
	}
}
