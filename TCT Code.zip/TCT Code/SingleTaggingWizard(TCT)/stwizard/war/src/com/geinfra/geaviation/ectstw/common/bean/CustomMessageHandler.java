/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common.bean;

import java.util.ArrayList;
import java.util.List;

import com.ge.portal.faces.model.ErrorMessageInfo;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class CustomMessageHandler {
	private List<ErrorMessageInfo> errorMessages;

	public CustomMessageHandler() {
		
		errorMessages = new ArrayList<ErrorMessageInfo>();
	}

	public void addError(Exception exp, String userMessage) {
		

		String userErrorMessage = userMessage;

		if (userErrorMessage == null || userErrorMessage.equals("")) {
			userErrorMessage = TaggingWizardConstants.ERROR_COM_01;
		}

		errorMessages.add(new ErrorMessageInfo(userErrorMessage));
	}

	public void addMessage(String userMessage) {
		
		if (userMessage != null && userMessage.length() != 0) {
			errorMessages.add(new ErrorMessageInfo(userMessage));
		}
	}

	public List<ErrorMessageInfo> getErrorMessages() {
		List<ErrorMessageInfo> tempList = errorMessages;
		errorMessages = new ArrayList();
		return tempList;
	}

	public void setErrorMessages(List<ErrorMessageInfo> errorMessages) {
		this.errorMessages = errorMessages;
	}
}
