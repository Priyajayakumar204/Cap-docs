/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils.xml;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.data.ExportableObject;
import com.geinfra.geaviation.ectstw.webservice.ECTTagWebService;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class XMLStreamDataHandler implements XMLDataHandler {
	private static Logger logger = Logger.getLogger(XMLStreamDataHandler.class);
	public List<ExportableObject> readXMLData(String xml) {
		String qName;
		ExportableObject tempExpObj = null;
		List<ExportableObject> expObjList = new ArrayList<ExportableObject>();

		StringReader strReader = new StringReader(xml);

		try {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			XMLStreamReader reader = factory.createXMLStreamReader(strReader);

			while (reader.hasNext()) {
				int eventType = reader.next();
				switch (eventType) {
				case XMLStreamConstants.START_ELEMENT:
					qName = reader.getLocalName();
					if (qName.equalsIgnoreCase("ExportableObject")) {
						//create a new instance of ExportableObject
						tempExpObj = new ExportableObject();
					} else if (qName.equalsIgnoreCase("ObjectName")) {
						tempExpObj.setObjName(reader.getElementText());
					} else if (qName.equalsIgnoreCase("ObjectType")) {
						tempExpObj.setObjType(reader.getElementText());
					} else if (qName.equalsIgnoreCase("classification")) {
						tempExpObj.setClassification(reader.getElementText());
					} else if (qName.equalsIgnoreCase("exportStatus")) {
						tempExpObj.setExportStatus(reader.getElementText());
					} else if (qName.equalsIgnoreCase("rational")) {
						tempExpObj.setRational(reader.getElementText());
					}
					break;
				case XMLStreamConstants.END_ELEMENT:
					qName = reader.getLocalName();
					if (qName.equalsIgnoreCase("ExportableObject")) {
						//add it to the list
						expObjList.add(tempExpObj);
					}
					break;
				default:
					logger.info("default case.");
				}
			}

		} catch (XMLStreamException exp) {
			logger.error("Exception: " + exp.getMessage());
			throw new RuntimeException(exp);
		}

		return expObjList;
	}

	public String writeXMLData(List<ExportableObject> expObjList) {
		String xmlData;
		ExportableObject expObj;
		XMLStreamWriter xtw = null;

		StringWriter strWriter = new StringWriter();
		XMLOutputFactory xof = XMLOutputFactory.newInstance();

		try {
			xtw = xof.createXMLStreamWriter(strWriter);

			xtw.writeStartDocument("UTF-8", "1.0");
			xtw.writeComment("List all exportable objects with required information.");
			xtw.writeStartElement("ExportableObjects");

			int size = expObjList.size();
			for (int i = 0; i < size; i++) {
				expObj = expObjList.get(i);

				xtw.writeStartElement("ExportableObject");
				writeElement(xtw, "ObjectName", expObj.getObjName());
				writeElement(xtw, "ObjectType", expObj.getObjType());
				writeElement(xtw, "Classification", expObj.getClassification());
				writeElement(xtw, "ExportStatus", expObj.getExportStatus());
				writeElement(xtw, "Rational", expObj.getRational());
				xtw.writeEndElement();
			}

			xtw.writeEndElement();
			//xtw.writeEndDocument();

			xtw.flush();
			xtw.close();
		} catch (XMLStreamException exp) {
			logger.error("Exception: " + exp.getMessage());
			throw new RuntimeException(exp);
		} finally {
			if (xtw != null) {
				try {
					xtw.flush();
					xtw.close();
				} catch (XMLStreamException exp) {
					logger.error("Exception: " + exp.getMessage());					
				}
			}
		}

		xmlData = strWriter.toString();

		logger.debug("Result xml: " + xmlData);
		return xmlData;
	}

	private void writeElement(XMLStreamWriter xtw, String eleName, String eleValue) throws XMLStreamException {

		if (eleValue != null && eleValue.length() != 0) {
			xtw.writeStartElement(eleName);
			xtw.writeCharacters(eleValue);
			xtw.writeEndElement();
		} else {
			xtw.writeEmptyElement(eleName);
		}

	}
}
