/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import com.geinfra.geaviation.ectstw.data.ITARQuestionVO;
import com.geinfra.geaviation.ectstw.service.ITARQuestionService;
import com.geinfra.geaviation.ectstw.utils.SelectItemComparator;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class ITARQuestionBean extends AbstractQuestionBean {
	private ITARQuestionVO itarQuestionVO = null;
	private ITARQuestionService itarQuestionService = null;

	private final static int USML_LIST_SIZE = 21;

	private List<SelectItem> selITARReasonList = new ArrayList<SelectItem>();
	private List<SelectItem> selUSMLList = new ArrayList<SelectItem>();
	private List<SelectItem> availableUSMLTypeList = new ArrayList<SelectItem>();
	private List<SelectItem> selectedUSMLTypeList = new ArrayList<SelectItem>();

	public List<SelectItem> getSelITARReasonList() throws Exception {
		if (!itarQuestionVO.isSelITARReasonEnabled()) {
			return new ArrayList<SelectItem>();
		}

		if (selITARReasonList.isEmpty()) {
			List<String> tempList = itarQuestionService.getITARReasons();
			selITARReasonList = faceletUtil.createSelectUIList(tempList, "ITAR");
		}

		return selITARReasonList;
	}

	public void setSelITARReasonList(List<SelectItem> selITARReasonList) {
		this.selITARReasonList = selITARReasonList;
	}

	public List<SelectItem> getSelUSMLList() {
		if (selUSMLList.isEmpty()) {
			for (int i = 1; i <= USML_LIST_SIZE; i++) {
				selUSMLList.add(new SelectItem("" + i, "USML 121.1 category " + i));
			}
		}

		return selUSMLList;
	}

	public void setSelUSMLList(List<SelectItem> selUSMLList) {
		this.selUSMLList = selUSMLList;
	}

	public void updateAvailableUSMLTypeList(ActionEvent ae) throws Exception {		
		List<String> tempSelUSMLValues = new ArrayList<String>();
		List<SelectItem> tempAvailUSMLValues = new ArrayList<SelectItem>();

		if (itarQuestionVO.getSelUSMLType() != null && itarQuestionVO.getSelUSMLType().length() != 0) {
			List<String> tempList = itarQuestionService.getUSMLCatagory();

			for (int i = 0; i < selectedUSMLTypeList.size(); i++) {
				SelectItem selItem = selectedUSMLTypeList.get(i);
				String val = (String) selItem.getValue();
				tempSelUSMLValues.add(val);
			}

			for (String item : tempList) {
				if (item.startsWith(itarQuestionVO.getSelUSMLType())) {
					if (!tempSelUSMLValues.contains(item)) {
						tempAvailUSMLValues.add(new SelectItem(item, item));
					}
				}
			}
		}
		availableUSMLTypeList = tempAvailUSMLValues;
	}

	public void moveToSelectedList(ActionEvent event) {
		List<SelectItem> tempSelUSMLValues = new ArrayList<SelectItem>(selectedUSMLTypeList);
		List<SelectItem> tempAvailUSMLValues = new ArrayList<SelectItem>(availableUSMLTypeList);
		
		String newUsml = null;
		String oldUsml = null;
		boolean isExists = false;
		Iterator<String> itr = itarQuestionVO.getAvailableUSMLValues().iterator();
		while (itr.hasNext()) {
			newUsml = itr.next();
			isExists = false;

			Iterator<SelectItem> itrX = selectedUSMLTypeList.iterator();
			while (itrX.hasNext()) {
				oldUsml = (String) itrX.next().getValue();
				if (oldUsml.equals(newUsml)) {
					isExists = true;
					break;
				}
			}
			if (!isExists) {
				tempSelUSMLValues.add(new SelectItem(newUsml, newUsml));
			}

			itrX = tempAvailUSMLValues.iterator();
			while (itrX.hasNext()) {
				oldUsml = (String) itrX.next().getValue();
				if (oldUsml.equals(newUsml)) {
					itrX.remove();
					break;
				}
			}
		}
		selectedUSMLTypeList = tempSelUSMLValues;
		availableUSMLTypeList = tempAvailUSMLValues;
		
		itarQuestionVO.setAvailableUSMLValues(new ArrayList<String>());
		Collections.sort(selectedUSMLTypeList, new SelectItemComparator());
	}

	public void moveToAvailableList(ActionEvent ae) {
		List<SelectItem> tempSelUSMLValues = new ArrayList<SelectItem>(selectedUSMLTypeList);
		List<SelectItem> tempAvailUSMLValues = new ArrayList<SelectItem>(availableUSMLTypeList);
		
		String newUsml = null;
		String oldUsml = null;
		boolean isExists = false;

		Iterator<String> itrX = itarQuestionVO.getSelectedUSMLValues().iterator();
		while (itrX.hasNext()) {
			newUsml = itrX.next();
			isExists = false;

			Iterator<SelectItem> itrY = availableUSMLTypeList.iterator();
			while (itrY.hasNext()) {
				oldUsml = (String) itrY.next().getValue();
				if (oldUsml.equals(newUsml)) {
					isExists = true;
					break;
				}
			}
			if (!isExists) {
				tempAvailUSMLValues.add(new SelectItem(newUsml, newUsml));
			}

			itrY = tempSelUSMLValues.iterator();
			while (itrY.hasNext()) {
				oldUsml = (String) itrY.next().getValue();
				if (oldUsml.equals(newUsml)) {
					itrY.remove();
					break;
				}
			}
		}
		selectedUSMLTypeList = tempSelUSMLValues;
		availableUSMLTypeList = tempAvailUSMLValues;
		
		itarQuestionVO.setSelectedUSMLValues(new ArrayList<String>());
		Collections.sort(availableUSMLTypeList, new SelectItemComparator());
	}

	public ITARQuestionVO getItarQuestionVO() {
		return itarQuestionVO;
	}

	public void setItarQuestionVO(ITARQuestionVO itarQuestionVO) {
		this.itarQuestionVO = itarQuestionVO;
	}

	public ITARQuestionService getItarQuestionService() {
		return itarQuestionService;
	}

	public void setItarQuestionService(ITARQuestionService itarQuestionService) {
		this.itarQuestionService = itarQuestionService;
	}

	public Map getComponentStatusMap(Map compStatusMap) {
		return itarQuestionService.validate(compStatusMap);
	}
	
	public List<SelectItem> getAvailableUSMLTypeList() {
		if(!itarQuestionVO.isSelUSMLEnabled()){
			availableUSMLTypeList.clear();			
		}
		return availableUSMLTypeList;
	}
	
	public void setAvailableUSMLTypeList(List<SelectItem> availableUSMLTypeList) {
		this.availableUSMLTypeList = availableUSMLTypeList;
	}
	
	public List<SelectItem> getSelectedUSMLTypeList() {
		if(!itarQuestionVO.isSelUSMLEnabled()){
			selectedUSMLTypeList.clear();			
		}
		return selectedUSMLTypeList;
	}

	public void setSelectedUSMLTypeList(List<SelectItem> selectedUSMLTypeList) {
		this.selectedUSMLTypeList = selectedUSMLTypeList;
	}
}
