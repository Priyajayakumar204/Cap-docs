/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.ajax4jsf.component.html.HtmlAjaxSupport;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.data.EARQuestionVO;
import com.geinfra.geaviation.ectstw.service.EARQuestionService;
import com.geinfra.geaviation.ectstw.utils.SelectItemComparator;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class EARQuestionBean extends AbstractQuestionBean {
	private static Logger logger = Logger.getLogger(EARQuestionBean.class);
	private EARQuestionVO earQuestionVO = null;
	private EARQuestionService earQuestionService = null;

	private final static int ECCN_LIST_SIZE = 9;

	private List<SelectItem> selEARList = new ArrayList<SelectItem>();
	private List<SelectItem> selECCNList = new ArrayList<SelectItem>();

	private List<SelectItem> availableECCNTypeList = new ArrayList<SelectItem>();
	private List<SelectItem> selectedECCNTypeList = new ArrayList<SelectItem>();

	public List<SelectItem> getSelEARList() throws Exception {
		if (!earQuestionVO.isSelEARReasonEnabled()) {
			return new ArrayList<SelectItem>();
		}

		if (selEARList.isEmpty()) {
			List<String> tempList = earQuestionService.getEARReasons();
			selEARList = faceletUtil.createSelectUIList(tempList, "EAR");
		}

		return selEARList;
	}

	public void setSelEARList(List<SelectItem> selEARList) {
		this.selEARList = selEARList;
	}

	public List<SelectItem> getSelECCNList() {
		if (selECCNList.isEmpty()) {
			for (int i = 1; i <= ECCN_LIST_SIZE; i++) {
				selECCNList.add(new SelectItem("" + i, "ECCN starting with " + i + " ..."));
			}
		}

		return selECCNList;
	}

	public void setSelECCNList(List<SelectItem> selECCNList) {
		this.selECCNList = selECCNList;
	}

	public void updateAvailableECCNTypeList(ActionEvent ae) throws Exception {
		HtmlAjaxSupport htmlObnj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectOneMenu selOneMenu = (HtmlSelectOneMenu) htmlObnj.getParent();

		//logger.debug("Action1:" + selOneMenu.getValue().getClass().getName());		
		
		List<String> tempSelECCNValues = new ArrayList<String>();
		List<SelectItem> tempAvailECCNValues = new ArrayList<SelectItem>();

		if (earQuestionVO.getSelECCNIndex() >= 0 && earQuestionVO.getSelECCNIndex() <= ECCN_LIST_SIZE) {
			List<String> dbECCNTypeList = earQuestionService.getECCNCatagoriesSub();

			for (int i = 0; i < selectedECCNTypeList.size(); i++) {
				SelectItem selItem = selectedECCNTypeList.get(i);
				String val = (String) selItem.getValue();
				tempSelECCNValues.add(val);
			}

			if (!tempSelECCNValues.contains("EAR99")) {
				tempAvailECCNValues.add(new SelectItem("EAR99", "EAR99"));
			}

			for (String item : dbECCNTypeList) {
				if (item.startsWith("" + earQuestionVO.getSelECCNIndex())) {
					if (!tempSelECCNValues.contains(item)) {
						tempAvailECCNValues.add(new SelectItem(item, item));
					}
				}
			}
		}
		
		availableECCNTypeList = tempAvailECCNValues;
	}

	public void moveToSelectedList(ActionEvent event) {
		List<SelectItem> tempSelECCNValues = new ArrayList<SelectItem>(selectedECCNTypeList);
		List<SelectItem> tempAvailECCNValues = new ArrayList<SelectItem>(availableECCNTypeList);
		
		String newUsml = null;
		String oldUsml = null;

		boolean isExists = false;
		Iterator<String> itr = earQuestionVO.getAvailableECCNValues().iterator();
		while (itr.hasNext()) {
			newUsml = itr.next();
			isExists = false;

			Iterator<SelectItem> itrX = selectedECCNTypeList.iterator();
			while (itrX.hasNext()) {
				oldUsml = (String) itrX.next().getValue();
				if (oldUsml.equals(newUsml)) {
					isExists = true;
					break;
				}
			}
			if (!isExists) {
				tempSelECCNValues.add(new SelectItem(newUsml, newUsml));
			}

			itrX = tempAvailECCNValues.iterator();
			while (itrX.hasNext()) {
				oldUsml = (String) itrX.next().getValue();
				if (oldUsml.equals(newUsml)) {
					itrX.remove();
					break;
				}
			}
		}
		selectedECCNTypeList = tempSelECCNValues;
		availableECCNTypeList = tempAvailECCNValues;
		
		earQuestionVO.setAvailableECCNValues(new ArrayList<String>());
		Collections.sort(selectedECCNTypeList, new SelectItemComparator());
	}

	public void moveToAvailableList(ActionEvent ae) {
		List<SelectItem> tempSelECCNValues = new ArrayList<SelectItem>(selectedECCNTypeList);
		List<SelectItem> tempAvailECCNValues = new ArrayList<SelectItem>(availableECCNTypeList);
		
		String newUsml = null;
		String oldUsml = null;
		boolean isExists = false;

		Iterator<String> itrX = earQuestionVO.getSelectedECCNValues().iterator();
		while (itrX.hasNext()) {
			newUsml = itrX.next();
			isExists = false;

			Iterator<SelectItem> itrY = availableECCNTypeList.iterator();
			while (itrY.hasNext()) {
				oldUsml = (String) itrY.next().getValue();
				if (oldUsml.equals(newUsml)) {
					isExists = true;
					break;
				}
			}
			if (!isExists) {
				tempAvailECCNValues.add(new SelectItem(newUsml, newUsml));
			}

			itrY = tempSelECCNValues.iterator();
			while (itrY.hasNext()) {
				oldUsml = (String) itrY.next().getValue();
				if (oldUsml.equals(newUsml)) {
					itrY.remove();
					break;
				}
			}
		}
		selectedECCNTypeList = tempSelECCNValues;
		availableECCNTypeList = tempAvailECCNValues;
		
		earQuestionVO.setSelectedECCNValues(new ArrayList<String>());
		Collections.sort(availableECCNTypeList, new SelectItemComparator());
	}

	public EARQuestionVO getEarQuestionVO() {
		return earQuestionVO;
	}

	public void setEarQuestionVO(EARQuestionVO earQuestionVO) {
		this.earQuestionVO = earQuestionVO;
	}

	public EARQuestionService getEarQuestionService() {
		return earQuestionService;
	}

	public void setEarQuestionService(EARQuestionService earQuestionService) {
		this.earQuestionService = earQuestionService;
	}

	public Map getComponentStatusMap(Map compStatusMap) {
		return earQuestionService.validate(compStatusMap);
	}
	
	public List<SelectItem> getAvailableECCNTypeList() {
		if(!earQuestionVO.isSelECCNEnabled()){
			availableECCNTypeList.clear();
		}
		
		return availableECCNTypeList;
	}
	
	public void setAvailableECCNTypeList(List<SelectItem> availableECCNTypeList) {
		this.availableECCNTypeList = availableECCNTypeList;
	}

	public List<SelectItem> getSelectedECCNTypeList() {
		if(!earQuestionVO.isSelECCNEnabled()){
			selectedECCNTypeList.clear();
		}
		
		return selectedECCNTypeList;
	}

	public void setSelectedECCNTypeList(List<SelectItem> selectedECCNTypeList) {
		this.selectedECCNTypeList = selectedECCNTypeList;
	}
}
