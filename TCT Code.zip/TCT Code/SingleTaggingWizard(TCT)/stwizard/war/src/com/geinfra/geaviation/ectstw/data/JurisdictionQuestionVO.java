/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class JurisdictionQuestionVO extends BaseSTWVO {
	private boolean stateDeptEnabled = false;
	private boolean commDeptEnabled = false;
	private String department = null;
	private String juriRationalText = null;
	
	private boolean drawingModelEnabled = false;
	private String drawingModel = null;	

	private boolean drawingReviewSpecEnabled = false;
	private String drawingReviewSpec = null;
	
	public boolean isStateDeptEnabled() {
		return stateDeptEnabled;
	}

	public void setStateDeptEnabled(boolean stateDeptEnabled) {
		this.stateDeptEnabled = stateDeptEnabled;
	}

	public boolean isCommDeptEnabled() {
		return commDeptEnabled;
	}

	public void setCommDeptEnabled(boolean commDeptEnabled) {
		this.commDeptEnabled = commDeptEnabled;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public boolean isDrawingModelEnabled() {
		return drawingModelEnabled;
	}

	public void setDrawingModelEnabled(boolean drawingModelEnabled) {
		this.drawingModelEnabled = drawingModelEnabled;
	}

	public String getDrawingModel() {
		return drawingModel;
	}

	public void setDrawingModel(String drawingModel) {
		this.drawingModel = drawingModel;
	}

	public boolean isDrawingReviewSpecEnabled() {
		return drawingReviewSpecEnabled;
	}

	public void setDrawingReviewSpecEnabled(boolean drawingReviewSpecEnabled) {
		this.drawingReviewSpecEnabled = drawingReviewSpecEnabled;
	}

	public String getDrawingReviewSpec() {
		return drawingReviewSpec;
	}

	public void setDrawingReviewSpec(String drawingReviewSpec) {
		this.drawingReviewSpec = drawingReviewSpec;
	}

	public String getJuriRationalText() {
		if(juriRationalText == null){
			return "";
		}
		return juriRationalText;
	}

	public void setJuriRationalText(String juriRationalText) {
		/*
		if(TaggingWizardUtil.isSpecialCharacter(juriRationalText)){
			TaggingWizardUtil.addMessage("Speacial characters are not allowed.");
			return;
		}
		*/
		this.juriRationalText = juriRationalText;
	}
}
