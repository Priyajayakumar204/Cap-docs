/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common.faces;

import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.apache.log4j.Logger;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class CustomPhaseListener implements PhaseListener {
	private final static long serialVersionUID = 2131946617880013988L;
	private final static Logger logger = Logger.getLogger(CustomPhaseListener.class);

	public void afterPhase(PhaseEvent event) {
		logger.debug("after phase: " + event.getPhaseId());
	}

	public void beforePhase(PhaseEvent event) {
		logger.debug("before phase: " + event.getPhaseId());

		/*
			if(event.getPhaseId().equals(PhaseId.RENDER_RESPONSE)) {
				FacesContext facescontext = event.getFacesContext();
				
				Boolean resetView;
				
				logger.debug("dwbWizard map: " + facescontext.getExternalContext().getSessionMap());
				
				if(facescontext.getExternalContext().getRequest() instanceof PortletRequest){
					resetView = (Boolean)((PortletRequest)facescontext.getExternalContext().getRequest()).getPortletSession().getAttribute("RESET_VIEW", 1);
					((PortletRequest)facescontext.getExternalContext().getRequest()).getPortletSession().removeAttribute("RESET_VIEW", 1);
				} else {
					resetView = (Boolean)((HttpServletRequest)facescontext.getExternalContext().getRequest()).getSession().getAttribute("RESET_VIEW");
					((HttpServletRequest)facescontext.getExternalContext().getRequest()).getSession().removeAttribute("RESET_VIEW");
				}
				
				if(resetView != null){				
					logger.debug("resetting application state by creating new backing beans...");
					logger.debug("viewId: " + event.getFacesContext().getViewRoot().getViewId());
					Class dwbWizard = com.geinfra.geaviation.ectstw.wizards.DWBWizard.class;				
					ELContext elContext = facescontext.getELContext();
					facescontext.getApplication().getExpressionFactory().createValueExpression(elContext, "#{dwbWizard}", dwbWizard).setValue(elContext, null);
					facescontext.setViewRoot(facescontext.getApplication().getViewHandler().createView(event.getFacesContext(), "/faces/dwb-tagger.jsp"));				
				}
			}
		*/

	}

	public PhaseId getPhaseId() {
		return PhaseId.ANY_PHASE;
	}
}
