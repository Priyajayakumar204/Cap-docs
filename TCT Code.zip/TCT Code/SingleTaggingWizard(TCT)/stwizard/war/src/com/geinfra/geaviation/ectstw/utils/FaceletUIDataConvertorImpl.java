/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class FaceletUIDataConvertorImpl implements FaceletUIDataConvertor {
	private static Logger logger = Logger.getLogger(FaceletUIDataConvertorImpl.class);
	public FaceletUIDataConvertorImpl() {
		logger.debug("FaceletUIDataConvertorImpl Created:" + this);
	}

	public List<SelectItem> createSelectUIList(List<String> itemList) {
		List<SelectItem> tempList = new ArrayList<SelectItem>();
		
		if (itemList == null || itemList.isEmpty()) {
			return tempList;
		}

		for (String item : itemList) {
			tempList.add(new SelectItem(item, item));
		}
		
		return tempList;
	}

	public List<SelectItem> createSelectUIList(List<String> itemList, String filterStr) {
		List<SelectItem> tempList = new ArrayList<SelectItem>();
		
		if (itemList == null || itemList.isEmpty()) {
			return tempList;
		}

		for (String item : itemList) {
			if (item.indexOf(filterStr) != -1) {
				tempList.add(new SelectItem(item, item));
			}
		}
		
		return tempList;
	}

}
