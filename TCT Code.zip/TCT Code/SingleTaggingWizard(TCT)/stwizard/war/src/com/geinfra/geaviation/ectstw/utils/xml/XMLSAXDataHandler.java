/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils.xml;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import com.geinfra.geaviation.ectstw.data.ExportableObject;
import com.geinfra.geaviation.ectstw.webservice.ECTTagWebService;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class XMLSAXDataHandler implements XMLDataHandler {
	private static Logger logger = Logger.getLogger(XMLSAXDataHandler.class);
	public List<ExportableObject> readXMLData(String xml) {
		XMLSAXEventHandler eventHandler = new XMLSAXEventHandler();

		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		//saxFactory.setValidating(false);
		//saxFactory.setNamespaceAware(false);

		try {
			SAXParser saxParser = saxFactory.newSAXParser();
			saxParser.parse(new ByteArrayInputStream(xml.getBytes()), eventHandler);
		} catch (Exception exp) {
			logger.error("Exception: " + exp.getMessage());
			
			throw new RuntimeException(exp);
		}

		return eventHandler.getExpObjList();
	}

	public String writeXMLData(List<ExportableObject> expObjList) {
		ExportableObject expObj;

		StringWriter strWriter = new StringWriter();
		StreamResult streamResult = new StreamResult(strWriter);

		try {
			SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
			TransformerHandler hd = tf.newTransformerHandler();
			Transformer serializer = hd.getTransformer();
			serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			//serializer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "users.dtd");
			serializer.setOutputProperty(OutputKeys.INDENT, "yes");

			hd.setResult(streamResult);

			hd.startDocument();
			hd.startElement("", "", "ExportableObjects", new AttributesImpl());

			int size = expObjList.size();
			for (int i = 0; i < size; i++) {
				expObj = expObjList.get(i);

				hd.startElement("", "", "ExportableObject", new AttributesImpl());
				writeElement(hd, "ObjectName", expObj.getObjName());
				writeElement(hd, "ObjectType", expObj.getObjType());
				writeElement(hd, "Classification", expObj.getClassification());
				writeElement(hd, "ExportStatus", expObj.getExportStatus());
				writeElement(hd, "Rational", expObj.getRational());
				hd.endElement("", "", "ExportableObject");
			}

			hd.endElement("", "", "ExportableObjects");
		} catch (SAXException exp) {
			logger.error("Exception: " + exp.getMessage());
			throw new RuntimeException(exp);
		} catch (TransformerConfigurationException exp) {
			logger.error("Exception: " + exp.getMessage());
			throw new RuntimeException(exp);
		}

		return strWriter.toString();
	}

	private void writeElement(TransformerHandler hd, String eleName, String eleValue) throws SAXException {
		hd.startElement("", "", eleName, null);
		if (eleValue != null && eleValue.length() != 0) {
			hd.characters(eleValue.toCharArray(), 0, eleValue.length());
		} else {
			//hd.characters(eleValue.toCharArray(), 0, eleValue.length());
		}
		hd.endElement("", "", eleName);
	}

}
