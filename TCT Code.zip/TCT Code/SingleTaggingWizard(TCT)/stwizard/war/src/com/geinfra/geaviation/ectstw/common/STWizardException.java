/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common;

public class STWizardException extends Exception {
	private final static long serialVersionUID = 4025927232474016132L;

	public STWizardException() {
	}

	public STWizardException(String str) {
		super(str);
	}

	public STWizardException(String str, Throwable throwable) {
		super(str, throwable);
	}

	public STWizardException(Throwable throwable) {
		super(throwable);
	}
}
