/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

import java.io.PrintStream;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.common.bean.CustomMessageHandler;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class TaggingWizardUtil {
	private static Logger logger = Logger.getLogger(TaggingWizardUtil.class);
	
	private TaggingWizardUtil(){}
	
	public static String getUserSSO() {
		return FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
	}

	public static void handleFacesError(String message, Exception exp) {
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, exp.getMessage()));
	}

	public static void handleFacesError(String message) {
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message));
	}

	public static void handleFacesError(String message, Exception exp, FacesContext ctx) {
		ctx.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, exp.getMessage()));
	}

	public static void handleFacesError(String message, FacesContext ctx) {
		ctx.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message));
	}

	public static void handleFacesInfo(String message, Exception exp) {
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO, message, exp.getMessage()));
	}

	public static void handleFacesInfo(String message) {
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO, message, message));
	}

	public static void handleFacesInfo(String message, Exception exp, FacesContext ctx) {
		ctx.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO, message, exp.getMessage()));
	}

	public static void handleFacesInfo(String message, FacesContext ctx) {
		ctx.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO, message, message));
	}

	public static Object getSessionAttribute(String key) {
		Object value = null; 
		
		PortletRequest portletRequest = null;
		PortletSession portletSession = null;
		
		HttpServletRequest httpRequest = null;
		HttpSession httpSession = null;
		
		
		ExternalContext extContext = FacesContext.getCurrentInstance().getExternalContext(); 
		Object request = extContext.getRequest();
		
		if(request instanceof PortletRequest){
			portletRequest = (PortletRequest) request;
			portletSession = portletRequest.getPortletSession(true);			
			value = portletSession.getAttribute(key, 1);
		} else {
			httpRequest = (HttpServletRequest) request;
			httpSession = httpRequest.getSession(true);
			value = httpSession.getAttribute(key);
		}
		
		return value;
	}

	public static void setSessionAttribute(String key, Object value) {
		PortletRequest portletRequest = null;
		PortletSession portletSession = null;
		
		HttpServletRequest httpRequest = null;
		HttpSession httpSession = null;
		
		
		ExternalContext extContext = FacesContext.getCurrentInstance().getExternalContext(); 
		Object request = extContext.getRequest();
		
		if(request instanceof PortletRequest){
			portletRequest = (PortletRequest) request;
			portletSession = portletRequest.getPortletSession(true);			
			portletSession.setAttribute(key, value, 1);
		} else {
			httpRequest = (HttpServletRequest) request;
			httpSession = httpRequest.getSession(true);
			httpSession.setAttribute(key, value);
		}
	}

	public static Map getRequestMap(){
		return FacesContext.getCurrentInstance().getExternalContext().getRequestMap();
	}
	
	public static PortletRequest getPortletRequest(){
		return (PortletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}
	
	public static CustomMessageHandler getMsgHandler() {
		Map<String, Object> reqMap = getRequestMap();

		CustomMessageHandler msgHandler = (CustomMessageHandler) reqMap.get(TaggingWizardConstants.CUSTOM_MSG_LIST_KEY);
		if (msgHandler == null) {
			
			msgHandler = new CustomMessageHandler();
			reqMap.put(TaggingWizardConstants.CUSTOM_MSG_LIST_KEY, msgHandler);
		}
		

		return msgHandler;
	}

	public static void addError(Exception exp, String userMessage) {
		getMsgHandler().addError(exp, userMessage);
	}

	public static void addMessage(String userMessage) {
		getMsgHandler().addMessage(userMessage);
	}

	public static String booleanYesNo(boolean value) {
		if (value) {
			return TaggingWizardConstants.YES;
		} else {
			return TaggingWizardConstants.NO;
		}
	}
	
	public static void printException(Throwable exp){
		logger.error("Exception: [" + exp.getClass() + "] - [cause: " + exp.getCause() + "] - " + exp.getMessage());
	}
	
	public static void printExceptionTrack(Throwable exp){
		logger.debug(exp);

		StackTraceElement astacktraceelement[] = exp.getStackTrace();
		for (int i = 0; i < astacktraceelement.length; i++)
			logger.debug((new StringBuilder()).append("\tat ").append(astacktraceelement[i]).toString());

		Throwable throwable = exp.getCause();
		if (throwable != null)
			printExceptionTrackAsCause(throwable, astacktraceelement);
	}
	
	private static void printExceptionTrackAsCause(Throwable throwable, StackTraceElement astacktraceelement[]) {
		StackTraceElement astacktraceelement1[] = throwable.getStackTrace();
		int i = astacktraceelement1.length - 1;

		for (int j = astacktraceelement.length - 1; i >= 0 && j >= 0 && astacktraceelement1[i].equals(astacktraceelement[j]); j--)
			i--;

		int k = astacktraceelement1.length - 1 - i;
		logger.debug((new StringBuilder()).append("Caused by: ").append(throwable).toString());

		for (int l = 0; l <= i; l++)
			logger.debug((new StringBuilder()).append("\tat ").append(astacktraceelement1[l]).toString());

		if (k != 0)
			logger.debug((new StringBuilder()).append("\t... ").append(k).append(" more").toString());

		Throwable newThrowable = throwable.getCause();
		if (newThrowable != null)
			printExceptionTrackAsCause(newThrowable, astacktraceelement1);
	}
	
	/**
	 * For special character validation - underscore hyphen are allowed.
	 * 
	 * @param string
	 * @return true if the passed string contains special characters.
	 */
	public static boolean isSpecialCharacter(final String inputStr) {
		final String splCharacters = ResourceFactory.getInstance().getTextMsg("SPECIAL_CHARACTERS");
		
		if(inputStr == null || inputStr.length() == 0){
			return false;
		}
			
		for (int index = 0; index < inputStr.length(); index++) {
			if (splCharacters.indexOf(inputStr.charAt(index)) != -1) {
				return true;
			}
		}
		return false;
	}
	
	public static String makeTextWrapped(String text, int length){
		StringBuilder strBuilder = new StringBuilder();
		
		if(text == null){
			return null;
		}
		
		int pos = 0;
		int len = text.length();
		do {
			if((pos + length) < len) {			
				strBuilder.append(text.substring(pos, pos + length) + "<br/>");
				pos = pos + length;
			} else {
				strBuilder.append(text.substring(pos));
				pos = len;
			}
		} while (pos < len);
		
		return strBuilder.toString();
	}
}
