/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.data;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class ExportableObject {
	private String objName;
	private String objType;
	private String classification;
	private String exportStatus;
	private String rational;

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getExportStatus() {
		return exportStatus;
	}

	public void setExportStatus(String exportStatus) {
		this.exportStatus = exportStatus;
	}

	public String getRational() {
		return rational;
	}

	public void setRational(String rational) {
		this.rational = rational;
	}

	@Override
	public String toString() {
		return new StringBuffer().append(objName + ", ").append(objType + ", ").append(classification + ", ").append(exportStatus + ", ").append(rational + ".").toString();
	}
}
