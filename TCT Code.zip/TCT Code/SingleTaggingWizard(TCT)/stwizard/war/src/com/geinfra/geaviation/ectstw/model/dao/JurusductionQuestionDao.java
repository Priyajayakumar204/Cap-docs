/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

public class JurusductionQuestionDao extends BaseSTWDao {

}
