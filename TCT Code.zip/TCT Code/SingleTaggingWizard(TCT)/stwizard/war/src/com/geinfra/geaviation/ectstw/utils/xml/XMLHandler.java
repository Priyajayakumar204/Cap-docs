/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils.xml;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.data.ExportableObject;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class XMLHandler {
	private XMLHandler(){}
	
	public static void main(String[] args) {
		Logger logger = Logger.getLogger(XMLHandler.class);
		List<ExportableObject> expObjList = new ArrayList<ExportableObject>();
		ExportableObject expObj;

		for (int i = 0; i < 10; i++) {
			expObj = new ExportableObject();

			expObj.setObjName("objName" + i);
			expObj.setObjType("objType" + i);
			expObj.setClassification("classification" + i);
			expObj.setExportStatus("exportSatus" + i);
			expObj.setRational("rational" + i);

			expObjList.add(expObj);
		}

		String xmlData = new XMLSAXDataHandler().writeXMLData(expObjList);
		logger.debug("xml: " + xmlData);

		logger.debug("data: " + new XMLStreamDataHandler().readXMLData(xmlData));
		logger.debug("data: " + new XMLSAXDataHandler().readXMLData(xmlData));
	}
}
