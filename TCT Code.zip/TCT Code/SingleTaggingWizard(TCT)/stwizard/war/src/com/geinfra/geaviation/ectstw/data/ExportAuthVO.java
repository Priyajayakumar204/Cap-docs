/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

public class ExportAuthVO extends BaseSTWVO {

}
