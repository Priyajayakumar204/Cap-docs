/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils.xml;

import java.util.List;

import com.geinfra.geaviation.ectstw.data.ExportableObject;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public interface XMLDataHandler {
	public List<ExportableObject> readXMLData(String xml);

	public String writeXMLData(List<ExportableObject> expObjList);
}
