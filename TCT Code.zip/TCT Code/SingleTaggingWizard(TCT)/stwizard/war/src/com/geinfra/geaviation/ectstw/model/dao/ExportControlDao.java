/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName ExportControlDao.java
 * @version 1.0
 * @author kumar, Amit
 */
import geae.dao.GEAEResultSet;
import geae.exception.dao.GEAESQLException;
import geae.export.ect.GEAEECTException;
import geae.export.ect.GEAEExportControlObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

@SuppressWarnings("unchecked")
public class ExportControlDao {
	private final static Logger logger = Logger.getLogger(ExportControlDao.class);

	private final static int ECT_COL_CODE = 1;
	private final static int ECT_COL_TYPE = 3;
	private final static String ECT_STATUS_NLR = "NLR";
	private final static String ECT_STATUS_LRS = "LRS";
	private final static String ECT_STATUS_LRC = "LRC";
	private final static String ECT_STATUS_DNE = "DNE";
	private final static String ECT_STATUS_NSR = "NSR";

	private final static String ECT_TYPE_USML = "USML";
	private final static String ECT_TYPE_ECCN = "ECCN";
	private final static String ECT_TYPE_DNE_REASON = "DNE Reason";
	// private final static String ECT_TYPE_NSR_EAR_REASON = "EAR Reason";
	// private final static String ECT_TYPE_NSR_ITAR_REASON = "ITAR Reason";

	private final static String ECT_TYPE_NSR_EAR_REASON = "Reason";
	private final static String ECT_TYPE_NSR_ITAR_REASON = "Reason";

	private final static String ECT_CODE_GEAE_CTRL_TECH = "GEAE Controlled Technology";

	private static HashMap classificationCodeList;
	private static HashMap classificationList;

	/**
	 * default constructor
	 */
	public ExportControlDao() {
		logger.info("ExportControlDao Initializing...");

		try {
			getClassificationCodeList();
		} catch (Exception ex) {
			logger.error("Error during initiliazation of ExportControlDao class...");
			logger.error("Exception: " + ex.getMessage());
		}
	}

	/**
	 * This program is used to implement Export Tagging Wizard functionality
	 * 
	 * @param context
	 *            The current users context
	 * @throws Exception
	 *             If the operation is unsecessful
	 */

	public Map getECTData(String appId, String appType, String objectId) throws Exception {
		Map map;
		String sExportStatus = "";
		String sLicense = "";
		String sClassCode = "";
		String sRationale = "";
		try {
			String[] sReturn = getExportInfo(appId, appType, objectId);
			// exportStatus is first token
			sExportStatus = sReturn[0];
			// sLicense is second token
			sLicense = sReturn[1];
			// sClassCode is third token
			sClassCode = sReturn[2];
			// sRationale is fourth token
			sRationale = sReturn[3];

			map = new HashMap();
			// map.put("sName", sObjectName);
			// map.put("sObjectId", sObjectId);
			// map.put("appType", sAppType);
			map.put("sExportStatus", sExportStatus);
			map.put("sLicense", sLicense);
			map.put("sClassCode", sClassCode);
			map.put("sRationale", sRationale);
		} catch (Exception e) {
			logger.error("Exception in ExportControlDao[getECTData] :::" + e);
			throw e;
		}

		return map;
	} // end getECTData

	/**
	 * @param objId
	 * @return String
	 * @throws Exception
	 */
	public static String[] getExportInfo(String appId, String appType, String objId) throws Exception {
		String objectId = objId;
		String[] sReturn = new String[4];
		GEAEResultSet rs = null;
		GEAEResultSet rsReturn = null;
		try {
			rs = new GEAEResultSet();
			rs.setColumnHeading(0, "appId");
			rs.setColumnHeading(1, "appType");
			rs.setColumnHeading(2, "appName");

			ArrayList row = new ArrayList();
			row.add(appId);
			row.add(appType);
			row.add(objectId.trim());

			rs.addRow(row);
			rsReturn = GEAEExportControlObject.lookupNewExportability(rs);

			while (rsReturn.next()) {
				sReturn[0] = rsReturn.getString(4);
				sReturn[1] = rsReturn.getString(5);
				sReturn[2] = rsReturn.getString(8);
				sReturn[3] = rsReturn.getString(9);
			} // end while loop
		} catch (GEAESQLException e) {
			logger.error("Exception in ExportControlDao[getExportInfo] objId::::::" + e);
			throw e;
		} catch (GEAEECTException e) {
			logger.error("Exception in ExportControlDao[getExportInfo] objId::::::" + e);
			throw e;
		}
		return sReturn;
	}// END getExportInfo

	/**
	 * @param sCurrentExportStatus
	 * @param sNewExportStatus
	 * @return boolean
	 * @throws Exception
	 */
	public boolean canClassify(String sCurrentExportStatus, String sNewExportStatus) throws Exception {
		boolean bCanClassify = false;
		ArrayList<String> lValidExportStatus = new ArrayList<String>();

		// adding by Hanpiing Long 7/11/08

		if (sCurrentExportStatus != null) {

			if (sCurrentExportStatus.equalsIgnoreCase("NLR")) {
				lValidExportStatus.add("NSR");
				lValidExportStatus.add("NLR");
				lValidExportStatus.add("NLR+LRJ");
			} else if (sCurrentExportStatus.equalsIgnoreCase("NLR+LRJ")) {
				lValidExportStatus.add("NLR+LRJ");
			} else if (sCurrentExportStatus.equalsIgnoreCase("LRC")) {
				lValidExportStatus.add("LRC");
				lValidExportStatus.add("NLR");
				lValidExportStatus.add("NSR");
				lValidExportStatus.add("LRC+LRJ");
				lValidExportStatus.add("NLR+LRJ");

			} else if (sCurrentExportStatus.equalsIgnoreCase("LRC+LRJ")) {
				lValidExportStatus.add("NLR+LRJ");
				lValidExportStatus.add("LRC+LRJ");
			} else if (sCurrentExportStatus.equalsIgnoreCase("LRS")) {
				lValidExportStatus.add("NSR");
				lValidExportStatus.add("NLR");
				lValidExportStatus.add("NLR+LRJ");
				lValidExportStatus.add("LRS");
			} else if (sCurrentExportStatus.equalsIgnoreCase("LRS+LRC")) {
				lValidExportStatus.add("NSR");
				lValidExportStatus.add("NLR");
				lValidExportStatus.add("NLR+LRJ");
				lValidExportStatus.add("LRS+LRC");
			} else if (sCurrentExportStatus.equalsIgnoreCase("DNE")) {
				lValidExportStatus.add("DNE");
			} else if (sCurrentExportStatus.equalsIgnoreCase("LR")) {
				lValidExportStatus.add("LRC");
				lValidExportStatus.add("LRS");
				lValidExportStatus.add("LRS+LRC");
				lValidExportStatus.add("LRC+LRJ");
				lValidExportStatus.add("NLR+LRJ");
				lValidExportStatus.add("NLR");
				lValidExportStatus.add("NSR");
			} else if (sCurrentExportStatus.equalsIgnoreCase("NSR")) {
				lValidExportStatus.add("NSR");
			}
		}
		if (sNewExportStatus != null) {
			if (lValidExportStatus.contains(sNewExportStatus)) {
				bCanClassify = true;
			}
		}

		return bCanClassify;
		// end adding
	}// end canClassify

	/**
	 * @return HashMap
	 * @throws Exception
	 */
	private HashMap getClassificationCodeList() throws Exception {
		GEAEResultSet geaeResultSet = null;
		HashMap ectCodesHashMap = null;
		Iterator<Map.Entry<String, GEAEResultSet>> entryList = null;
		Map.Entry<String, GEAEResultSet> entry = null;
		String key = null;
		String ectCode = null;
		String ectType = null;
		HashMap mapCodes = new HashMap();

		if (classificationCodeList == null) {
			try {
				ectCodesHashMap = getClassificationList();
				if (ectCodesHashMap != null) {
					entryList = ectCodesHashMap.entrySet().iterator();
				}
			} catch (Exception e) {
				logger.error("Exception in ExportControlDao[getClassificationCodeList] :::" + e);
				throw e;
			}
			if (entryList != null) {
				logger.debug("getting classificationCodeList...");

				while (entryList.hasNext()) {
					entry = entryList.next();
					key = entry.getKey();

					if (key.equals(ECT_STATUS_LRS)) {
						/* get the result set and sort it */
						geaeResultSet = entry.getValue();
						geaeResultSet.sort(ECT_COL_CODE, true);

						while (geaeResultSet.next()) {
							ectCode = geaeResultSet.getString(ECT_COL_CODE);
							ectType = geaeResultSet.getString(ECT_COL_TYPE);

							if (ectType.equals(ECT_TYPE_USML)) {
								if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
									mapCodes.put(ectCode, key);
								}
							}
						}
					}

					if (key.equals(ECT_STATUS_LRC)) {
						/* get the result set and sort it */
						geaeResultSet = entry.getValue();
						geaeResultSet.sort(ECT_COL_CODE, true);

						while (geaeResultSet.next()) {
							ectCode = geaeResultSet.getString(ECT_COL_CODE);
							ectType = geaeResultSet.getString(ECT_COL_TYPE);

							if (ectType.equals(ECT_TYPE_ECCN)) {
								if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
									mapCodes.put(ectCode, key);
								}
							}
						}
					}

					if (key.equals(ECT_STATUS_NLR)) {
						/* get the result set and sort it */
						geaeResultSet = entry.getValue();
						geaeResultSet.sort(ECT_COL_CODE, true);

						while (geaeResultSet.next()) {
							ectCode = geaeResultSet.getString(ECT_COL_CODE);
							ectType = geaeResultSet.getString(ECT_COL_TYPE);

							if (ectType.equals(ECT_TYPE_ECCN)) {
								if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
									mapCodes.put(ectCode, key);
								}
							}
						}
					}

					if (key.equals(ECT_STATUS_DNE)) {
						/* get the result set and sort it */
						geaeResultSet = entry.getValue();
						geaeResultSet.sort(ECT_COL_CODE, true);

						while (geaeResultSet.next()) {
							ectCode = geaeResultSet.getString(ECT_COL_CODE);
							ectType = geaeResultSet.getString(ECT_COL_TYPE);

							if (ectType.equals(ECT_TYPE_DNE_REASON)) {
								if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
									mapCodes.put(ectCode, key);
								}
							}
						}
					}

					if (key.equals(ECT_STATUS_NSR)) {
						/* get the result set and sort it */
						geaeResultSet = entry.getValue();
						geaeResultSet.sort(ECT_COL_CODE, true);

						while (geaeResultSet.next()) {
							ectCode = geaeResultSet.getString(ECT_COL_CODE);
							ectType = geaeResultSet.getString(ECT_COL_TYPE);

							// if (ectType.equals(ECT_TYPE_NSR_EAR_REASON) ||
							// ectType.equals(ECT_TYPE_NSR_ITAR_REASON))
							// {
							if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
								mapCodes.put(ectCode, key);
							}
							// }
						}
					}

				}
			}
			classificationCodeList = mapCodes;
		}

		logger.debug("classificationCodeList: " + classificationCodeList);
		return classificationCodeList;
	} // end getClassificationCodeList

	/**
	 * Get the export status for a specific classification code
	 * 
	 * @param code
	 *            Classification code The wizard interface must pass in a class
	 *            code of 'LRJ' if user answers yes to GE Honda Program
	 *            question. The returned Export status for this case would also
	 *            be the passed in value 'LRJ'.
	 * @return Export status
	 * @throws Exception
	 */
	public String getExportStatus(String sCode) throws Exception {
		String status = null;

		try {
			if (sCode.equals("LRJ")) {
				status = sCode;
			} else {
				HashMap hm = getClassificationCodeList();
				status = (String) hm.get(sCode);
			}
		} catch (Exception e) {
			
			logger.error("Exception in ExportControlDao[getExportStatus] :::" + e);
			throw e;
		}

		return status;
	}

	/**
	 * Get the aggregated export status for a list of classification codes
	 * 
	 * @param codes
	 *            List of classification codes
	 * @return Aggregated export status
	 * @throws Exception
	 */
	public String getExportStatus(String[] codes) throws Exception {
		String status = null;
		try {
			for (int i = 0; i < codes.length; i++) {
				String str = "";
				if (codes[i] != null) {
					str = getExportStatus(codes[i]);
				}
				if (str.equals("DNE")) {
					status = "DNE";
					break;
				} else if (str.equals("LRS")) {
					if (status != null && (status.equals("LRC") || status.equals("LRS+LRC"))) {
						status = "LRS+LRC";
					} else {
						status = "LRS";
					}
				} else if (str.equals("LRC")) {
					if (status != null && (status.equals("LRS") || status.equals("LRS+LRC"))) {
						status = "LRS+LRC";
					} else if (status != null && (status.equals("LRJ"))) {
						status = "LRC+LRJ";
					} else if (status != null && (status.equals("LRC+LRJ"))) {
						status = "LRC+LRJ";
					} else if (status != null && (status.equals("NLR+LRJ"))) {
						status = "LRC+LRJ";
					} else {
						status = "LRC";
					}
				} else if (str.equals("NLR")) {
					if (status != null && (status.equals("LRJ"))) {
						status = "NLR+LRJ";
					} else if (status != null && (status.equals("NLR+LRJ"))) {
						status = "NLR+LRJ";
					} else if (status == null) {
						status = "NLR";
					} else if (status.equals("NSR")) {
						status = "NLR";
					}
				} else if (str.equals("LRJ")) {
					if (status != null && (status.equals("LRC") || status.equals("NLR"))) {
						status = status + "+LRJ";
					} else if (status != null && (status.equals("NSR"))) {
						status = "NSR";
					} else {
						status = "LRJ";
					}
				} else if (str.equals("NSR")) {
					if (status != null && (status.equals("LRC"))) {
						status = "LRC";
					} else if (status != null && (status.equals("LRS"))) {
						status = "LRS";
					} else if (status != null && (status.equals("NLR"))) {
						status = "NLR";
					} else {
						status = "NSR";
					}
				} else {
					status = "UNK";
				}
			}
		} catch (Exception e) {
			
			logger.error("Exception in ExportControlDao[getExportStatus] :::" + e);
			throw e;
		}

		return status;
	} // end getExportStatus

	// setExportControlData updates the export controled object if object is
	// present
	/**
	 * @param args
	 * @return Boolean
	 * @throws Exception
	 */
	public Boolean setExportControlData(String appId, String appType, String[] args) throws Exception {
		String objectId = args[0];
		String sDesc = args[1];
		String sStatus = args[2];
		String sUser = args[3];
		String sClassCode = args[4];
		String sRationale = args[5];
		String sCtrlTech = args[6];
		boolean bReturn = false;

		logger.debug("-----------------------------------------------------");
		logger.debug("-----------------------------------------------------");
		logger.debug("setting export status for object " + objectId + "...");
		logger.debug("data for object " + objectId + "...");
		logger.debug("appId: " + appId);
		logger.debug("appType: " + appType);
		logger.debug("Description: " + sDesc);
		logger.debug("Status: " + sStatus);
		logger.debug("User: " + sUser);
		logger.debug("Classification Code: " + sClassCode);
		logger.debug("Rationale: " + sRationale);
		logger.debug("CtrlTechnology: " + sCtrlTech);

		try {
			StringTokenizer idToken = new StringTokenizer(sClassCode, "~");
			ArrayList lClassCode = new ArrayList();
			while (idToken.hasMoreTokens()) {
				lClassCode.add(idToken.nextToken());
			}
			logger.debug("sClassCode:" + sClassCode + ", lClassCode: " + lClassCode);

			bReturn = GEAEExportControlObject.setExpObjectData(appId, appType, objectId, sDesc, sStatus, sUser, lClassCode, sRationale, sCtrlTech);
		} // ends try
		catch (Exception e) {
			logger.error("Exception in ExportControlDao[setExportControlData] ::::::" + e);
			throw e;
		}
		Boolean bol = Boolean.valueOf(bReturn);
		logger.debug("status of setting export status for object " + objectId + ": " + bol);
		
		return bol;
	}// END setExportControlData

	// 8 createExportControlObject to create an exportable object if it is not
	// already created
	/**
	 * @param args
	 * @return Boolean
	 * @throws Exception
	 */
	public Boolean createExportControlObject(String appId, String appType, String[] args) throws Exception {
		String appName = args[0];
		String sDesc = args[1];
		String sStatus = args[2];
		String sFileLocation = args[3];
		String sArchSys = args[4];
		String sArchData = args[5];
		String sUser = args[6];
		String sClassCode = args[7];
		String sRationale = args[8];
		String sCtrlTech = args[9];
		boolean bReturn = false;

		logger.debug("-----------------------------------------------------");
		logger.debug("-----------------------------------------------------");
		logger.debug("setting export status for object " + appName + "...");
		logger.debug("data for object " + appName + "...");
		logger.debug("appId: " + appId);
		logger.debug("appType: " + appType);
		logger.debug("Description: " + sDesc);
		logger.debug("Status: " + sStatus);		
		logger.debug("FileLocation: " + sFileLocation);
		logger.debug("ArchSys: " + sArchSys);
		logger.debug("ArchData: " + sArchData);		
		logger.debug("User: " + sUser);
		logger.debug("Classification Code: " + sClassCode);
		logger.debug("Rationale: " + sRationale);
		logger.debug("CtrlTechnology: " + sCtrlTech);

		
		try {
			StringTokenizer idToken = new StringTokenizer(sClassCode, "~");
			ArrayList lClassCode = new ArrayList();
			while (idToken.hasMoreTokens()) {
				lClassCode.add(idToken.nextToken());
			}
			logger.debug("sClassCode:" + sClassCode + ", lClassCode: " + lClassCode);
			
			bReturn = GEAEExportControlObject.createExportableObject(appId, appType, appName, sDesc, sStatus, sFileLocation, sArchSys, sArchData, sUser, lClassCode, sRationale, sCtrlTech);
		} // ends try
		catch (Exception e) {
			bReturn = false;
			logger.error("Exception in ExportControlDao[createExportControlObject] ::::::" + e);
			throw e;
		}
		logger.debug("status of setting export status for object " + appName + ": " + bReturn);
		return bReturn;
	}// END createExportControlObject

	/**
	 * @return HashMap
	 * @throws Exception
	 */
	public static HashMap getClassificationList() throws Exception {
		HashMap ectCodesHashMap = null;
		if (classificationList == null) {
			/*******************************************************************
			 * get ECT classification codes
			 ******************************************************************/
			try {
				logger.debug("getting classificationList...");
				ectCodesHashMap = GEAEExportControlObject.getClassificationList();
			} catch (GEAEECTException e) {
				logger.error("Exception in ExportControlDao[getClassificationList] :::" + e);
				throw e;
			}
			classificationList = ectCodesHashMap;
		}

		logger.debug("classificationList: " + classificationList);
		return classificationList;
	} // end getClassificationList

	/**
	 * Get the classification codes
	 * 
	 * @param sBeginsWith -
	 *            1st value in String array. All returned class codes must begin
	 *            with this value
	 * @param String
	 *            array of Export staus values for which class codes are sought
	 * 
	 * @return Classification codes that begin with the value passed in
	 *         sBeginsWith
	 * @throws Exception
	 */
	public static List<String> getClassificationCodesByStatus(String[] args) throws Exception {
		String sBeginsWith = args[0];
		List<String> sCodeValues = new ArrayList<String>();
		HashMap ectCodesHashMap = null;
		String ectCode = null;
		String ectType = null;

		GEAEResultSet geaeResultSet = null;

		ectCodesHashMap = getClassificationList();
		for (int i = 1; i < args.length; i++) {
			try {
				/* get the result set and sort it */
				geaeResultSet = (GEAEResultSet) ectCodesHashMap.get(args[i]);
				geaeResultSet.sort(ECT_COL_CODE, true);

				while (geaeResultSet.next()) {
					ectCode = geaeResultSet.getString(ECT_COL_CODE);
					ectType = geaeResultSet.getString(ECT_COL_TYPE);
					if (ectType.equals(ECT_TYPE_NSR_EAR_REASON) || ectType.equals(ECT_TYPE_NSR_ITAR_REASON) || ectType.equals(ECT_TYPE_ECCN) || ectType.equals(ECT_TYPE_USML) || ectType.equals(ECT_TYPE_DNE_REASON)) {
						if (!ectCode.equals(ECT_CODE_GEAE_CTRL_TECH)) {
							if (sBeginsWith.equalsIgnoreCase("ALL")) {
								sCodeValues.add(ectCode);
							} else if (ectType.equals(ECT_TYPE_NSR_EAR_REASON) && sBeginsWith.equalsIgnoreCase("ALLEAR") && ectCode.indexOf("EAR") != -1) {
								sCodeValues.add(ectCode);
							} else if (ectType.equals(ECT_TYPE_NSR_ITAR_REASON) && sBeginsWith.equalsIgnoreCase("ALLITAR") && ectCode.indexOf("ITAR") != -1) {
								sCodeValues.add(ectCode);
							} else if (ectCode.startsWith(sBeginsWith)) {
								sCodeValues.add(ectCode);
							}
						}
					}
				}
			} catch (Exception e) {
				logger.error("Exception in ExportControlDao[getClassificationCodesByStatus] :::" + e);
				throw e;
			}
		}

		return sCodeValues;
	}// end getClassificationCodesByStatus

	/**
	 * @param args
	 * @return ArrayList
	 * @throws Exception
	 */
	public ArrayList<String> verifyStatus(String[] args, List<String[]> objArgs) throws Exception {
		String sNewStatus = args[0];
		String sAppType = args[2];
		String sAppId = args[1];
		ArrayList<String> slInvalidStatus = new ArrayList<String>();
		for (int i = 0; i < objArgs.size(); i++) {
			try {
				String sObjectId = objArgs.get(i)[0];
				String sCurrentStatus = objArgs.get(i)[1];
				if (sCurrentStatus.equals("UNK")) {
					GEAEResultSet expobject = GEAEExportControlObject.queryNewChangesToExpObject(sAppId, sAppType, sObjectId);
					ArrayList<String> list = new ArrayList<String>();
					if (expobject != null) {
						while (expobject.next()) {
							String statusE = (expobject.getString(3)).trim().toUpperCase(Locale.US);
							if (statusE != null && !statusE.equals("")) {
								if (!list.contains(statusE)) {
									list.add(statusE);
								}
							}
						}
					}

					logger.info("Object [" + sObjectId + "] was previously tagged with " + list.size() + " tags [" + list.toString() + "].");

					int size = list.size();
					if (size == 1 && list.get(0).equals("UNK")) {
						//;
					} else if (size == 0) {
						//;
					} else if (size == 2) {
						String status1 = list.get(0);
						String status2 = list.get(1);
						String nonUnk = status2;

						if (nonUnk.equalsIgnoreCase("UNK")) {
							nonUnk = status1;
						}
						if (nonUnk.equalsIgnoreCase("NLR")) {
							if (sNewStatus.equals("NSR") || sNewStatus.equals("NLR") || sNewStatus.equals("NLR+LRJ")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}

						} else if (nonUnk.equalsIgnoreCase("NLR+LRJ")) {
							if (sNewStatus.equals("NLR+LRJ")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}

						} else if (nonUnk.equalsIgnoreCase("LRC")) {
							if (sNewStatus.equals("LRC") || sNewStatus.equals("NLR") || sNewStatus.equals("NSR") || sNewStatus.equals("LRC+LRJ") || sNewStatus.equals("NLR+LRJ")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}

						} else if (nonUnk.equalsIgnoreCase("LRC+LRJ")) {
							if (sNewStatus.equals("NLR+LRJ") || sNewStatus.equals("LRC+LRJ")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}

						} else if (nonUnk.equalsIgnoreCase("LRS")) {
							if (sNewStatus.equals("NSR") || sNewStatus.equals("NLR") || sNewStatus.equals("NLR+LRJ") || sNewStatus.equals("LRS")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}
						} else if (nonUnk.equalsIgnoreCase("LRS+LRC")) {
							if (sNewStatus.equals("NSR") || sNewStatus.equals("NLR") || sNewStatus.equals("NLR+LRJ") || sNewStatus.equals("LRS+LRC")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}
						} else if (nonUnk.equalsIgnoreCase("DNE")) {
							if (sNewStatus.equals("DNE")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}
						} else if (nonUnk.equalsIgnoreCase("LR")) {
							if (sNewStatus.equals("LRC") || sNewStatus.equals("LRS") || sNewStatus.equals("LRS+LRC") || sNewStatus.equals("LRC+LRJ") || sNewStatus.equals("NLR+LRJ") || sNewStatus.equals("NLR") || sNewStatus.equals("NSR")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}

						} else if (nonUnk.equalsIgnoreCase("NSR")) {
							if (sNewStatus.equals("NSR")) {
								;
							} else {
								slInvalidStatus.add(sObjectId);
							}
						} else {
							slInvalidStatus.add(sObjectId);
						}
					} else {
						slInvalidStatus.add(sObjectId);
					}
					// end adding by Hanping
				} else if (canClassify(sCurrentStatus, sNewStatus)) {
					; // add by Hanping
				} else {
					slInvalidStatus.add(sObjectId);
				}
			} catch (Exception e) {
				logger.error("Exception in ExportControlDao[verifyStatus] :::" + e);
				throw e;
			}
		}
		return slInvalidStatus;
	}// end verifyStatus

}// end class
