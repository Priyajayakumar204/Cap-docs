/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

public class CtrlTechQuestionVO extends BaseSTWVO {
	private boolean aeControlTechEnabled = true;
	private String aeControlTechnology = null;

	private boolean geHondaEnabled = false;
	private String geHondaAeroTech = null;
	
	

	public boolean isAeControlTechEnabled() {
		return aeControlTechEnabled;
	}

	public void setAeControlTechEnabled(boolean aeControlTechEnabled) {
		this.aeControlTechEnabled = aeControlTechEnabled;
	}

	public boolean isGeHondaEnabled() {
		return geHondaEnabled;
	}

	public void setGeHondaEnabled(boolean geHondaEnabled) {
		this.geHondaEnabled = geHondaEnabled;
	}

	public String getGeHondaAeroTech() {
		return geHondaAeroTech;
	}

	public void setGeHondaAeroTech(String geHondaAeroTech) {
		this.geHondaAeroTech = geHondaAeroTech;
	}

	public String getAeControlTechnology() {
		return aeControlTechnology;
	}
	
	public void setAeControlTechnology(String aeControlTechnology) {
		this.aeControlTechnology = aeControlTechnology;
	}
}
