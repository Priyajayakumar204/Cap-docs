/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import java.util.ArrayList;
import java.util.List;

public class EARQuestionVO extends BaseSTWVO {
	private boolean boolEAREnabled = false;
	private String subjectToEar = null;

	private boolean boolITCApprovalEnabled = false;
	private boolean boolITCApproval = false;

	private String selEARReason = null;
	private boolean selEARReasonEnabled = false;
	
	private int selECCNIndex = -1;
	private boolean selECCNEnabled = false;
	
	private List<String> availableECCNValues = new ArrayList<String>();
	private List<String> selectedECCNValues = new ArrayList<String>();
	
	public String getSelEARReason() {
		return selEARReason;
	}

	public void setSelEARReason(String selEARReason) {
		this.selEARReason = selEARReason;
	}
	
	public int getSelECCNIndex() {
		return selECCNIndex;
	}

	public void setSelECCNIndex(int selECCNIndex) {
		this.selECCNIndex = selECCNIndex;
	}
	
	public boolean isBoolEAREnabled() {
		return boolEAREnabled;
	}

	public void setBoolEAREnabled(boolean enabled) {
		boolEAREnabled = enabled;
	}

	public String getSubjectToEar() {
		return subjectToEar;
	}

	public void setSubjectToEar(String subjectToEar) {
		this.subjectToEar = subjectToEar;
	}

	public boolean isBoolITCApprovalEnabled() {
		return boolITCApprovalEnabled;
	}

	public void setBoolITCApprovalEnabled(boolean approvalEnabled) {
		boolITCApprovalEnabled = approvalEnabled;
	}

	public boolean isBoolITCApproval() {
		return boolITCApproval;
	}

	public void setBoolITCApproval(boolean approval) {
		boolITCApproval = approval;
	}

	public boolean isSelEARReasonEnabled() {
		return selEARReasonEnabled;
	}

	public void setSelEARReasonEnabled(boolean selEARReasonEnabled) {
		this.selEARReasonEnabled = selEARReasonEnabled;
	}

	public boolean isSelECCNEnabled() {
		return selECCNEnabled;
	}

	public void setSelECCNEnabled(boolean selECCNEnabled) {
		this.selECCNEnabled = selECCNEnabled;
	}

	public List<String> getAvailableECCNValues() {
		return availableECCNValues;
	}

	public void setAvailableECCNValues(List<String> availableECCNValues) {
		this.availableECCNValues = availableECCNValues;
	}

	public List<String> getSelectedECCNValues() {
		return selectedECCNValues;
	}

	public void setSelectedECCNValues(List<String> selectedECCNValues) {
		this.selectedECCNValues = selectedECCNValues;
	}
}
