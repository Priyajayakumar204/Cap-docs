/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.spring;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringApplicationContextProvider implements ApplicationContextAware {
	private Logger log = Logger.getLogger(SpringApplicationContextProvider.class);

	public void setApplicationContext(ApplicationContext ctx) throws BeansException {
		// Wiring the ApplicationContext into a static method
		SpringApplicationContext.setApplicationContext(ctx);
		log.debug("Spring application context has been set.");
	}
}
