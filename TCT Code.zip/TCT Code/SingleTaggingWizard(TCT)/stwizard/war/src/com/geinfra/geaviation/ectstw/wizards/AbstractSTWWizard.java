/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.wizards;

import com.geinfra.geaviation.ectstw.common.STWizardException;
import com.geinfra.geaviation.ectstw.common.bean.BaseDataTableBean;

public abstract class AbstractSTWWizard extends BaseDataTableBean {
	public abstract void init() throws STWizardException;
}
