/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import com.geinfra.geaviation.ectstw.wizards.DWBWizard;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public interface ComponentStatusUpdater {
	public void updateComponentStatus(DWBWizard taggingWizard, String questionKey, String newValue);
}
