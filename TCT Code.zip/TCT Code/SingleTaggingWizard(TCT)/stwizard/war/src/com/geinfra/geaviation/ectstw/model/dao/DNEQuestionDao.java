/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.util.List;

public class DNEQuestionDao extends BaseSTWDao {
	
	public List<String> getDNEReasons() throws Exception {
		String[] values = new String[] { "all", "DNE" };
		List<String> dneReasonList = ExportControlDao.getClassificationCodesByStatus(values);
		return dneReasonList;
	}
}
