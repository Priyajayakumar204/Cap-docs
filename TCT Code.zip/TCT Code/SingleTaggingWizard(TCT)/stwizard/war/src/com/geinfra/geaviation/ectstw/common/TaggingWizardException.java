/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class TaggingWizardException extends RuntimeException {
	private final static long serialVersionUID = 1401239315392646206L;

	public TaggingWizardException(String msg) {
		super(msg);
	}

	public TaggingWizardException(Throwable exp) {
		super(exp);
	}

	public TaggingWizardException(String msg, Throwable exp) {
		super(msg, exp);
	}
}
