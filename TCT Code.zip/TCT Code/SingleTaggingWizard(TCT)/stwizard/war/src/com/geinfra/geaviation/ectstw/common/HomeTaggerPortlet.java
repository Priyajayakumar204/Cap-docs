/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common;

import geae.exception.dao.GEAESQLException;
import geae.export.ect.GEAEECTException;
import geae.export.ect.GEAEECTNoPrivilegeException;
import geae.export.ect.GEAEExportControlObject;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSecurityException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.bean.STWTagRequestBean;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class HomeTaggerPortlet extends GenericPortlet {
	private Logger logger = Logger.getLogger(HomeTaggerPortlet.class);

	@Override
	public void render(RenderRequest request, RenderResponse response) throws PortletException, PortletSecurityException, IOException {
		logger.debug("--------------------------------------------------------------------------------------");
		logger.debug("HomeTaggerPortlet called: method render...");
		boolean passed = false;

		STWTagRequestBean stwTagRequestBean = STWTagRequestBean.readData(request.getRemoteUser());

		//request.getPortletSession().setAttribute("RESET_VIEW", Boolean.TRUE, 1);
		
		if(stwTagRequestBean == null) {
			stwTagRequestBean = (STWTagRequestBean) request.getPortletSession().getAttribute(TaggingWizardConstants.ECT_OBJECTS_DATA, 1);
		} else if(request.getPortletSession().getAttribute(TaggingWizardConstants.ECT_VALID_TAGGER, 1) != null) {
			logger.debug("new export control object data was passed. so, resetting application state...");
			request.getPortletSession().invalidate();
			request.getPortletSession();
		}	
		
		if ((stwTagRequestBean == null || stwTagRequestBean.getStwTAGRequestList().size() == 0)) {
			response.setContentType("text/html");
			response.setTitle(getTitle(request));
			response.getWriter().write("<br /><span class=\"Error\">" + ResourceFactory.getInstance().getTextMsg("DATA_NOT_FOUND") + "</span>");
			return;
		}
		
		String appId = stwTagRequestBean.getSrcAppId();
		String appType = stwTagRequestBean.getSrcAppType();

		try {
			passed = checkSecurity(request, appId, appType);
		} catch (STWizardException ex) {
			logger.error(ex.toString());
			response.setContentType("text/html");
			response.setTitle(getTitle(request));
			response.getWriter().write("<br/><span class=\"Error\">" + ex.getMessage() + "</span>");
			return;
		}

		if (passed) {
			request.getPortletSession().setAttribute(TaggingWizardConstants.ECT_OBJECTS_DATA, stwTagRequestBean, 1);
			request.getPortletSession().setAttribute(TaggingWizardConstants.ECT_APP_ID, appId, 1);
			request.getPortletSession().setAttribute(TaggingWizardConstants.ECT_APP_TYPE, appType, 1);

			response.setContentType("text/html");
			response.setTitle(getTitle(request));
			response.getWriter().write(ResourceFactory.getInstance().getAppProperty("TAGGER_WINDOW_REDIRECT_HTML_CODE"));
		} else {
			response.setContentType("text/html");
			response.setTitle(getTitle(request));
			response.getWriter().write(ResourceFactory.getInstance().getTextMsg("NOT_VALID_TAGGER_MESSAGE"));
		}
	}

	@Override
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, PortletSecurityException, IOException {
		logger.debug("--------------------------------------------------------------------------------------");
		logger.debug("HomeTaggerPortlet called: method processAction...");
	}

	private boolean checkSecurity(PortletRequest request, String appId, String appType) throws STWizardException {
		boolean passed = false;

		Map userInfo = (Map) request.getAttribute(PortletRequest.USER_INFO);
		String altuid = (String) userInfo.get("user.altuid");
		altuid = altuid == null? null : altuid.toLowerCase(Locale.US);
		
		logger.info("User NTid:" + altuid);
		
		try {
			passed = GEAEExportControlObject.checkValidTagger(altuid, appId, appType);
		} catch (GEAEECTNoPrivilegeException exp) {
			TaggingWizardUtil.printException(exp);
			throw new STWizardException(exp.getMessage(), exp);
		} catch (GEAEECTException exp) {
			TaggingWizardUtil.printException(exp);
			throw new STWizardException(ResourceFactory.getInstance().getTextMsg("NOT_VALID_TAGGER_ERROR_MESSAGE"), exp);
		} catch (GEAESQLException exp) {
			TaggingWizardUtil.printException(exp);
			throw new STWizardException(ResourceFactory.getInstance().getTextMsg("NOT_VALID_TAGGER_ERROR_MESSAGE"), exp);
		} 

		request.getPortletSession().setAttribute(TaggingWizardConstants.ECT_VALID_TAGGER, passed, 1);

		return passed;
	}
}
