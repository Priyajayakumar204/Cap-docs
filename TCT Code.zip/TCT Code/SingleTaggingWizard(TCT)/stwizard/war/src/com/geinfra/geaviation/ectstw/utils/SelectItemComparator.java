/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

import java.io.Serializable;
import java.util.Comparator;

import javax.faces.model.SelectItem;

public class SelectItemComparator implements Comparator<SelectItem>, Serializable {
	private final static long serialVersionUID = -6593092561279012903L;

	public int compare(SelectItem arg0, SelectItem arg1) {
		String val0 = (String)arg0.getValue();
		String val1 = (String)arg1.getValue();
		
		return val0.compareTo(val1);
	}
}
