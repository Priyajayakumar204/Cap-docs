/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import java.util.Map;

import com.geinfra.geaviation.ectstw.data.JurisdictionQuestionVO;
import com.geinfra.geaviation.ectstw.service.JurisdictionQuestionService;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class JurisdictionQuestionBean extends AbstractQuestionBean {
	private JurisdictionQuestionVO jurisdictionQuestionVO = null;
	private JurisdictionQuestionService jurisdictionQuestionService = null;
	
	public JurisdictionQuestionVO getJurisdictionQuestionVO() {
		return jurisdictionQuestionVO;
	}

	public void setJurisdictionQuestionVO(JurisdictionQuestionVO jurisdictionQuestionVO) {
		this.jurisdictionQuestionVO = jurisdictionQuestionVO;
	}

	public JurisdictionQuestionService getJurisdictionQuestionService() {
		return jurisdictionQuestionService;
	}

	public void setJurisdictionQuestionService(JurisdictionQuestionService jurisdictionQuestionService) {
		this.jurisdictionQuestionService = jurisdictionQuestionService;
	}
	
	public Map getComponentStatusMap(Map compStatusMap){
		return jurisdictionQuestionService.validate(compStatusMap);
	}
}
