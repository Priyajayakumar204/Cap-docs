/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class RationaleVO extends BaseSTWVO {
	String rationalText;

	public String getRationalText() {
		return rationalText;
	}

	public void setRationalText(String rationalText) {
		/*
		if(TaggingWizardUtil.isSpecialCharacter(rationalText)){
			TaggingWizardUtil.addMessage("Speacial characters are not allowed.");
			return;
		}
		*/
		this.rationalText = rationalText;
	}
}
