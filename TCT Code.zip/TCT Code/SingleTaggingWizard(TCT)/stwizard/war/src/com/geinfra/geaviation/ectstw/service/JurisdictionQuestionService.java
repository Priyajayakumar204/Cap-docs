/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.JurusductionQuestionDao;

public class JurisdictionQuestionService extends BaseSTWService {
	private JurusductionQuestionDao jurusductionQuestionDao;

	public JurusductionQuestionDao getJurusductionQuestionDao() {
		return jurusductionQuestionDao;
	}

	public void setJurusductionQuestionDao(JurusductionQuestionDao jurusductionQuestionDao) {
		this.jurusductionQuestionDao = jurusductionQuestionDao;
	} 
	
	public Map validate(Map compStatusMap){
		return getTagRulesService().validateJurusdictionQues(compStatusMap);
	}
}
