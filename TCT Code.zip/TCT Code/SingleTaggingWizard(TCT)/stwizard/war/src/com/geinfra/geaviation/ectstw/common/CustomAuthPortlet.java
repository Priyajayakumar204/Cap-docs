/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletSecurityException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.faces.GenericFacesPortlet;

import org.apache.log4j.Logger;

import com.ge.portal.faces.model.ErrorMessageInfo;
import com.geinfra.geaviation.ectstw.common.bean.CustomMessageHandler;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class CustomAuthPortlet extends GenericFacesPortlet {
	private Logger logger = Logger.getLogger(CustomAuthPortlet.class);

	@Override
	public void render(RenderRequest request, RenderResponse response) throws PortletException, PortletSecurityException, IOException {
		logger.debug("--------------------------------------------------------------------------------------");
		logger.debug("CustomAuthPortlet called: method render...");

		Boolean isValidTagger = (Boolean) request.getPortletSession().getAttribute(TaggingWizardConstants.ECT_VALID_TAGGER, 1);

		if (isValidTagger == null) {
			writeText(request, response, ResourceFactory.getInstance().getTextMsg("DIRECT_ACCESS_DENIED_MEASSAGE"));
			return;
		} else if (!isValidTagger) {
			writeText(request, response, ResourceFactory.getInstance().getTextMsg("NOT_VALID_TAGGER_MESSAGE"));
			return;
		}

		try {
			super.render(request, response);
		} catch (Exception ex) {
			TaggingWizardUtil.printException(ex);
			TaggingWizardUtil.printExceptionTrack(ex);
			response.resetBuffer();

			CustomMessageHandler customMessageHandler = (CustomMessageHandler) request.getAttribute(TaggingWizardConstants.CUSTOM_MSG_LIST_KEY);
			if (customMessageHandler != null) {
				List<ErrorMessageInfo> errorList = customMessageHandler.getErrorMessages();
				if (errorList.size() != 0) {
					writeText(request, response, "<br /><span class=\"Error\">" + errorList.get(0).getMessage() + "</span>");
				}
			} else {
				writeText(request, response, ResourceFactory.getInstance().getTextMsg("ERROR_COMMON_MEASSAGE"));
			}
		}
	}

	@Override
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, PortletSecurityException, IOException {
		logger.debug("--------------------------------------------------------------------------------------");
		logger.debug("CustomAuthPortlet called: method processAction...");

		Boolean isValidTagger = (Boolean) request.getPortletSession().getAttribute(TaggingWizardConstants.ECT_VALID_TAGGER, 1);
		if (isValidTagger == null || !isValidTagger) {
			return;
		}

		super.processAction(request, response);
	}

	private void writeText(RenderRequest request, RenderResponse response, String text) throws IOException {
		response.setContentType("text/html");
		response.setTitle(getTitle(request));
		response.getWriter().write(text);
	}
}
