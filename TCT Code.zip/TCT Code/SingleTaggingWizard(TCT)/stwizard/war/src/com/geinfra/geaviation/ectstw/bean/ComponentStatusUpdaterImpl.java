/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.common.TaggingWizardException;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;
import com.geinfra.geaviation.ectstw.wizards.DWBWizard;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class ComponentStatusUpdaterImpl implements ComponentStatusUpdater {
	private static Logger logger = Logger.getLogger(ComponentStatusUpdaterImpl.class);
	public ComponentStatusUpdaterImpl() {
		logger.debug("ComponentStatusUpdaterImpl Created: " + this);
	}

	public void updateComponentStatus(DWBWizard taggingWizard, String questionKey, String newValue) {
		try {
			if (TaggingWizardConstants.DNE_QUESTION.equals(questionKey)) {
				if (TaggingWizardConstants.YES.equals(newValue)) {
					//DNE
					taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelected(true);
					taggingWizard.getDneQuestionBean().getDneQuestionVO().setReasonEnabled(true);
				} else if (TaggingWizardConstants.NO.equals(newValue)) {
					taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelected(false);
					taggingWizard.getDneQuestionBean().getDneQuestionVO().setReasonEnabled(false);

					taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setAeControlTechnology(null);
				} else {
					throw new TaggingWizardException("'" + newValue + "' was not a valid value for DNE question.");
				}
				//DNE
				taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelDNEReason(null);

				reSetCtrlTechQuestion(taggingWizard.getCtrlTechQuestionBean(), false);
				reSetJurisdictionQuestion(taggingWizard.getJurisdictionQuestionBean());
				reSetITARQuestion(taggingWizard.getItarQuestionBean(), false);
				reSetEARQuestion(taggingWizard.getEarQuestionBean(), false);
			} else if (TaggingWizardConstants.AE_CONTROL_TECH_QUESTION.equals(questionKey)) {
				taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setAeControlTechnology(newValue);

				if (!taggingWizard.getDneQuestionBean().getDneQuestionVO().isSelected()) {
					taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setGeHondaEnabled(true);
				}
			} else if (TaggingWizardConstants.HONDA_QUESTION.equals(questionKey)) {
				taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setGeHondaAeroTech(newValue);

				reSetJurisdictionQuestion(taggingWizard.getJurisdictionQuestionBean());
				if (TaggingWizardConstants.YES.equals(newValue)) {
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setCommDeptEnabled(true);
				} else if (TaggingWizardConstants.NO.equals(newValue)) {
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setStateDeptEnabled(true);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setCommDeptEnabled(true);
				} else {
					throw new TaggingWizardException("'" + newValue + "' was not a valid value for Honda question.");
				}

				reSetITARQuestion(taggingWizard.getItarQuestionBean(), false);
				reSetEARQuestion(taggingWizard.getEarQuestionBean(), false);
			} else if (TaggingWizardConstants.JURISDICTION_QUESTION.equals(questionKey)) {
				taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDepartment(newValue);

				if (TaggingWizardConstants.STATE.equals(newValue)) {
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(null);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModelEnabled(true);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(false);
				} else if (TaggingWizardConstants.COMMERCE.equals(newValue)) {
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(null);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModelEnabled(false);
					taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(true);
				}

				reSetITARQuestion(taggingWizard.getItarQuestionBean(), false);
				reSetEARQuestion(taggingWizard.getEarQuestionBean(), false);
			} else if (TaggingWizardConstants.DRAWING_MODEL_QUESTION.equals(questionKey)) {
				taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(newValue);
				taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
				taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(true);

				reSetITARQuestion(taggingWizard.getItarQuestionBean(), false);
				reSetEARQuestion(taggingWizard.getEarQuestionBean(), false);
			} else if (TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION.equals(questionKey)) {
				taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(newValue);
				if (TaggingWizardConstants.STATE.equals(taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().getDepartment())) {
					if (TaggingWizardConstants.YES.equals(taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().getDrawingModel())) {
						taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolEAREnabled(true);
					}
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setBoolITAREnabled(true);
				} else if (TaggingWizardConstants.COMMERCE.equals(taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().getDepartment())) {
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolEAREnabled(true);
				}
			} else if (TaggingWizardConstants.ITAR_QUESTION.equals(questionKey)) {
				taggingWizard.getItarQuestionBean().getItarQuestionVO().setSubjectToITAR(newValue);

				if (TaggingWizardConstants.YES.equals(newValue)) {
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReason(null);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReasonEnabled(false);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLEnabled(true);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLType(null);
				} else if (TaggingWizardConstants.NO.equals(newValue)) {
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReason(null);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReasonEnabled(true);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLEnabled(false);
					taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLType(null);
				} else {
					throw new TaggingWizardException("'" + newValue + "'wasnot a valid value for EAR question.");
				}
			} else if (TaggingWizardConstants.EAR_QUESTION.equals(questionKey)) {
				taggingWizard.getEarQuestionBean().getEarQuestionVO().setSubjectToEar(newValue);

				if (TaggingWizardConstants.YES.equals(newValue)) {
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReason(null);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReasonEnabled(false);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApproval(false);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApprovalEnabled(false);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNEnabled(true);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNIndex(0);
				} else if (TaggingWizardConstants.NO.equals(newValue)) {
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReason(null);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReasonEnabled(true);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApproval(false);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApprovalEnabled(true);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNEnabled(false);
					taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNIndex(0);
				} else {
					throw new TaggingWizardException("'" + newValue + "' was not a valid value for EAR question.");
				}
			}
		} catch (ClassCastException exp) {
			logger.error("ClassCastException:" + exp.getMessage());
			throw exp;
		} 
	}

	private void reSetCtrlTechQuestion(CtrlTechQuestionBean question, boolean enable) {
		question.getCtrlTechQuestionVO().setGeHondaEnabled(enable);
		question.getCtrlTechQuestionVO().setGeHondaAeroTech(null);
	}

	private void reSetJurisdictionQuestion(JurisdictionQuestionBean question) {
		question.getJurisdictionQuestionVO().setDepartment(null);
		question.getJurisdictionQuestionVO().setCommDeptEnabled(false);
		question.getJurisdictionQuestionVO().setStateDeptEnabled(false);
		question.getJurisdictionQuestionVO().setDrawingModel(null);
		question.getJurisdictionQuestionVO().setDrawingModelEnabled(false);
		question.getJurisdictionQuestionVO().setDrawingReviewSpec(null);
		question.getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(false);
	}

	private void reSetITARQuestion(ITARQuestionBean question, boolean enable) {
		question.getItarQuestionVO().setBoolITAREnabled(enable);
		question.getItarQuestionVO().setSubjectToITAR(null);
		question.getItarQuestionVO().setSelITARReason(null);
		question.getItarQuestionVO().setSelITARReasonEnabled(false);
		question.getItarQuestionVO().setSelUSMLEnabled(false);
		question.getItarQuestionVO().setSelUSMLType(null);
	}

	private void reSetEARQuestion(EARQuestionBean question, boolean enable) {
		question.getEarQuestionVO().setBoolEAREnabled(enable);
		question.getEarQuestionVO().setSubjectToEar(null);
		question.getEarQuestionVO().setSelEARReason(null);
		question.getEarQuestionVO().setSelEARReasonEnabled(false);
		question.getEarQuestionVO().setBoolITCApproval(false);
		question.getEarQuestionVO().setBoolITCApprovalEnabled(false);
		question.getEarQuestionVO().setSelECCNIndex(0);
		question.getEarQuestionVO().setSelECCNEnabled(false);
	}
}
