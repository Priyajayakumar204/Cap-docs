/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;


public class BaseSTWService {
	private TagRulesService tagRulesService;

	public TagRulesService getTagRulesService() {
		return tagRulesService;
	}

	public void setTagRulesService(TagRulesService tagRulesService) {
		this.tagRulesService = tagRulesService;
	}
}
