/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.resource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.common.TaggingWizardException;
import com.geinfra.geaviation.ectstw.spring.SpringApplicationContext;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class ResourceFactory {
	private static ResourceFactory instance;

	private ResourceBundle queryBundle;
	private ResourceBundle textMsgBundle;
	private Properties ect_stwProperties;

	private ResourceFactory(String queryResource, String textMsgResource, String ect_stwPropPath) {
		queryBundle = ResourceBundle.getBundle(queryResource);
		textMsgBundle = ResourceBundle.getBundle(textMsgResource);		
		
		InputStream inStream = null;
		
		try {
			inStream = new FileInputStream(ect_stwPropPath);
			ect_stwProperties = new Properties();			
			ect_stwProperties.load(inStream);
		} catch (IOException exp) {
			TaggingWizardUtil.printException(exp);
			Logger.getLogger(ResourceFactory.class).debug("Error: unable to load properties from file " + ect_stwPropPath);
			throw new TaggingWizardException("Error: unable to load properties from file " + ect_stwPropPath, exp);
		} finally {
			if(inStream != null){
				try {
					inStream.close();
				} catch (IOException exp) {
					TaggingWizardUtil.printException(exp);
					Logger.getLogger(ResourceFactory.class).debug("Error: " + exp.getMessage());
				}
			}
		}
	}

	public static ResourceFactory getInstance() {
		if (instance == null) {
			instance = (ResourceFactory) SpringApplicationContext.getApplicationContext().getBean("resourceFactory");
		}

		return instance;
	}
	
	public static ResourceFactory createInstance(String queryResource, String textMsgResource, String ect_stwPropResource) {
		if (instance == null) {
			instance = new ResourceFactory(queryResource, textMsgResource, ect_stwPropResource);
		}

		return instance;
	}

	public String getQuery(String queryId) {
		if (queryBundle == null) {
			return null;
		} else {
			return queryBundle.getString(queryId);
		}
	}

	public String getTextMsg(String msgId) {
		if (textMsgBundle == null) {
			return null;
		} else {
			return textMsgBundle.getString(msgId);
		}
	}
	
	public String getAppProperty(String propId) {
		if (ect_stwProperties == null) {
			return null;
		} else {
			return ect_stwProperties.getProperty(propId);
		}
	}
}
