/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.driver.OracleTypes;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.ectstw.webservice.ECTTagWebService;

public class BaseSTWDao extends SimpleJdbcDaoSupport  {
	private static Logger logger = Logger.getLogger(BaseSTWDao.class);
	private Map<String, List<String>> classificationCodeMap = new HashMap<String, List<String>>();
	
	// NLR, LRS, LRC, DNE
	public List<String> getKeyClassificationList(String statusType) {
		logger.debug("getting classification list for " + statusType + "...");
		
		List<String> classificationList = classificationCodeMap.get(statusType);

		if (classificationList == null) {
			classificationList = getClassificationList(statusType);
			classificationCodeMap.put(statusType, classificationList);
		}

		return classificationList;
	}
	
	@SuppressWarnings ("unchecked")
	private List<String> getClassificationList(final String statusType) {
		List<String> data = (List<String>) getJdbcTemplate().execute(new StmtCreator(statusType), new StmtCallBack());
		return data;
	}
	
	public static class StmtCreator implements CallableStatementCreator {
		String statusType;
		
		StmtCreator(String statusType){
			this.statusType = statusType; 
		}
		
		public CallableStatement createCallableStatement(Connection con) throws SQLException {
			CallableStatement cs = con.prepareCall("{call DST.DST_ECT_MOD.DST_ECT_GETClassification(?, ?)}");
			cs.setString(1, statusType);
			cs.registerOutParameter(2, OracleTypes.CURSOR);

			return cs;
		}
	}
	
	public static class StmtCallBack implements CallableStatementCallback {
		public Object doInCallableStatement(CallableStatement cs) throws DataAccessException, SQLException {
			List<String> result = new ArrayList<String>();
			ResultSet reSet = null;
			
			try {
				cs.execute();
				reSet = (ResultSet) cs.getObject(2);
				while (reSet.next()) {
					result.add(reSet.getString(1));
				}
			} finally {
				if(reSet != null){
					reSet.close();	
				}
			}
						
			return result;
		}
	}
}
