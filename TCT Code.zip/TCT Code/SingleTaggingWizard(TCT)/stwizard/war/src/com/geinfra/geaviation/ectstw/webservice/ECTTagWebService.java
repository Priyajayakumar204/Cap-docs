/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.webservice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.bean.STWTagRequestBean;
import com.geinfra.geaviation.ectstw.common.DataValidationException;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

@Path("/ect-stw")
public class ECTTagWebService {
	private static Logger logger = Logger.getLogger(ECTTagWebService.class);

	@Context
	HttpServletResponse response;

	@Context
	HttpServletRequest request;
	
	public ECTTagWebService() {
		response = null;
		request = null;
	}

	@POST
	@Path("/classify")
	public String doClassify(MultivaluedMap<String, String> form) {
		try {
			String userid = request.getHeader("sm_ssoid");
			String mail = request.getHeader("sm_email");
			String firstName = request.getHeader("sm_first_name");
			String lastName = request.getHeader("sm_last_name");

			if (userid == null || userid.trim().length() == 0) {
				logger.warn("No user information was associated with current request.");
				userid = form.getFirst("user_sso");
				//return "No user information was associated with current request. Please try again with user information.";
			}

			logger.info("Welcome " + lastName + ", " + firstName + " (" + userid + ")." + " Email:" + mail);			
			logger.info("Client: " + request.getHeader("User-Agent"));
			
			String request_type = request.getParameter("client_type");			
			STWTagRequestBean.createSTWTagRequest(form, userid);

			String appHomeUrl = ResourceFactory.getInstance().getAppProperty("APPLICATION_HOME_URL");
			if ("Browser".equalsIgnoreCase(request_type)) {
				response.sendRedirect(appHomeUrl);
			} else {
				return appHomeUrl;
			}
		} catch (DataValidationException ex) {
			TaggingWizardUtil.printException(ex);
			return "Error: " + ex.getMessage();
		} catch (Exception ex) {
			TaggingWizardUtil.printException(ex);
			return "System Error. Please contact administrator.";
		}

		logger.debug("web service completed...");
		return "Please wait. You are been redirected to portal page.";
	}
	
	@GET
	@Path("/classify")
	public String doGetClassify() {		
		logger.debug("Request URI: " + request.getRequestURL());
		logger.debug("Request URI: " + request.getQueryString());
		return "Request was not submitted in proper form. Please try again.";
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
}
