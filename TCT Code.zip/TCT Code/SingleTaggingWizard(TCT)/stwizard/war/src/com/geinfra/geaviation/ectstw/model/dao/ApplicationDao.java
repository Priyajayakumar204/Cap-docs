/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.commons.collections.map.ListOrderedMap;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.ectstw.webservice.ECTTagWebService;

public class ApplicationDao extends SimpleJdbcDaoSupport {
	private static Logger logger = Logger.getLogger(ApplicationDao.class);
	public List getAppIdList() {
		List appIdList = new ArrayList();

		String query = "select distinct Application_Id  from dst_ect_group_app order by Application_Id";

		List result = getJdbcTemplate().queryForList(query);
		logger.debug("List:" + result.size());
		logger.debug("List Item Type:" + result.get(0).getClass().getName());

		for (int i = 0; i < result.size(); i++) {
			ListOrderedMap tempMap = (ListOrderedMap) result.get(i);
			appIdList.add(new SelectItem(tempMap.getValue(0), tempMap.getValue(0).toString()));
		}

		return appIdList;
	}

	public List getAppTypeList() {
		List appTypeList = new ArrayList();

		String query = "select distinct Application_Type from dst_ect_group_app order by Application_Type";

		List result = getJdbcTemplate().queryForList(query);
		logger.debug("List:" + result.size());

		for (int i = 0; i < result.size(); i++) {
			ListOrderedMap tempMap = (ListOrderedMap) result.get(i);
			appTypeList.add(new SelectItem(tempMap.getValue(0), tempMap.getValue(0).toString()));
		}

		return appTypeList;
	}

	public List getAppTypeList(String appId) {
		List appTypeList = new ArrayList();

		String query = "select distinct application_type appType " + "from dst_ect_group_app where substr(Application_Type, 0, instr(application_type, '_') - 1) = '" + appId + "' order by appType";

		List result = getJdbcTemplate().queryForList(query);
		logger.debug("List:" + result.size());

		for (int i = 0; i < result.size(); i++) {
			ListOrderedMap tempMap = (ListOrderedMap) result.get(i);
			appTypeList.add(new SelectItem(tempMap.getValue(0), tempMap.getValue(0).toString()));
		}

		return appTypeList;
	}
}
