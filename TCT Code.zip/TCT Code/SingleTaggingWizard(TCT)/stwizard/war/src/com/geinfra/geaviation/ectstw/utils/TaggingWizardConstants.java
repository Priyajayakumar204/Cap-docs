/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public final class TaggingWizardConstants {
	private TaggingWizardConstants() {
	}
	
	public final static int WRAP_TEXT_LENGTH = 100;

	//Constants
	public final static String CUSTOM_MSG_LIST_KEY = "CUSTOM_MSG_LIST_KEY";
	public final static String EXPORT_QUESTIONS_MAP = "EXPORT_QUESTIONS_MAP";
	
	public final static String ECT_OBJECTS_DATA = "ECT_OBJECTS_DATA";
	public final static String ECT_APP_ID = "ECT_APP_ID";
	public final static String ECT_APP_TYPE = "ECT_APP_TYPE";
	public final static String ECT_VALID_TAGGER = "ECT_VALID_TAGGER";

	//Component Constants
	public final static String DNE_SELECTION_VALUE = "DNE_SELECTION_VALUE";
	public final static String DNE_REASON_ENABLE = "DNE_REASON_ENABLE";	
	public final static String DNE_REASON_VALUE = "DNE_REASON_VALUE";
	
	public final static String CTRL_TECH_VALUE = "CTRL_TECH_VALUE";
	public final static String HONDA_ENABLE = "HONDA_ENABLE";
	public final static String HONDA_VALUE = "HONDA_VALUE";
	
	public final static String JURI_DEPT_VALUE = "JURI_DEPT_VALUE";
	public final static String JURI_COMMERCE_DEPT_ENABLE = "JURI_COMMERCE_DEPT_ENABLE";
	public final static String JURI_STATE_DEPT_ENABLE = "JURI_STATE_DEPT_ENABLE";
	public final static String JURI_DRAWING_MODEL_VALUE = "JURI_DRAWING_MODEL_VALUE";
	public final static String JURI_DRAWING_MODEL_ENABLE = "JURI_DRAWING_MODEL_ENABLE";
	public final static String JURI_RETIONALE_VALUE = "JURI_RETIONALE_VALUE";
	public final static String JURI_REVIEW_SPEC_VALUE = "JURI_REVIEW_SPEC_VALUE";
	public final static String JURI_REVIEW_SPEC_ENABLE = "JURI_REVIEW_SPEC_ENABLE";
	
	public final static String ITAR_SUBJECT_TO_ENABLE = "ITAR_SUBJECT_TO_ENABLE";
	public final static String ITAR_SUBJECT_TO_VALUE = "ITAR_SUBJECT_TO_VALUE";	
	public final static String ITAR_REASON_ENABLE = "ITAR_REASON_ENABLE";
	public final static String ITAR_REASON_VALUE = "ITAR_REASON_VALUE";
	public final static String ITAR_USML_ENABLE = "ITAR_USML_ENABLE";
	public final static String ITAR_USML_VALUE = "ITAR_USML_VALUE";
	
	public final static String EAR_SUBJECT_TO_ENABLE = "EAR_SUBJECT_TO_ENABLE";
	public final static String EAR_SUBJECT_TO_VALUE = "EAR_SUBJECT_TO_VALUE";	
	public final static String EAR_REASON_ENABLE = "EAR_REASON_ENABLE";
	public final static String EAR_REASON_VALUE = "EAR_REASON_VALUE";
	
	public final static String EAR_ITC_APPROVAL_ENABLE = "EAR_ITC_APPROVAL_ENABLE";
	public final static String EAR_ITC_APPROVAL_VALUE = "EAR_ITC_APPROVAL_VALUE";	
	public final static String EAR_ECCN_ENABLE = "EAR_ECCN_ENABLE";
	public final static String EAR_ECCN_VALUE = "EAR_ECCN_VALUE";
	
	
	//Questions Constants
	public final static String QUESTION_KEY = "QUESTION_KEY";
	public final static String DNE_QUESTION = "DNE_QUESTION";
	public final static String AE_CONTROL_TECH_QUESTION = "AE_CONTROL_TECH_QUESTION";
	public final static String HONDA_QUESTION = "HONDA_QUESTION";
	public final static String JURISDICTION_QUESTION = "JURISDICTION_QUESTION";
	public final static String DRAWING_MODEL_QUESTION = "DRAWING_MODEL_QUESTION";
	public final static String DRAWING_REVIEW_SPEC_QUESTION = "DRAWING_REVIEW_SPEC_QUESTION";
	public final static String EAR_QUESTION = "EAR_QUESTION";
	public final static String ITAR_QUESTION = "ITAR_QUESTION";

	public final static String YES = "YES";
	public final static String NO = "NO";
	public final static String NA = "NA";
	public final static String COMMERCE = "COMMERCE";
	public final static String STATE = "STATE";
	public final static String STATE_COMMERCE = "STATE_COMMERCE";
	
	public final static String LRJ = "LRJ";
	public final static String ERROR = "error";
	
	//Messages
	public final static String ERROR_COM_01 = "Error occured. Please contact Administrator";
	
	public final static String DNE_REASON_MSG = "Please select the reason for DNE.";
	public final static String CONTROL_TECH_MSG = "Please answer the GE aviation controlled technology question.";
	public final static String HONDA_AERO_MSG = "Please answer GE-Honda aero engines program question.";
	public final static String IDN_JURD_MSG = "Please select either state or commerce for Identify Jurisdiction.";
	public final static String CO_MINGLE_MSG = "Please answer the co-mingle question.";
	public final static String JURI_RATIONALE_MSG = "Please enter rationale for jurisdiction selection.";
	public final static String JURI_RATIONALE_LEN_MSG = "Please enter rationale less than 255 characters.";
	public final static String DRAWING_REVIEW_SPEC_MSG = "Please answer the drawing review specification question.";
	public final static String ITAR_QUES_MSG = "Please answer the ITAR question.";
	public final static String ITAR_REASON_MSG = "Please select an ITAR reason.";
	public final static String USML_CATEG_MSG = "Please select a USML Category.";
	public final static String EAR_QUES_MSG = "Please answer the EAR question.";
	public final static String EAR_REASON_MSG = "Please select an EAR reason.";
	public final static String ITC_APPROVAL_MSG = "Please select yes for ITC Approval.";
	public final static String ECCN_CAT_MSG = "Please select a ECCN Category.";
	public final static String USML_ECCN_LEN_MSG = "Selected classification code list is very large. Please unselect some classification and try again.";
	public final static String RATIONALE_CHECK_MSG = "Please enter your rationale for your previous determinations.";
	public final static String RATIONALE_LEN_MSG = "Combined text for jurisdiction rationale (previous page) and this rationale should be less than 255 characters.";
}
