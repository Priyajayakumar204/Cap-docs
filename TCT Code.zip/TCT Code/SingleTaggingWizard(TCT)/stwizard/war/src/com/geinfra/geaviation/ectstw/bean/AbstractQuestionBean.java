/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import com.geinfra.geaviation.ectstw.utils.FaceletUIDataConvertor;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public abstract class AbstractQuestionBean {
	protected FaceletUIDataConvertor faceletUtil;

	protected AbstractQuestionBean() {
	}

	public FaceletUIDataConvertor getFaceletUtil() {
		return faceletUtil;
	}

	public void setFaceletUtil(FaceletUIDataConvertor faceletUtil) {
		this.faceletUtil = faceletUtil;
	}
}
