/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.util.Map;

import com.geinfra.geaviation.ectstw.common.TaggingWizardException;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;

@SuppressWarnings("unchecked")
public class TagRulesDao extends BaseSTWDao {
	public Map getDneQuestionRule(Map compStatusMap){
		boolean newValue = (Boolean) compStatusMap.get(TaggingWizardConstants.DNE_SELECTION_VALUE); 	
		
		if (newValue) {
			//DNE
			compStatusMap.put(TaggingWizardConstants.DNE_SELECTION_VALUE, Boolean.TRUE);
			//taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelected(true);
			
			compStatusMap.put(TaggingWizardConstants.DNE_REASON_ENABLE, Boolean.TRUE);
			//taggingWizard.getDneQuestionBean().getDneQuestionVO().setReasonEnabled(true);
		} else {
			compStatusMap.put(TaggingWizardConstants.DNE_SELECTION_VALUE, Boolean.FALSE);
			//taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelected(false);
			
			compStatusMap.put(TaggingWizardConstants.DNE_REASON_ENABLE, Boolean.FALSE);
			//taggingWizard.getDneQuestionBean().getDneQuestionVO().setReasonEnabled(false);

			compStatusMap.put(TaggingWizardConstants.CTRL_TECH_VALUE, null);
			//taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setAeControlTechnology(null);
		} 
		
		//DNE
		compStatusMap.put(TaggingWizardConstants.DNE_REASON_VALUE, null);
		//taggingWizard.getDneQuestionBean().getDneQuestionVO().setSelDNEReason(null);

		reSetCtrlTechQuestion(compStatusMap);
		reSetJurisdictionQuestion(compStatusMap);
		reSetITARQuestion(compStatusMap);
		reSetEARQuestion(compStatusMap);
		
		return compStatusMap;
	}
	
	public Map getCtrlQuestionRules(Map compStatusMap){
		String questionKey = (String) compStatusMap.get(TaggingWizardConstants.QUESTION_KEY);
		
		if (TaggingWizardConstants.AE_CONTROL_TECH_QUESTION.equals(questionKey)) {
			//compStatusMap.put(TaggingWizardConstants.CTRL_TECH_VALUE, newValue);
			//taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setAeControlTechnology(newValue);

			if (!(Boolean)compStatusMap.get(TaggingWizardConstants.DNE_SELECTION_VALUE)) {
				compStatusMap.put(TaggingWizardConstants.HONDA_ENABLE, Boolean.TRUE);
				//taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setGeHondaEnabled(true);
			}
		} else if (TaggingWizardConstants.HONDA_QUESTION.equals(questionKey)) {
			String newValue = (String) compStatusMap.get(TaggingWizardConstants.HONDA_VALUE);
			//taggingWizard.getCtrlTechQuestionBean().getCtrlTechQuestionVO().setGeHondaAeroTech(newValue);

			reSetJurisdictionQuestion(compStatusMap);
			if (TaggingWizardConstants.YES.equals(newValue)) {
				compStatusMap.put(TaggingWizardConstants.JURI_COMMERCE_DEPT_ENABLE, Boolean.TRUE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setCommDeptEnabled(true);
			} else if (TaggingWizardConstants.NO.equals(newValue)) {
				compStatusMap.put(TaggingWizardConstants.JURI_STATE_DEPT_ENABLE, Boolean.TRUE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setStateDeptEnabled(true);
				
				compStatusMap.put(TaggingWizardConstants.JURI_COMMERCE_DEPT_ENABLE, Boolean.TRUE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setCommDeptEnabled(true);
			} else {
				throw new TaggingWizardException("'" + newValue + "' was not a valid value for Honda question.");
			}

			reSetITARQuestion(compStatusMap);
			reSetEARQuestion(compStatusMap);
		}
		
		return compStatusMap;
	}
	
	public Map getJurisdictionQuesRule(Map compStatusMap){
		String questionKey = (String) compStatusMap.get(TaggingWizardConstants.QUESTION_KEY);
		
		if (TaggingWizardConstants.JURISDICTION_QUESTION.equals(questionKey)) {
			String newValue = (String) compStatusMap.get(TaggingWizardConstants.JURI_DEPT_VALUE);
			//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDepartment(newValue);
			
			if (TaggingWizardConstants.STATE.equals(newValue)) {
				compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, null);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(null);
				
				compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_ENABLE, Boolean.TRUE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModelEnabled(true);
				
				compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, null);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
				
				compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE, Boolean.FALSE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(false);
			} else if (TaggingWizardConstants.COMMERCE.equals(newValue)) {
				compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, null);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(null);
				
				compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_ENABLE, Boolean.FALSE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModelEnabled(false);
				
				compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, null);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
				
				compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE, Boolean.TRUE);
				//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(true);
			}

			reSetITARQuestion(compStatusMap);
			reSetEARQuestion(compStatusMap);
		} else if (TaggingWizardConstants.DRAWING_MODEL_QUESTION.equals(questionKey)) {
			//String newValue = (String) compStatusMap.get(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE);			
			//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingModel(newValue);

			compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, null);
			//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(null);
			
			compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE, Boolean.TRUE);
			//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(true);

			reSetITARQuestion(compStatusMap);
			reSetEARQuestion(compStatusMap);
		} else if (TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION.equals(questionKey)) {
			//String newValue = (String) compStatusMap.get(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE);
			//taggingWizard.getJurisdictionQuestionBean().getJurisdictionQuestionVO().setDrawingReviewSpec(newValue);
			
			if (TaggingWizardConstants.STATE.equals(compStatusMap.get(TaggingWizardConstants.JURI_DEPT_VALUE))) {
				if (TaggingWizardConstants.YES.equals(compStatusMap.get(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE))) {
					compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_ENABLE, Boolean.TRUE);		
					//taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolEAREnabled(true);
				}
				compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_ENABLE, Boolean.TRUE);
				//taggingWizard.getItarQuestionBean().getItarQuestionVO().setBoolITAREnabled(true);
			} else if (TaggingWizardConstants.COMMERCE.equals(compStatusMap.get(TaggingWizardConstants.JURI_DEPT_VALUE))) {
				compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_ENABLE, Boolean.TRUE);
				//taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolEAREnabled(true);
			}
		}
		
		return compStatusMap;
	}
	
	public Map getITARQuestionRule(Map compStatusMap){
		String newValue = (String) compStatusMap.get(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE);
		//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSubjectToITAR(newValue);

		if (TaggingWizardConstants.YES.equals(newValue)) {
			compStatusMap.put(TaggingWizardConstants.ITAR_REASON_ENABLE, Boolean.FALSE);
			//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReasonEnabled(false);
			
			compStatusMap.put(TaggingWizardConstants.ITAR_USML_ENABLE, Boolean.TRUE);
			//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLEnabled(true);
			
			
		} else if (TaggingWizardConstants.NO.equals(newValue)) {
			compStatusMap.put(TaggingWizardConstants.ITAR_REASON_ENABLE, Boolean.TRUE);
			//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReasonEnabled(true);
			
			compStatusMap.put(TaggingWizardConstants.ITAR_USML_ENABLE, Boolean.FALSE);
			//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLEnabled(false);
		} else {
			throw new TaggingWizardException("'" + newValue + "' was not a valid value for EAR question.");
		}		
		
		compStatusMap.put(TaggingWizardConstants.ITAR_REASON_VALUE, null);
		//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelITARReason(null);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_USML_VALUE, null);
		//taggingWizard.getItarQuestionBean().getItarQuestionVO().setSelUSMLIndex(0);
		
		return compStatusMap;
	}
	
	public Map getEARQuesRules(Map compStatusMap){
		String newValue = (String) compStatusMap.get(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE);
		//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSubjectToEar(newValue);

		if (TaggingWizardConstants.YES.equals(newValue)) {			
			compStatusMap.put(TaggingWizardConstants.EAR_REASON_ENABLE, Boolean.FALSE);			
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReasonEnabled(false);
		
			compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_ENABLE, Boolean.FALSE);
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApprovalEnabled(false);
			
			compStatusMap.put(TaggingWizardConstants.EAR_ECCN_ENABLE, Boolean.TRUE);
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNEnabled(true);
		
		} else if (TaggingWizardConstants.NO.equals(newValue)) {			
			compStatusMap.put(TaggingWizardConstants.EAR_REASON_ENABLE, Boolean.TRUE);
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReasonEnabled(true);
			
			compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_ENABLE, Boolean.TRUE);
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApprovalEnabled(true);
			
			compStatusMap.put(TaggingWizardConstants.EAR_ECCN_ENABLE, Boolean.FALSE);
			//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNEnabled(false);			
		} else {
			throw new TaggingWizardException("'" + newValue + "' was not a valid value for EAR question.");
		}	
		compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_VALUE, Boolean.FALSE);
		//taggingWizard.getEarQuestionBean().getEarQuestionVO().setBoolITCApproval(false);
		
		compStatusMap.put(TaggingWizardConstants.EAR_REASON_VALUE, null);
		//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelEARReason(null);
		
		compStatusMap.put(TaggingWizardConstants.EAR_ECCN_VALUE, -1);
		//taggingWizard.getEarQuestionBean().getEarQuestionVO().setSelECCNIndex(0);
		
		return compStatusMap;
	}
	
	private void reSetCtrlTechQuestion(Map compStatusMap) {
		compStatusMap.put(TaggingWizardConstants.HONDA_ENABLE, Boolean.FALSE);
		compStatusMap.put(TaggingWizardConstants.HONDA_VALUE, null);
	}
	
	private void reSetJurisdictionQuestion(Map compStatusMap) {
		compStatusMap.put(TaggingWizardConstants.JURI_DEPT_VALUE, null);		
		//question.getJurisdictionQuestionVO().setDepartment(null);
		
		compStatusMap.put(TaggingWizardConstants.JURI_COMMERCE_DEPT_ENABLE, Boolean.FALSE);
		//question.getJurisdictionQuestionVO().setCommDeptEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.JURI_STATE_DEPT_ENABLE, Boolean.FALSE);
		//question.getJurisdictionQuestionVO().setStateDeptEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, null);
		//question.getJurisdictionQuestionVO().setDrawingModel(null);
		
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_ENABLE, Boolean.FALSE);
		//question.getJurisdictionQuestionVO().setDrawingModelEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.JURI_RETIONALE_VALUE, null);
		
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, null);
		//question.getJurisdictionQuestionVO().setDrawingReviewSpec(null);
		
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE, Boolean.FALSE);
		//question.getJurisdictionQuestionVO().setDrawingReviewSpecEnabled(false);
	}

	private void reSetITARQuestion(Map compStatusMap) {
		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_ENABLE, Boolean.FALSE);		
		//question.getItarQuestionVO().setBoolITAREnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE, null);
		//question.getItarQuestionVO().setSubjectToITAR(null);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_REASON_VALUE, null);
		//question.getItarQuestionVO().setSelITARReason(null);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_REASON_ENABLE, Boolean.FALSE);
		//question.getItarQuestionVO().setSelITARReasonEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_USML_ENABLE, Boolean.FALSE);
		//question.getItarQuestionVO().setSelUSMLEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.ITAR_USML_VALUE, null);
		//question.getItarQuestionVO().setSelUSMLIndex(0);
	}

	private void reSetEARQuestion(Map compStatusMap) {
		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_ENABLE, Boolean.FALSE);		
		//question.getEarQuestionVO().setBoolEAREnabled(enable);
		
		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE, null);
		//question.getEarQuestionVO().setSubjectToEar(null);
		
		compStatusMap.put(TaggingWizardConstants.EAR_REASON_VALUE, null);
		//question.getEarQuestionVO().setSelEARReason(null);
		
		compStatusMap.put(TaggingWizardConstants.EAR_REASON_ENABLE, Boolean.FALSE);
		//question.getEarQuestionVO().setSelEARReasonEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_VALUE, Boolean.FALSE);
		//question.getEarQuestionVO().setBoolITCApproval(false);
		
		compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_ENABLE, Boolean.FALSE);
		//question.getEarQuestionVO().setBoolITCApprovalEnabled(false);
		
		compStatusMap.put(TaggingWizardConstants.EAR_ECCN_VALUE, -1);
		//question.getEarQuestionVO().setSelECCNIndex(0);
		
		compStatusMap.put(TaggingWizardConstants.EAR_ECCN_ENABLE, Boolean.FALSE);
		//question.getEarQuestionVO().setSelECCNEnabled(false);
	}
}
