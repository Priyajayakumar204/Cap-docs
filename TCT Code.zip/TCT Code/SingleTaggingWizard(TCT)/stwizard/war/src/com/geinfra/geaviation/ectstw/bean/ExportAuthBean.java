/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import com.geinfra.geaviation.ectstw.data.ExportAuthVO;
import com.geinfra.geaviation.ectstw.service.ExportAuthService;

public class ExportAuthBean {
	private ExportAuthService exportAuthService;
	private ExportAuthVO exportAuthVO;
	
	public ExportAuthService getExportAuthService() {
		return exportAuthService;
	}
	public void setExportAuthService(ExportAuthService exportAuthService) {
		this.exportAuthService = exportAuthService;
	}
	public ExportAuthVO getExportAuthVO() {
		return exportAuthVO;
	}
	public void setExportAuthVO(ExportAuthVO exportAuthVO) {
		this.exportAuthVO = exportAuthVO;
	}
	
	
}
