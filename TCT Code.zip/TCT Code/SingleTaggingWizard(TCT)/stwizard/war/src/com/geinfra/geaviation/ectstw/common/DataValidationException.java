/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common;

public class DataValidationException extends Exception {
	private final static long serialVersionUID = -6101489488608329613L;

	public DataValidationException() {
	}

	public DataValidationException(String str) {
		super(str);
	}

	public DataValidationException(String str, Throwable throwable) {
		super(str, throwable);
	}

	public DataValidationException(Throwable throwable) {
		super(throwable);
	}
}
