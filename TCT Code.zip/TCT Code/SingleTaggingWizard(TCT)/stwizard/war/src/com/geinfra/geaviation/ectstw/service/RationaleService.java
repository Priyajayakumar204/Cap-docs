/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import com.geinfra.geaviation.ectstw.model.dao.RationaleDao;

public class RationaleService extends BaseSTWService {
	private RationaleDao rationaleDao;

	public RationaleDao getRationaleDao() {
		return rationaleDao;
	}

	public void setRationaleDao(RationaleDao rationaleDao) {
		this.rationaleDao = rationaleDao;
	}
}
