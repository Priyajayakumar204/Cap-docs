/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import com.geinfra.geaviation.ectstw.model.dao.ExportControlDao;

public class ExportControlService extends BaseSTWService {
	private ExportControlDao exportControlDao;

	public ExportControlDao getExportControlDao() {
		return exportControlDao;
	}

	public void setExportControlDao(ExportControlDao exportControlDao) {
		this.exportControlDao = exportControlDao;
	}	
}
