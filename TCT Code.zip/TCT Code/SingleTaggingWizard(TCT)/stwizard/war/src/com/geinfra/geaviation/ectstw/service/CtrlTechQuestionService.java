/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.CtrlTechQuestionDao;

public class CtrlTechQuestionService extends BaseSTWService {
	private CtrlTechQuestionDao ctrlTechQuestionDao;

	public CtrlTechQuestionDao getCtrlTechQuestionDao() {
		return ctrlTechQuestionDao;
	}

	public void setCtrlTechQuestionDao(CtrlTechQuestionDao ctrlTechQuestionDao) {
		this.ctrlTechQuestionDao = ctrlTechQuestionDao;
	}
	
	public Map validate(Map compStatusMap){
		return getTagRulesService().validateCtrlTechQues(compStatusMap);
	}
}
