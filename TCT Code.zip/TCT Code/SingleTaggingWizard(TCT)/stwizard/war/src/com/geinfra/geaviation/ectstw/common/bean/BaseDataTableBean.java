/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.common.bean;

import java.util.List;

import javax.faces.component.html.HtmlDataTable;
import javax.faces.event.ActionEvent;

import com.ge.portal.faces.model.DataTableBean;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class BaseDataTableBean extends DataTableBean {
	protected HtmlDataTable dataTable;

	public BaseDataTableBean() {
		super();
	}

	@Override
	public String getPrevious() {
		
		if (dataTable.getFirst() >= dataTable.getRows()) {
			return "Previous";
		}

		return "";
	}

	@Override
	public String getNext() {
		
		if ((dataTable.getFirst() + dataTable.getRows()) < dataTable.getRowCount()) {
			return "Next";
		}

		return "";
	}

	@Override
	public void previous(ActionEvent event) {
		
		//dataTable.setFirst(dataTable.getFirst() - dataTable.getRows());
		dataTable.setFirst(dataTable.getFirst() - dataTable.getRows());
	}

	@Override
	public void next(ActionEvent event) {
		
		dataTable.setFirst(dataTable.getFirst() + dataTable.getRows());
	}
	
	@Override
	public String getResultsShown() {
		int lastRow = dataTable.getFirst() + dataTable.getRows();

		if (lastRow > dataTable.getRowCount()) {
			lastRow = dataTable.getRowCount();
		}

		return (new StringBuilder()).append((dataTable.getFirst() + 1)).append(" - ").append(lastRow).append(" of ").append(dataTable.getRowCount()).toString();
	}

	public HtmlDataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}

	public void addError(Exception exp, String userMessage) {
		TaggingWizardUtil.addError(exp, userMessage);
	}

	public void addMessage(String userMessage) {
		TaggingWizardUtil.addMessage(userMessage);
	}

	public List getCustomErrorMessages() {
		
		return TaggingWizardUtil.getMsgHandler().getErrorMessages();
	}
}