/**
 * Copyright (C) 2008 GE Infra. 
 * All rights reserved 
 * @FileName AuthorizationFilter.java
 * @Creation date: 24-Mar-2009
 * @version 1.0
 * @author Satyam
 */
package com.geinfra.geaviation.ectstw.common;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.log4j.Logger;

public class AuthorizationFilter implements Filter {
	private final static Logger logger = Logger.getLogger(AuthorizationFilter.class);
	//private FilterConfig filterConfig = null;

	public void init(FilterConfig filterConfig) throws ServletException {
		//this.filterConfig = filterConfig;
	}

	/**
	 * 
	 * @param request
	 *            current request
	 * @param response
	 *            current response
	 * @param chain
	 *            application filter chain
	 * @throws IOException
	 *             in case of error
	 * @throws ServletException
	 *             in case of error
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest hreq = (HttpServletRequest) request;
		// HttpServletResponse hres = (HttpServletResponse) response;

		logger.debug("--------------------------------------------------------------------------------------");
		logger.debug("Entering AuthorizationFilter...");

		String userid = hreq.getHeader("sm_ssoid");
		String mail = hreq.getHeader("sm_email");
		String firstName = hreq.getHeader("sm_first_name");
		String lastName = hreq.getHeader("sm_last_name");

		logger.info("welcome " + userid + " :" + firstName + " " + lastName + " :" + mail);
		logger.info("Path URL: " + hreq.getRequestURL());

		Enumeration dataEnum = hreq.getHeaderNames();
		logger.info("Header Information");
		logger.info("---------------------------------------------------------------------------");
		while(dataEnum.hasMoreElements()){
			String header = (String) dataEnum.nextElement();
			logger.info(header + ": " + hreq.getHeader(header));
		}
		logger.info("---------------------------------------------------------------------------");
		
		logger.info("Content-Type: " + hreq.getHeader("Content-Type"));
		logger.info("Http Method: " + hreq.getMethod());

		chain.doFilter(request, response);
		
		logger.debug("Exiting AuthorizationFilter...");
	}

	public void destroy() {	
		//filterConfig = null;
	}
}