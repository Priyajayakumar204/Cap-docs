/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import geae.export.ect.GEAEECTNoMatchingRecordFoundException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.rmi.server.ObjID;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.common.DataValidationException;
import com.geinfra.geaviation.ectstw.common.TaggingWizardException;
import com.geinfra.geaviation.ectstw.data.STWTAGRequest;
import com.geinfra.geaviation.ectstw.model.dao.ExportControlDao;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

public class STWTagRequestBean implements Serializable {
	private final static long serialVersionUID = 5308311733560165395L;
	
	private String srcAppId;
	private String srcAppType;
	private ArrayList<STWTAGRequest> stwTAGRequestList = new ArrayList<STWTAGRequest>();
	private List<String> filteredObjects = new ArrayList<String>();
	
	public static synchronized void createSTWTagRequest(MultivaluedMap<String, String> form, String userSSO) throws IOException, DataValidationException, Exception {
		Logger logger = Logger.getLogger(STWTagRequestBean.class);	
		
		STWTagRequestBean stwTagRequestBean = new STWTagRequestBean();
		Set<String> objSet = new HashSet<String>();
		
		List<String> appIdList = form.get("appId");
		List<String> appTypeList = form.get("appType");
		List<String> objectDataList =  form.get("objectData");
		
		logger.debug("application Id list: " + appIdList);
		logger.debug("application Type list: " + appTypeList);
		logger.debug("object data list: " + objectDataList);
		
		if(appIdList == null){
			throw new DataValidationException("Application Id was not found in the data.");
		} else if(appIdList.size() > 1) {
			throw new DataValidationException("Application Id should not be more than one.");
		} else if(appIdList.get(0).trim().length() == 0) {
			throw new DataValidationException("Application Id should not be empty.");
		}
		
		if(appTypeList == null){
			throw new DataValidationException("Application Type was not found in the data.");
		} else if(appTypeList.size() > 1) {
			throw new DataValidationException("Application Type should not be more than one.");
		} else if(appTypeList.get(0).trim().length() == 0) {
			throw new DataValidationException("Application Type should not be empty.");
		}
		
		if(objectDataList == null){
			throw new DataValidationException(ResourceFactory.getInstance().getTextMsg("DATA_NOT_FOUND"));
		} 
		
		logger.debug("Application Id: " + appIdList.get(0));
		logger.debug("Application Type: " + appTypeList.get(0));
		
		String appId = appIdList.get(0);
		String appType = appTypeList.get(0);
		
		stwTagRequestBean.setSrcAppId(appId);
		stwTagRequestBean.setSrcAppType(appType);
				
		Iterator<String> itr = objectDataList.iterator();
		
		logger.debug("started reading object data...");
		while(itr.hasNext()){
			String objDataStr = itr.next(); 
			if(objDataStr != null && objDataStr.trim().length() != 0) {
				logger.debug("processing object: " + objDataStr);
				String[] objData = objDataStr.split("\\$\\$");

				logger.debug("tokens: " + Arrays.toString(objData));
				String objId = objData[0].trim();
				
				if(objData.length != 2){
					logger.debug("skipped via multiple token check...");
					if(objId.length() != 0){
						stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: wrong data format.");
					}
					continue;
				} 
				
				String objDesc = objData[1].trim();				
				if(objId.length() == 0){
					logger.debug("skipped via object id null or empty...");
					continue;
				} else if(objDesc.length() == 0){
					logger.debug("skipped via description null or empty...");
					stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: empty description.");
					continue;
				}
				
				if(objDesc.length() > 255){
					logger.debug("skipped via long length description...");
					stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: description was more than 255 characters.");
					continue;
				}
				
				/*
				if(TaggingWizardUtil.isSpecialCharacter(objId)){
					logger.debug("skipped via special character in object id...");
					stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: object name contained some special characters.");
					continue;
				}
				
				if(TaggingWizardUtil.isSpecialCharacter(objDesc)){
					logger.debug("skipped via special character in description...");
					stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: description contained some special characters.");
					continue;
				}
				*/
				
				if(objSet.contains(objId)){
					logger.debug("skipped via duplicate object name...");
					stwTagRequestBean.getFilteredObjects().add("Object with object name [" + objId + "] was filtered out. Error: duplicate object was found.");
					continue;
				}
				
				objSet.add(objId);
				logger.debug("object id: " + objId + ", object desc: " + objDesc);
				
				try {
					String[] objDBData = ExportControlDao.getExportInfo(appId, appType, objId);
					
					STWTAGRequest stwTAGRequest = new STWTAGRequest();
					
					stwTAGRequest.setObjName(objId);
					stwTAGRequest.setObjDesc(objDesc);
					stwTAGRequest.setClassification(objDBData[2]);
					stwTAGRequest.setExportStatus(objDBData[0]);
					stwTAGRequest.setRational(objDBData[3]);
					
					stwTagRequestBean.getStwTAGRequestList().add(stwTAGRequest);	
				} catch(GEAEECTNoMatchingRecordFoundException ex){					
					TaggingWizardUtil.printException(ex);
					
					logger.debug("adding object " + objId + " with export status UNK");
					
					STWTAGRequest stwTAGRequest = new STWTAGRequest();					
					stwTAGRequest.setObjName(objId);
					stwTAGRequest.setObjDesc(objDesc);
					stwTAGRequest.setExportStatus("UNK");
					
					stwTagRequestBean.getStwTAGRequestList().add(stwTAGRequest);
				} catch(Exception ex){					
					TaggingWizardUtil.printException(ex);
					throw ex;
				}
			}
		}
		
		if(stwTagRequestBean.getStwTAGRequestList().size() == 0){
			throw new DataValidationException("No valid object data was found.");
		}
		writeData(userSSO, stwTagRequestBean);
	}
	
	private static synchronized void writeData(String userSSO, STWTagRequestBean stwTagRequestBean) throws IOException {
		Logger logger = Logger.getLogger(STWTagRequestBean.class);
		
		File file = null;				
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		
		if(userSSO == null || userSSO.trim().length() == 0){
			throw new TaggingWizardException("User SSO was null or empty.");
		}
		
		try{
			String filePath = ResourceFactory.getInstance().getAppProperty("DATA_FOLDER_PATH");
			file = new File(filePath + userSSO + ".dat");
			fos = new FileOutputStream(file);
			oos = new ObjectOutputStream(fos);
			
			oos.writeObject(stwTagRequestBean);
			
			oos.flush();
			oos.close();
		} catch(IOException ex){
			Logger.getLogger(STWTagRequestBean.class).error("Exception:" + ex.getMessage());
			
 			if(fos != null){
				try {
					fos.close();
				} catch (IOException exp) {
					logger.error("IOException in catch block:" + exp.getMessage());
				}
				fos = null;
			}
			if(file != null && file.exists()) {
				if(file.delete()){
					logger.debug("Error occured while writing export control object data to file. And, file '" + file.getName() + "' was deleted.");
				} else {
					logger.debug("Error occured while writing export control object data to file. And, file '" + file.getName() + "' was not deleted.");					
				}
			}
			
			throw ex;
		} finally {
			if(fos != null){
				try {
					fos.close();
				} catch (IOException exp) {
					logger.error("IOException in finally block:" + exp.getMessage());
				}
				fos = null;
			}
		}
	}
	
	public static synchronized STWTagRequestBean readData(String userSSO) {
		Logger logger = Logger.getLogger(STWTagRequestBean.class);
		STWTagRequestBean stwTagRequestBean = null;
		
		File file = null;
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		
		if(userSSO == null || userSSO.trim().length() == 0){
			throw new TaggingWizardException("User SSO was null or empty.");
		}
		
		try{
			String filePath = ResourceFactory.getInstance().getAppProperty("DATA_FOLDER_PATH");
			file = new File(filePath + userSSO + ".dat");
			fis = new FileInputStream(file);
			ois = new ObjectInputStream(fis);
			
			stwTagRequestBean =  (STWTagRequestBean) ois.readObject();
			
			ois.close();
		} catch(ClassNotFoundException ex){
			Logger.getLogger(STWTagRequestBean.class).error("Exception:" + ex.getMessage());
		} catch(IOException ex){
			Logger.getLogger(STWTagRequestBean.class).error("Exception:" + ex.getMessage());
			stwTagRequestBean = null;
		} finally {
			if(fis != null){
				try {
					fis.close();
				} catch (IOException exp) {
					logger.error("IOException in finally block:" + exp.getMessage());
				}
				fis = null;
			}
			if(file != null && file.exists()) {
				if(file.delete()){
					logger.debug("File '" + file.getName() + "' was deleted.");
				} else {
					logger.debug("File '" + file.getName() + "' was not deleted.");					
				}
			}
		}
		
		return stwTagRequestBean;
	}

	public ArrayList<STWTAGRequest> getStwTAGRequestList() {
		return stwTAGRequestList;
	}

	public void setStwTAGRequestList(ArrayList<STWTAGRequest> stwTAGRequestList) {
		this.stwTAGRequestList = stwTAGRequestList;
	}

	public String getSrcAppId() {
		return srcAppId;
	}

	public void setSrcAppId(String srcAppId) {
		this.srcAppId = srcAppId;
	}
	
	public String getSrcAppType() {
		return srcAppType;
	}

	public void setSrcAppType(String srcAppType) {
		this.srcAppType = srcAppType;
	}

	public List<String> getFilteredObjects() {
		return filteredObjects;
	}

	public void setFilteredObjects(List<String> filteredObjects) {
		this.filteredObjects = filteredObjects;
	}
}
