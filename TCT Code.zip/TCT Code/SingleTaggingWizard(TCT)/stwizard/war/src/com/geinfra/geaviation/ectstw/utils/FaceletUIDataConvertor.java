/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

import java.util.List;

import javax.faces.model.SelectItem;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public interface FaceletUIDataConvertor {
	public List<SelectItem> createSelectUIList(List<String> itemList);

	public List<SelectItem> createSelectUIList(List<String> itemList, String filterStr);
}
