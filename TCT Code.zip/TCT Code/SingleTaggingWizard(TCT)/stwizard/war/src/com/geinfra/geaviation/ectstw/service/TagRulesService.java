/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.TagRulesDao;

public class TagRulesService {
	TagRulesDao tagRulesDao = null;
	
	public TagRulesDao getTagRulesDao() {
		return tagRulesDao;
	}

	public void setTagRulesDao(TagRulesDao tagRulesDao) {
		this.tagRulesDao = tagRulesDao;
	}
	
	public Map validateDNEQuestion(Map compStatusMap){
		return tagRulesDao.getDneQuestionRule(compStatusMap);
	}
	
	public Map validateCtrlTechQues(Map compStatusMap){
		return tagRulesDao.getCtrlQuestionRules(compStatusMap);
	}
	
	public Map validateJurusdictionQues(Map compStatusMap){
		return tagRulesDao.getJurisdictionQuesRule(compStatusMap);
	}
	
	public Map validateITARQues(Map compStatusMap){
		return tagRulesDao.getITARQuestionRule(compStatusMap);
	}
	
	public Map validateEARQues(Map compStatusMap){
		return tagRulesDao.getEARQuesRules(compStatusMap);
	}
}
