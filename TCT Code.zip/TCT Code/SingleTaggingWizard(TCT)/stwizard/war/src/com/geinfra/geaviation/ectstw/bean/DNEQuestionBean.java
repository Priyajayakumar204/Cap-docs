/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.ectstw.data.DNEQuestionVO;
import com.geinfra.geaviation.ectstw.service.DNEQuestionService;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class DNEQuestionBean extends AbstractQuestionBean {
	private DNEQuestionVO dneQuestionVO = null;
	private DNEQuestionService dneQuestionService = null;
	private List<SelectItem> selDNEReasonList = new ArrayList<SelectItem>();	

	public List<SelectItem> getSelDNEReasonList() throws Exception {
		if (!dneQuestionVO.isReasonEnabled()) {
			return new ArrayList<SelectItem>();
		}

		if (selDNEReasonList.isEmpty()) {
			List<String> tempList = dneQuestionService.getDNEReasons();
			selDNEReasonList = faceletUtil.createSelectUIList(tempList);
		}

		return selDNEReasonList;
	}

	public void setSelDNEReasonList(List<SelectItem> selDNERessonList) {
		this.selDNEReasonList = selDNERessonList;
	}
	
	public Map getComponentStatusMap(Map compStatusMap){
		//DNE Question is permanently disabled.
		
		//return dneQuestionService.validate(compStatusMap);		
		return compStatusMap;
	}

	public DNEQuestionVO getDneQuestionVO() {
		return dneQuestionVO;
	}

	public DNEQuestionService getDneQuestionService() {
		return dneQuestionService;
	}

	public void setDneQuestionService(DNEQuestionService dneQuestionService) {
		this.dneQuestionService = dneQuestionService;
	}

	public void setDneQuestionVO(DNEQuestionVO dneQuestionVO) {
		this.dneQuestionVO = dneQuestionVO;
	}
}
