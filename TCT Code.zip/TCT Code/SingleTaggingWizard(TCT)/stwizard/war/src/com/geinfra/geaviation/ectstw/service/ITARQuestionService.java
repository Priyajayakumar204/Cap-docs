/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.service;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.ectstw.model.dao.ITARQuestionDao;

public class ITARQuestionService extends BaseSTWService {
	private ITARQuestionDao itarQuestionDao = null;

	public ITARQuestionDao getItarQuestionDao() {
		return itarQuestionDao;
	}

	public void setItarQuestionDao(ITARQuestionDao itarQuestionDao) {
		this.itarQuestionDao = itarQuestionDao;
	}
	
	public List<String> getITARReasons() throws Exception {
		return itarQuestionDao.getITARReasons();		
	}
	
	public List<String> getUSMLCatagory() throws Exception {
		return itarQuestionDao.getUSMLCatagory();
	}	
	
	public Map validate(Map compStatusMap){
		return getTagRulesService().validateITARQues(compStatusMap);
	}
}
