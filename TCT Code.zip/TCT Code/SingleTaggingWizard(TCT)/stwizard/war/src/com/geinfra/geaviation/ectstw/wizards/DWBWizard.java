/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.wizards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.component.html.HtmlSelectOneRadio;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;
import javax.portlet.PortletRequest;

import org.ajax4jsf.component.html.HtmlAjaxSupport;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.ectstw.bean.CtrlTechQuestionBean;
import com.geinfra.geaviation.ectstw.bean.DNEQuestionBean;
import com.geinfra.geaviation.ectstw.bean.EARQuestionBean;
import com.geinfra.geaviation.ectstw.bean.ITARQuestionBean;
import com.geinfra.geaviation.ectstw.bean.JurisdictionQuestionBean;
import com.geinfra.geaviation.ectstw.bean.RationaleBean;
import com.geinfra.geaviation.ectstw.bean.STWTagRequestBean;
import com.geinfra.geaviation.ectstw.common.STWizardException;
import com.geinfra.geaviation.ectstw.data.STWTAGRequest;
import com.geinfra.geaviation.ectstw.model.dao.ExportControlDao;
import com.geinfra.geaviation.ectstw.resource.ResourceFactory;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class DWBWizard extends AbstractSTWWizard {
	private Logger logger = Logger.getLogger(DWBWizard.class);

	private Map<String, Object> compStatusMap = new HashMap<String, Object>();
	private List<STWTAGRequest> inValidObjects = new ArrayList<STWTAGRequest>();
	private List<STWTAGRequest> validObjects = new ArrayList<STWTAGRequest>();

	private DNEQuestionBean dneQuestionBean = null;
	private CtrlTechQuestionBean ctrlTechQuestionBean = null;
	private JurisdictionQuestionBean jurisdictionQuestionBean = null;
	private ITARQuestionBean itarQuestionBean = null;
	private EARQuestionBean earQuestionBean = null;
	private RationaleBean rationaleBean = null;

	//private ComponentStatusUpdater compStatusUpdater = null;

	private String usmlSelected;
	private String eccnSelected;
	private String classCode;

	private String newExpStatus = null;

	private STWTagRequestBean stwTagRequestBean = null;
	private ExportControlDao exportControlDao = null;

	@Override
	public void init() throws STWizardException {
		logger.debug("DWBWizard Init method called...");

		stwTagRequestBean = (STWTagRequestBean) TaggingWizardUtil.getSessionAttribute(TaggingWizardConstants.ECT_OBJECTS_DATA);

		if (stwTagRequestBean == null || stwTagRequestBean.getStwTAGRequestList().size() == 0) {
			addMessage("Export control objects data was not found.");
			throw new STWizardException("Export control objects data was not found.");
		}

		setResults(stwTagRequestBean.getStwTAGRequestList());

		if (!stwTagRequestBean.getFilteredObjects().isEmpty()) {
			for (String object : stwTagRequestBean.getFilteredObjects()) {
				addMessage(object);
			}

			stwTagRequestBean.getFilteredObjects().clear();
		}

		updateCompStatuMap();
	}

	public void setStwTAGRequests(ArrayList<STWTAGRequest> stwTAGRequestList) {
		this.stwTagRequestBean.setStwTAGRequestList(stwTAGRequestList);
	}

	public void changeDneSelection(ActionEvent ae) {
		HtmlAjaxSupport htmlObnj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectBooleanCheckbox selOneMenu = (HtmlSelectBooleanCheckbox) htmlObnj.getParent();
		
		Boolean newValue = (Boolean) selOneMenu.getValue();
		compStatusMap.put(TaggingWizardConstants.DNE_SELECTION_VALUE, newValue);
		compStatusMap = dneQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DNE_QUESTION, TaggingWizardUtil.booleanYesNo(newValue));
	}

	public void changeDneSelection(ValueChangeEvent event) {
		Boolean newValue = (Boolean) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.DNE_SELECTION_VALUE, newValue);
		compStatusMap = dneQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectIsCtrlTech(ActionEvent ae) {
		HtmlAjaxSupport htmlObnj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) htmlObnj.getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.CTRL_TECH_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.AE_CONTROL_TECH_QUESTION);
		compStatusMap = ctrlTechQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.AE_CONTROL_TECH_QUESTION, newValue);
	}

	public void selectIsCtrlTech(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.CTRL_TECH_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.AE_CONTROL_TECH_QUESTION);
		compStatusMap = ctrlTechQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectIsHondaPrg(ActionEvent ae) {
		HtmlAjaxSupport htmlAjaxObj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) htmlAjaxObj.getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.HONDA_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.HONDA_QUESTION);
		compStatusMap = ctrlTechQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.HONDA_QUESTION, newValue);
	}

	public void selectIsHondaPrg(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.HONDA_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.HONDA_QUESTION);
		compStatusMap = ctrlTechQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectJurisdictionDept(ActionEvent ae) {
		HtmlAjaxSupport htmlAjaxObj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) htmlAjaxObj.getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.JURI_DEPT_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.JURI_RETIONALE_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText());
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.JURISDICTION_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.JURISDICTION_QUESTION, newValue);
	}

	public void selectJurisdictionDept(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.JURI_DEPT_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.JURI_RETIONALE_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText());
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.JURISDICTION_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectDrawingModel(ActionEvent ae) {
		HtmlAjaxSupport htmlAjaxObj = (HtmlAjaxSupport) ae.getSource();
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) htmlAjaxObj.getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.DRAWING_MODEL_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DRAWING_MODEL_QUESTION, newValue);
	}

	public void selectDrawingModel(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.DRAWING_MODEL_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectDeawingOnlyQuestion(ActionEvent ae) {
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) ae.getComponent().getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION, newValue);
	}

	public void selectDeawingOnlyQuestion(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, newValue);
		compStatusMap.put(TaggingWizardConstants.QUESTION_KEY, TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION);
		compStatusMap = jurisdictionQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectSubjectToITAR(ActionEvent ae) {
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) ae.getComponent().getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE, newValue);
		compStatusMap = itarQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.ITAR_QUESTION, newValue);
	}

	public void selectSubjectToITAR(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE, newValue);
		compStatusMap = itarQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	public void selectSubjToEar(ActionEvent ae) {
		HtmlSelectOneRadio srcComp = (HtmlSelectOneRadio) ae.getComponent().getParent();

		String newValue = (String) srcComp.getValue();
		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE, newValue);
		compStatusMap = earQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		//compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.EAR_QUESTION, newValue);
	}

	public void selectSubjToEar(ValueChangeEvent event) {
		String newValue = (String) event.getNewValue();
		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE, newValue);
		compStatusMap = earQuestionBean.getComponentStatusMap(compStatusMap);
		updateQuestionBeans();

		FacesContext.getCurrentInstance().responseComplete();
		//performAction(event);
	}

	//	public void performAction(ValueChangeEvent event) {
	//		String compId = event.getComponent().getId();
	//		
	//
	//		if ("chkDNE".equals(compId)) {
	//			boolean newValue = (Boolean) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DNE_QUESTION, TaggingWizardUtil.booleanYesNo(newValue));
	//		} else if ("aeCtrlTech".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.AE_CONTROL_TECH_QUESTION, newValue);
	//		} else if ("honda".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.HONDA_QUESTION, newValue);
	//		} else if ("jurisdictionDept".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.JURISDICTION_QUESTION, newValue);
	//		} else if ("drawingModel".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DRAWING_MODEL_QUESTION, newValue);
	//		} else if ("reviewSpec".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.DRAWING_REVIEW_SPEC_QUESTION, newValue);
	//		} else if ("rdITAR".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.ITAR_QUESTION, newValue);
	//		} else if ("rdEAR".equals(compId)) {
	//			String newValue = (String) event.getNewValue();
	//			compStatusUpdater.updateComponentStatus(this, TaggingWizardConstants.EAR_QUESTION, newValue);
	//		}
	//
	//		FacesContext.getCurrentInstance().responseComplete();
	//	}

	private void updateCompStatuMap() {
		

		compStatusMap.put(TaggingWizardConstants.DNE_SELECTION_VALUE, dneQuestionBean.getDneQuestionVO().isSelected());
		compStatusMap.put(TaggingWizardConstants.DNE_REASON_ENABLE, dneQuestionBean.getDneQuestionVO().isReasonEnabled());
		compStatusMap.put(TaggingWizardConstants.DNE_REASON_VALUE, dneQuestionBean.getDneQuestionVO().getSelDNEReason());

		compStatusMap.put(TaggingWizardConstants.CTRL_TECH_VALUE, ctrlTechQuestionBean.getCtrlTechQuestionVO().getAeControlTechnology());
		compStatusMap.put(TaggingWizardConstants.HONDA_VALUE, ctrlTechQuestionBean.getCtrlTechQuestionVO().getGeHondaAeroTech());
		compStatusMap.put(TaggingWizardConstants.HONDA_ENABLE, ctrlTechQuestionBean.getCtrlTechQuestionVO().isGeHondaEnabled());

		compStatusMap.put(TaggingWizardConstants.JURI_DEPT_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment());
		compStatusMap.put(TaggingWizardConstants.JURI_COMMERCE_DEPT_ENABLE, jurisdictionQuestionBean.getJurisdictionQuestionVO().isCommDeptEnabled());
		compStatusMap.put(TaggingWizardConstants.JURI_STATE_DEPT_ENABLE, jurisdictionQuestionBean.getJurisdictionQuestionVO().isStateDeptEnabled());
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingModel());
		compStatusMap.put(TaggingWizardConstants.JURI_DRAWING_MODEL_ENABLE, jurisdictionQuestionBean.getJurisdictionQuestionVO().isDrawingModelEnabled());
		compStatusMap.put(TaggingWizardConstants.JURI_RETIONALE_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText());
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE, jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingReviewSpec());
		compStatusMap.put(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE, jurisdictionQuestionBean.getJurisdictionQuestionVO().isDrawingReviewSpecEnabled());

		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_ENABLE, itarQuestionBean.getItarQuestionVO().isBoolITAREnabled());
		compStatusMap.put(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE, itarQuestionBean.getItarQuestionVO().getSubjectToITAR());
		compStatusMap.put(TaggingWizardConstants.ITAR_REASON_ENABLE, itarQuestionBean.getItarQuestionVO().isSelITARReasonEnabled());
		compStatusMap.put(TaggingWizardConstants.ITAR_REASON_VALUE, itarQuestionBean.getItarQuestionVO().getSelITARReason());
		compStatusMap.put(TaggingWizardConstants.ITAR_USML_ENABLE, itarQuestionBean.getItarQuestionVO().isSelUSMLEnabled());
		compStatusMap.put(TaggingWizardConstants.ITAR_USML_VALUE, itarQuestionBean.getItarQuestionVO().getSelUSMLType());

		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_ENABLE, earQuestionBean.getEarQuestionVO().isBoolEAREnabled());
		compStatusMap.put(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE, earQuestionBean.getEarQuestionVO().getSubjectToEar());
		compStatusMap.put(TaggingWizardConstants.EAR_REASON_ENABLE, earQuestionBean.getEarQuestionVO().isSelEARReasonEnabled());
		compStatusMap.put(TaggingWizardConstants.EAR_REASON_VALUE, earQuestionBean.getEarQuestionVO().getSelEARReason());

		compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_ENABLE, earQuestionBean.getEarQuestionVO().isBoolITCApprovalEnabled());
		compStatusMap.put(TaggingWizardConstants.EAR_ITC_APPROVAL_VALUE, earQuestionBean.getEarQuestionVO().isBoolITCApproval());
		compStatusMap.put(TaggingWizardConstants.EAR_ECCN_ENABLE, earQuestionBean.getEarQuestionVO().isSelECCNEnabled());
		compStatusMap.put(TaggingWizardConstants.EAR_ECCN_VALUE, earQuestionBean.getEarQuestionVO().getSelECCNIndex());
	}

	private void updateQuestionBeans() {
		//DNE Question is permanently disabled.
		//dneQuestionBean.getDneQuestionVO().setSelected((Boolean) compStatusMap.get(TaggingWizardConstants.DNE_SELECTION_VALUE));
		//dneQuestionBean.getDneQuestionVO().setReasonEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.DNE_REASON_ENABLE));
		//dneQuestionBean.getDneQuestionVO().setSelDNEReason((String) compStatusMap.get(TaggingWizardConstants.DNE_REASON_VALUE));

		ctrlTechQuestionBean.getCtrlTechQuestionVO().setAeControlTechnology((String) compStatusMap.get(TaggingWizardConstants.CTRL_TECH_VALUE));
		ctrlTechQuestionBean.getCtrlTechQuestionVO().setGeHondaAeroTech((String) compStatusMap.get(TaggingWizardConstants.HONDA_VALUE));
		ctrlTechQuestionBean.getCtrlTechQuestionVO().setGeHondaEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.HONDA_ENABLE));

		jurisdictionQuestionBean.getJurisdictionQuestionVO().setDepartment((String) compStatusMap.get(TaggingWizardConstants.JURI_DEPT_VALUE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setCommDeptEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.JURI_COMMERCE_DEPT_ENABLE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setStateDeptEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.JURI_STATE_DEPT_ENABLE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setDrawingModel((String) compStatusMap.get(TaggingWizardConstants.JURI_DRAWING_MODEL_VALUE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setDrawingModelEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.JURI_DRAWING_MODEL_ENABLE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setJuriRationalText((String) compStatusMap.get(TaggingWizardConstants.JURI_RETIONALE_VALUE));
		
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setDrawingReviewSpec((String) compStatusMap.get(TaggingWizardConstants.JURI_REVIEW_SPEC_VALUE));
		jurisdictionQuestionBean.getJurisdictionQuestionVO().setDrawingReviewSpecEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.JURI_REVIEW_SPEC_ENABLE));

		itarQuestionBean.getItarQuestionVO().setBoolITAREnabled((Boolean) compStatusMap.get(TaggingWizardConstants.ITAR_SUBJECT_TO_ENABLE));
		itarQuestionBean.getItarQuestionVO().setSubjectToITAR((String) compStatusMap.get(TaggingWizardConstants.ITAR_SUBJECT_TO_VALUE));
		itarQuestionBean.getItarQuestionVO().setSelITARReasonEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.ITAR_REASON_ENABLE));
		itarQuestionBean.getItarQuestionVO().setSelITARReason((String) compStatusMap.get(TaggingWizardConstants.ITAR_REASON_VALUE));
		itarQuestionBean.getItarQuestionVO().setSelUSMLEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.ITAR_USML_ENABLE));
		itarQuestionBean.getItarQuestionVO().setSelUSMLType((String) compStatusMap.get(TaggingWizardConstants.ITAR_USML_VALUE));

		earQuestionBean.getEarQuestionVO().setBoolEAREnabled((Boolean) compStatusMap.get(TaggingWizardConstants.EAR_SUBJECT_TO_ENABLE));
		earQuestionBean.getEarQuestionVO().setSubjectToEar((String) compStatusMap.get(TaggingWizardConstants.EAR_SUBJECT_TO_VALUE));
		earQuestionBean.getEarQuestionVO().setSelEARReasonEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.EAR_REASON_ENABLE));
		earQuestionBean.getEarQuestionVO().setSelEARReason((String) compStatusMap.get(TaggingWizardConstants.EAR_REASON_VALUE));

		earQuestionBean.getEarQuestionVO().setBoolITCApprovalEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.EAR_ITC_APPROVAL_ENABLE));
		earQuestionBean.getEarQuestionVO().setBoolITCApproval((Boolean) compStatusMap.get(TaggingWizardConstants.EAR_ITC_APPROVAL_VALUE));
		earQuestionBean.getEarQuestionVO().setSelECCNEnabled((Boolean) compStatusMap.get(TaggingWizardConstants.EAR_ECCN_ENABLE));
		earQuestionBean.getEarQuestionVO().setSelECCNIndex((Integer) compStatusMap.get(TaggingWizardConstants.EAR_ECCN_VALUE));
	}

	public JurisdictionQuestionBean getJurisdictionQuestionBean() {
		return jurisdictionQuestionBean;
	}

	public void setJurisdictionQuestionBean(JurisdictionQuestionBean jurisdictionQuestionBean) {
		this.jurisdictionQuestionBean = jurisdictionQuestionBean;
	}

	public DNEQuestionBean getDneQuestionBean() {
		return dneQuestionBean;
	}

	public void setDneQuestionBean(DNEQuestionBean dneQuestionBean) {
		this.dneQuestionBean = dneQuestionBean;
	}

	public CtrlTechQuestionBean getCtrlTechQuestionBean() {
		return ctrlTechQuestionBean;
	}

	public void setCtrlTechQuestionBean(CtrlTechQuestionBean ctrlTechQuestionBean) {
		this.ctrlTechQuestionBean = ctrlTechQuestionBean;
	}

	public ITARQuestionBean getItarQuestionBean() {
		return itarQuestionBean;
	}

	public void setItarQuestionBean(ITARQuestionBean itarQuestionBean) {
		this.itarQuestionBean = itarQuestionBean;
	}

	public EARQuestionBean getEarQuestionBean() {
		return earQuestionBean;
	}

	public void setEarQuestionBean(EARQuestionBean earQuestionBean) {
		this.earQuestionBean = earQuestionBean;
	}

	//	public ComponentStatusUpdater getCompStatusUpdater() {
	//		return compStatusUpdater;
	//	}
	//
	//	public void setCompStatusUpdater(ComponentStatusUpdater compStatusUpdater) {
	//		this.compStatusUpdater = compStatusUpdater;
	//	}

	public String getExportStatus() throws Exception {
		StringBuilder selectedOptions = new StringBuilder();

		StringBuilder usmlSelectedTemp;
		StringBuilder eccnSelectedTemp;

		String nextPage = "rationalePage";

		// GE Aviation Controlled Technology question must be answered
		if (ctrlTechQuestionBean.getCtrlTechQuestionVO().getAeControlTechnology() == null || ctrlTechQuestionBean.getCtrlTechQuestionVO().getAeControlTechnology().length() == 0) {
			TaggingWizardUtil.addMessage(TaggingWizardConstants.CONTROL_TECH_MSG);
			return "";
		}

		// Reason for DNE has to be selected if DNEwas checked
		if (dneQuestionBean.getDneQuestionVO().isSelected()) {
			if (dneQuestionBean.getDneQuestionVO().getSelDNEReason() == null || dneQuestionBean.getDneQuestionVO().getSelDNEReason().length() == 0) {
				TaggingWizardUtil.addMessage(TaggingWizardConstants.DNE_REASON_MSG);
				return "";
			}
		} else {
			// Honda question must be answered only if DNE was not checked
			if (ctrlTechQuestionBean.getCtrlTechQuestionVO().getGeHondaAeroTech() == null || ctrlTechQuestionBean.getCtrlTechQuestionVO().getGeHondaAeroTech().length() == 0) {
				TaggingWizardUtil.addMessage(TaggingWizardConstants.HONDA_AERO_MSG);
				return "";
			}

			// Identify Jurisdiction check
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment() == null || jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment().length() == 0) {
				TaggingWizardUtil.addMessage(TaggingWizardConstants.IDN_JURD_MSG);
				return "";
			}

			// CoMingle check
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment().equals(TaggingWizardConstants.STATE)) {
				if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingModel() == null || jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingModel().length() == 0) {
					TaggingWizardUtil.addMessage(TaggingWizardConstants.CO_MINGLE_MSG);
					return "";
				}
			}
			
			// Check for Jurisdiction Rationale
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText() == null || jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText().length() == 0) {
				TaggingWizardUtil.addMessage(TaggingWizardConstants.JURI_RATIONALE_MSG);
				return "";
			} 

			// Check for Jurisdiction Rationale length
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText().length() > 255) {
				TaggingWizardUtil.handleFacesError(TaggingWizardConstants.JURI_RATIONALE_LEN_MSG);
				return "";
			}
			
			// Document Review Specification check
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingReviewSpec() == null || jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingReviewSpec().length() == 0) {
				TaggingWizardUtil.addMessage(TaggingWizardConstants.DRAWING_REVIEW_SPEC_MSG);
				return "";
			}

			// ITAR check
			if (jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment().equals(TaggingWizardConstants.STATE)) {
				if (itarQuestionBean.getItarQuestionVO().getSubjectToITAR() == null || itarQuestionBean.getItarQuestionVO().getSubjectToITAR().length() == 0) {
					TaggingWizardUtil.addMessage(TaggingWizardConstants.ITAR_QUES_MSG);
					return "";
				} else if (itarQuestionBean.getItarQuestionVO().getSubjectToITAR().equals(TaggingWizardConstants.NO)) {
					if (itarQuestionBean.getItarQuestionVO().getSelITARReason() == null || itarQuestionBean.getItarQuestionVO().getSelITARReason().length() == 0) {
						TaggingWizardUtil.addMessage(TaggingWizardConstants.ITAR_REASON_MSG);
						return "";
					}
				}
				// USML Check
				else if (itarQuestionBean.getItarQuestionVO().getSubjectToITAR().equals(TaggingWizardConstants.YES)) {
					if (itarQuestionBean.getSelectedUSMLTypeList() == null || itarQuestionBean.getSelectedUSMLTypeList().size() == 0) {
						TaggingWizardUtil.addMessage(TaggingWizardConstants.USML_CATEG_MSG);
						return "";
					}
				}
			}

			// ECCn Check
			if ((jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment().equals(TaggingWizardConstants.STATE) && jurisdictionQuestionBean.getJurisdictionQuestionVO().getDrawingModel().equals(TaggingWizardConstants.YES)) || jurisdictionQuestionBean.getJurisdictionQuestionVO().getDepartment().equals(TaggingWizardConstants.COMMERCE)) {
				if (earQuestionBean.getEarQuestionVO().getSubjectToEar() == null || earQuestionBean.getEarQuestionVO().getSubjectToEar().length() == 0) {
					TaggingWizardUtil.addMessage(TaggingWizardConstants.EAR_QUES_MSG);
					return "";
				} else if (earQuestionBean.getEarQuestionVO().getSubjectToEar().equals(TaggingWizardConstants.NO)) {
					if (earQuestionBean.getEarQuestionVO().getSelEARReason() == null || earQuestionBean.getEarQuestionVO().getSelEARReason().length() == 0) {
						TaggingWizardUtil.addMessage(TaggingWizardConstants.EAR_REASON_MSG);
						return "";
					} else if (!earQuestionBean.getEarQuestionVO().isBoolITCApproval()) {
						TaggingWizardUtil.addMessage(TaggingWizardConstants.ITC_APPROVAL_MSG);
						return "";
					}
				} else if (earQuestionBean.getEarQuestionVO().getSubjectToEar().equals(TaggingWizardConstants.YES)) {
					if (earQuestionBean.getSelectedECCNTypeList() == null || earQuestionBean.getSelectedECCNTypeList().size() == 0) {
						TaggingWizardUtil.addMessage(TaggingWizardConstants.ECCN_CAT_MSG);
						return "";
					}
				}
			}
		}

		if (dneQuestionBean.getDneQuestionVO().getSelDNEReason() != null && dneQuestionBean.getDneQuestionVO().getSelDNEReason().length() != 0) {
			selectedOptions.append(dneQuestionBean.getDneQuestionVO().getSelDNEReason());
		} else {
			if (ctrlTechQuestionBean.getCtrlTechQuestionVO().getGeHondaAeroTech() != null && ctrlTechQuestionBean.getCtrlTechQuestionVO().getGeHondaAeroTech().equals(TaggingWizardConstants.YES)) {
				selectedOptions.append(TaggingWizardConstants.LRJ);
			}
			if (itarQuestionBean.getSelectedUSMLTypeList() != null && itarQuestionBean.getSelectedUSMLTypeList().size() != 0) {
				usmlSelectedTemp = new StringBuilder();
				for (int k = 0; k < itarQuestionBean.getSelectedUSMLTypeList().size(); k++) {
					SelectItem item = itarQuestionBean.getSelectedUSMLTypeList().get(k);
					if (((String) item.getValue()).length() != 0) {
						if (usmlSelectedTemp.length() != 0) {
							usmlSelectedTemp.append("~" + (String) item.getValue());
						} else {
							usmlSelectedTemp.append((String) item.getValue());
						}
					}
				}
				if (selectedOptions.length() != 0) {
					selectedOptions.append("~" + usmlSelectedTemp.toString());
				} else {
					selectedOptions.append(usmlSelectedTemp.toString());
				}

				usmlSelected = usmlSelectedTemp.toString();
			}
			if (earQuestionBean.getSelectedECCNTypeList() != null && earQuestionBean.getSelectedECCNTypeList().size() != 0) {
				eccnSelectedTemp = new StringBuilder();
				for (int k = 0; k < earQuestionBean.getSelectedECCNTypeList().size(); k++) {
					SelectItem item = earQuestionBean.getSelectedECCNTypeList().get(k);
					String itemVal = (String) item.getValue();
					if (itemVal.length() != 0) {
						if (eccnSelectedTemp.length() != 0) {
							eccnSelectedTemp.append("~" + itemVal);
						} else {
							eccnSelectedTemp.append(itemVal);
						}
					}
				}
				if (selectedOptions.length() != 0) {
					selectedOptions.append("~" + eccnSelectedTemp);
				} else {
					selectedOptions.append(eccnSelectedTemp);
				}
				eccnSelected = eccnSelectedTemp.toString();
			}
			if (itarQuestionBean.getItarQuestionVO().getSelITARReason() != null && itarQuestionBean.getItarQuestionVO().getSelITARReason().length() != 0) {
				if (selectedOptions.length() != 0) {
					selectedOptions.append("~" + itarQuestionBean.getItarQuestionVO().getSelITARReason());
				} else {
					selectedOptions.append(itarQuestionBean.getItarQuestionVO().getSelITARReason());
				}
			}
			if (earQuestionBean.getEarQuestionVO().getSelEARReason() != null && earQuestionBean.getEarQuestionVO().getSelEARReason().length() != 0) {
				if (selectedOptions.length() != 0) {
					selectedOptions.append("~" + earQuestionBean.getEarQuestionVO().getSelEARReason());
				} else {
					selectedOptions.append(earQuestionBean.getEarQuestionVO().getSelEARReason());
				}
			}
		}

		if((usmlSelected + "~" + eccnSelected).length() > 255){
			TaggingWizardUtil.addMessage(TaggingWizardConstants.USML_ECCN_LEN_MSG);
			return "";
		}
		
		logger.info("selectedOptions:" + selectedOptions);
		String[] args = selectedOptions.toString().split("\\~");
		try {
			newExpStatus = exportControlDao.getExportStatus(args);
			logger.info("new export status:" + newExpStatus);
		} catch (Exception e) {
			logger.error("Exception[getExportStatus]" + e.getMessage());
			nextPage = TaggingWizardConstants.ERROR;
		}

		return nextPage;
	}
	
	public String getRationalePreviousPage(){
		return "tagRulesPage";
	}

	public String getRationaleNextPage() {
		String nextPage = "tagConfirmationPage";

		inValidObjects.clear();
		validObjects.clear();

		if (rationaleBean.getRationaleVO().getRationalText() == null || rationaleBean.getRationaleVO().getRationalText().length() == 0) {
			TaggingWizardUtil.addMessage(TaggingWizardConstants.RATIONALE_CHECK_MSG);
			return "";
		} else if ((jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText().length() 
										+ rationaleBean.getRationaleVO().getRationalText().length()) > 255) {
			TaggingWizardUtil.addMessage(TaggingWizardConstants.RATIONALE_LEN_MSG);
			return "";
		} else {
			try {
				String appId = stwTagRequestBean.getSrcAppId();
				String appType = stwTagRequestBean.getSrcAppType();

				List<STWTAGRequest> tempObjList = stwTagRequestBean.getStwTAGRequestList();
				List<String> tempList;

				for (int i = 0; i < tempObjList.size(); i++) {
					STWTAGRequest stwTAGRequest = tempObjList.get(i);

					String[] args = new String[5];
					List<String[]> objArgs = new ArrayList<String[]>();
					
					args[0] = newExpStatus;
					args[1] = appId;
					args[2] = appType;
					
					objArgs.add(new String[]{stwTAGRequest.getObjName(), stwTAGRequest.getExportStatus()});
					
					tempList = exportControlDao.verifyStatus(args, objArgs);

					if (tempList.size() != 0) {
						inValidObjects.add(stwTAGRequest);
					} else {
						validObjects.add(stwTAGRequest);
					}
				}

				logger.info("Invalid Objects::" + inValidObjects.size());
				logger.info("Valid Objects::" + validObjects.size());
			} catch (Exception e) {
				logger.error("Exception[getConfirmPage]" + e.getMessage());
				throw new RuntimeException(e);
			}

			ArrayList<String> slClassCode = new ArrayList<String>();

			if (dneQuestionBean.getDneQuestionVO().getSelDNEReason() != null && dneQuestionBean.getDneQuestionVO().getSelDNEReason().length() != 0) {
				slClassCode.add(dneQuestionBean.getDneQuestionVO().getSelDNEReason());
			}

			if (itarQuestionBean.getItarQuestionVO().getSelITARReason() != null && itarQuestionBean.getItarQuestionVO().getSelITARReason().length() != 0) {
				slClassCode.add(itarQuestionBean.getItarQuestionVO().getSelITARReason());
			}

			if (earQuestionBean.getEarQuestionVO().getSelEARReason() != null && earQuestionBean.getEarQuestionVO().getSelEARReason().length() != 0) {
				slClassCode.add(earQuestionBean.getEarQuestionVO().getSelEARReason());
			}

			if (usmlSelected != null && usmlSelected.length() != 0) {
				slClassCode.add(usmlSelected);
			}

			if (eccnSelected != null && eccnSelected.length() != 0) {
				slClassCode.add(eccnSelected);
			}

			// Join the Class Codes together ~ delimited
			int iClassCodeSize = slClassCode.size();
			StringBuilder classCodeTemp = new StringBuilder();
			for (int i = 0; i < iClassCodeSize; i++) {
				if (i == 0) {
					classCodeTemp.append(slClassCode.get(i));
				} else {
					classCodeTemp.append("~" + slClassCode.get(i));
				}
			}
			classCode = classCodeTemp.toString();
		}

		return nextPage;
	}
	
	public String getConfirmPreviousPage(){
		return "rationalePage";
	}

	public String getObjTagged() {
		String nextPage = "taggedStausPage";
		StringBuilder taggedObjStr = new StringBuilder();
		boolean multiObjTagged = false;

		if (validObjects == null || validObjects.isEmpty()) {
			addMessage("No valid objects to tag.");
			nextPage = "";
		} else {
			String[] methodArgsECT = null;

			Map userInfo = (Map) TaggingWizardUtil.getPortletRequest().getAttribute(PortletRequest.USER_INFO);
			String altuid = (String) userInfo.get("user.altuid");

			logger.info("User NTid:" + altuid);

			String appId = stwTagRequestBean.getSrcAppId();
			String appType = stwTagRequestBean.getSrcAppType();

			Iterator<STWTAGRequest> itr = validObjects.iterator();

			while (itr.hasNext()) {
				boolean bReturn = false;
				STWTAGRequest ecObject = itr.next();

				String objectId = ecObject.getObjName();
				logger.debug("Started tagging object:" + objectId);
				try {
					logger.debug("Updating export status of the object...");
					methodArgsECT = new String[] { ecObject.getObjName(), ecObject.getObjDesc(), newExpStatus, altuid, classCode, jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText() + " " + rationaleBean.getRationaleVO().getRationalText(), ctrlTechQuestionBean.getCtrlTechQuestionVO().getAeControlTechnology()};					
					bReturn = exportControlDao.setExportControlData(appId, appType, methodArgsECT);
				} catch (Exception e) {					
					logger.error("Root Exception [" + e.getClass() + "] - " + e.getMessage());
					if (e.toString().indexOf("GEAEECTNoMatchingRecordFoundException") != -1) {
						try {
							logger.debug("Updating export status of the object got failed.");							
							logger.debug("Trying creating object and export status of the object...");
							methodArgsECT = new String[] { ecObject.getObjName(), ecObject.getObjDesc(), newExpStatus, "", "ECT", "", altuid, classCode, jurisdictionQuestionBean.getJurisdictionQuestionVO().getJuriRationalText() + " " + rationaleBean.getRationaleVO().getRationalText(), ctrlTechQuestionBean.getCtrlTechQuestionVO().getAeControlTechnology()};
							bReturn = exportControlDao.createExportControlObject(appId, appType, methodArgsECT);
						} catch (Exception f) {
							logger.error("Inner Exception [" + f.getClass() + "] - " + f.getMessage());
							if (f.toString().indexOf("No matching Application ID/Application Type Found") != -1) {
								addMessage("Error: Object Id [" + objectId + "] - " + "No matching App Id or App type");
							} else {
								addMessage("Error: Object Id [" + objectId + "] - " + "Some error has occured during tagging the object.");
							}
						}
					} else if (e.toString().indexOf("GEAEECTNoPrivilegeException") != -1) {
						if (e.toString().indexOf("US group") != -1) {
							addMessage("Error: Object Id [" + objectId + "] - " + "Not in US Group");
						} else {
							addMessage("Error: Object Id [" + objectId + "] - " + "Some access error has occured during tagging the object.");
						}
					} else {
						addMessage("Error: Object Id [" + objectId + "] - " + "Some unknown error has occured during tagging the object.");
					}
				}

				if (bReturn) {
					logger.debug("Object with Id [" + objectId + "] was tagged successfully.");
					if (!multiObjTagged) {
						taggedObjStr.append(objectId);
						multiObjTagged = true;
					} else {						
						taggedObjStr.append(", " + objectId);
					}
					stwTagRequestBean.getStwTAGRequestList().remove(ecObject);
					itr.remove();
				}
			}
			
			validObjects.clear();
			inValidObjects.clear();
			usmlSelected = null;
			eccnSelected = null;
			classCode = null;
			newExpStatus = null;			
		}

		if (multiObjTagged) {
			addMessage("Objects with Ids [" + taggedObjStr.toString() + "] were tagged successfully.");
		} else {
			addMessage("Object with Id [" + taggedObjStr.toString() + "] was tagged successfully.");
		}

		return nextPage;
	}

	public String doCancel() {
		((PortletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest()).getPortletSession().invalidate();

		return "";
	}

	public String getNewExpStatus() {
		return newExpStatus;
	}

	public void setNewExpStatus(String newExpStatus) {
		this.newExpStatus = newExpStatus;
	}

	public RationaleBean getRationaleBean() {
		return rationaleBean;
	}

	public void setRationaleBean(RationaleBean rationaleBean) {
		this.rationaleBean = rationaleBean;
	}

	public List<STWTAGRequest> getInValidObjects() {
		return inValidObjects;
	}

	public void setInValidObjects(List<STWTAGRequest> inValidObjects) {
		this.inValidObjects = inValidObjects;
	}

	public List<STWTAGRequest> getValidObjects() {
		return validObjects;
	}

	public void setValidObjects(List<STWTAGRequest> validObjects) {
		this.validObjects = validObjects;
	}

	public STWTagRequestBean getStwTagRequestBean() {
		return stwTagRequestBean;
	}

	public void setStwTagRequestBean(STWTagRequestBean stwTagRequestBean) {
		this.stwTagRequestBean = stwTagRequestBean;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public String getTextWrappedClassCode(){
		if(classCode == null){
			return  classCode;
		}
		return classCode.replaceAll("~", " ~ ");
	}
	
	public ExportControlDao getExportControlDao() {
		return exportControlDao;
	}

	public void setExportControlDao(ExportControlDao exportControlDao) {
		this.exportControlDao = exportControlDao;
	}

	public ListDataModel getExportControlObjects() throws STWizardException {
		if (getResults().getRowCount() <= 0) {
			addMessage("No export control objects data to tag.");
			throw new STWizardException("No export control objects data to tag.");
		}

		return getResults();
	}
	
	public String getLogoutUrl(){
		return ResourceFactory.getInstance().getAppProperty("LOG_OUT_URL");
	}
	
	public int getValidObjectSize() {
		return validObjects.size();
	}
	
	public int getInValidObjectSize() {
		return inValidObjects.size();
	}
}