/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils.xml;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.geinfra.geaviation.ectstw.data.ExportableObject;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */
public class XMLSAXEventHandler extends DefaultHandler {
	private String tempVal;
	private ExportableObject tempExpObj = null;
	private List<ExportableObject> expObjList = new ArrayList<ExportableObject>();

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equalsIgnoreCase("ObjectName")) {
			tempExpObj.setObjName(tempVal);
		} else if (qName.equalsIgnoreCase("ObjectType")) {
			tempExpObj.setObjType(tempVal);
		} else if (qName.equalsIgnoreCase("classification")) {
			tempExpObj.setClassification(tempVal);
		} else if (qName.equalsIgnoreCase("exportStatus")) {
			tempExpObj.setExportStatus(tempVal);
		} else if (qName.equalsIgnoreCase("rational")) {
			tempExpObj.setRational(tempVal);
		} else if (qName.equalsIgnoreCase("ExportableObject")) {
			//add it to the list
			expObjList.add(tempExpObj);
		}
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		//Data reset
		tempVal = "";
		if (qName.equalsIgnoreCase("ExportableObject")) {
			//create a new instance of ExportableObject
			tempExpObj = new ExportableObject();
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		tempVal = new String(ch, start, length);
	}

	public List<ExportableObject> getExpObjList() {
		return expObjList;
	}

	public void setExpObjList(List<ExportableObject> expObjList) {
		this.expObjList = expObjList;
	}
}
