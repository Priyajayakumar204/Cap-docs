/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.utils;

import org.apache.log4j.Logger;

/**
 * @author Kumar, Amit
 * @version 1.0.0
 */

@SuppressWarnings("unchecked")
public class WizardLogger {
	private WizardLogger(){}
	
	public static void log(Class log, String msg) {
		Logger logger = Logger.getLogger(log);
		logger.debug(msg);
	}
}
