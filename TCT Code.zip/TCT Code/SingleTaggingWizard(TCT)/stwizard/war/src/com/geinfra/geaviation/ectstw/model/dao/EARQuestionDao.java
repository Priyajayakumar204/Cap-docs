/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.util.List;

public class EARQuestionDao extends BaseSTWDao {

	public List<String> getEARReasons() throws Exception {
		String[] values = new String[] { "ALLEAR", "NSR" };
		
		return ExportControlDao.getClassificationCodesByStatus(values);		
	}
	
	public List<String> getECCNCatagoriesSub() throws Exception {
		String[] values = new String[] { "all", "LRC", "NLR" };

		return ExportControlDao.getClassificationCodesByStatus(values); 
	}
}
