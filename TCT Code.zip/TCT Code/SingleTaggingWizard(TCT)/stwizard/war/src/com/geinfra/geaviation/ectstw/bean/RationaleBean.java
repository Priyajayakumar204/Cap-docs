/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.bean;

import com.geinfra.geaviation.ectstw.data.RationaleVO;
import com.geinfra.geaviation.ectstw.service.RationaleService;

public class RationaleBean extends AbstractQuestionBean {
	private RationaleService rationaleService;
	private RationaleVO rationaleVO;
	
	public RationaleService getRationaleService() {
		return rationaleService;
	}
	public void setRationaleService(RationaleService rationaleService) {
		this.rationaleService = rationaleService;
	}
	public RationaleVO getRationaleVO() {
		return rationaleVO;
	}
	public void setRationaleVO(RationaleVO rationaleVO) {
		this.rationaleVO = rationaleVO;
	}
}
