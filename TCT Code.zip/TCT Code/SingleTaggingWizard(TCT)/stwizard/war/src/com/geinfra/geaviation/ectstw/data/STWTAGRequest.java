/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import java.io.Serializable;

import com.geinfra.geaviation.ectstw.utils.TaggingWizardConstants;
import com.geinfra.geaviation.ectstw.utils.TaggingWizardUtil;
import com.geinfra.geaviation.ectstw.utils.WizardLogger;

public class STWTAGRequest implements Serializable {
	private final static long serialVersionUID = 7121612167921361022L;
	
	private String objName;
	private String objType;
	private String objDesc;
	private String classification;
	private String exportStatus;
	private String rational;

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getTextWrappedClassification() {
		if(classification == null){		
			return classification; 
		}
		return classification.replaceAll("~", " ~ "); 
	}

	public String getExportStatus() {
		return exportStatus;
	}

	public void setExportStatus(String exportStatus) {
		this.exportStatus = exportStatus;
	}

	public String getRational() {
		return rational;
	}

	public void setRational(String rational) {
		this.rational = rational;
	}

	@Override
	public String toString() {
		return new StringBuffer().append(objName + ", ").append(objType + ", ").append(classification + ", ").append(exportStatus + ", ").append(rational + ".").toString();
	}

	public String getObjDesc() {
		return objDesc;
	}

	public void setObjDesc(String objDesc) {
		this.objDesc = objDesc;
	}
}
