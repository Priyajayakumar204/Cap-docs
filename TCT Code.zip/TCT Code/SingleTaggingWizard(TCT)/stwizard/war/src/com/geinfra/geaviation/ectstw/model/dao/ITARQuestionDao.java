/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.model.dao;

import java.util.List;

public class ITARQuestionDao extends BaseSTWDao {
	
	public List<String> getITARReasons() throws Exception {
		String[] values = new String[] { "ALLITAR", "NSR" };
		
		return ExportControlDao.getClassificationCodesByStatus(values);		
	}
		
	public List<String> getUSMLCatagory() throws Exception{
		String[] values = new String[] { "all", "LRS" };
		
		return ExportControlDao.getClassificationCodesByStatus(values);
	}
}
