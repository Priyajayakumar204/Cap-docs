/*
 *    Copyright (C) 2009 General Electric Company.
 *    All rights reserved
 */
package com.geinfra.geaviation.ectstw.data;

import java.util.ArrayList;
import java.util.List;

public class ITARQuestionVO extends BaseSTWVO {
	private boolean boolITAREnabled = false;
	private String subjectToITAR = null;

	private String selITARReason = null;
	private boolean selITARReasonEnabled = false;
	
	private boolean selUSMLEnabled = false;
	private String selUSMLType = null;
	
	private List<String> availableUSMLValues = new ArrayList<String>();
	private List<String> selectedUSMLValues = new ArrayList<String>();
		
	public String getSelUSMLType() {
		return selUSMLType;
	}

	public void setSelUSMLType(String selUSMLType) {
		this.selUSMLType = selUSMLType;
	}

	public boolean isBoolITAREnabled() {
		return boolITAREnabled;
	}

	public void setBoolITAREnabled(boolean boolITAREnabled) {
		this.boolITAREnabled = boolITAREnabled;
	}

	public String getSelITARReason() {
		return selITARReason;
	}

	public void setSelITARReason(String selITARReason) {
		this.selITARReason = selITARReason;
	}

	public String getSubjectToITAR() {
		return subjectToITAR;
	}

	public void setSubjectToITAR(String subjectToITAR) {
		this.subjectToITAR = subjectToITAR;
	}

	public boolean isSelITARReasonEnabled() {
		return selITARReasonEnabled;
	}

	public void setSelITARReasonEnabled(boolean selITARReasonEnabled) {
		this.selITARReasonEnabled = selITARReasonEnabled;
	}

	public boolean isSelUSMLEnabled() {
		return selUSMLEnabled;
	}

	public void setSelUSMLEnabled(boolean selUSMLEnabled) {
		this.selUSMLEnabled = selUSMLEnabled;
	}

	public List<String> getAvailableUSMLValues() {
		return availableUSMLValues;
	}

	public void setAvailableUSMLValues(List<String> availableUSMLValues) {
		this.availableUSMLValues = availableUSMLValues;
	}

	public List<String> getSelectedUSMLValues() {
		return selectedUSMLValues;
	}

	public void setSelectedUSMLValues(List<String> selectedUSMLValues) {
		this.selectedUSMLValues = selectedUSMLValues;
	}
}
