This folder should contain pre-built application and configuration files
