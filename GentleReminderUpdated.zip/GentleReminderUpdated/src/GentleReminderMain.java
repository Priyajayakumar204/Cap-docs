import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GentleReminderMain {
	
	public static void main(String[] args) throws Exception {
		
		//SET Total and closed sla breached
		/*int totalInc = 487;
		int closedInc = 48;
		int totalRitm = 523;
		int closedRitm = 19;*/
		
		//INC file
		String incFilePath = "INC.xls";
		FileInputStream incInputStream = new FileInputStream(new File(incFilePath));
		HSSFWorkbook incHwb = new HSSFWorkbook(incInputStream);
		HSSFSheet incSheet = incHwb.getSheetAt(0);
		//int incCount = 0;
		
		//RITM file
		String ritmFilePath = "RITM.xls";
		FileInputStream ritmInputStream = new FileInputStream(new File(ritmFilePath));
		HSSFWorkbook ritmHwb = new HSSFWorkbook(ritmInputStream);
		HSSFSheet ritmSheet = ritmHwb.getSheetAt(0);
		//int ritmCount = 0;
		
		//Breach File
		String breachFile = "breach.xlsx";
		FileInputStream breachFileInputStream = new FileInputStream(new File(breachFile));
		XSSFWorkbook breachFileHwb = new XSSFWorkbook(breachFileInputStream);
		XSSFSheet breachFileSheet = breachFileHwb.getSheetAt(1);
		ArrayList<OpenBreachBean> openBreachList = GentleReminderMethods.readOpenBreach(breachFileSheet);
		//System.out.println(Arrays.toString(openBreachList.toArray()));
		
		FileInputStream breachFileInputStream2 = new FileInputStream(new File(breachFile));
		XSSFWorkbook breachFileHwb2 = new XSSFWorkbook(breachFileInputStream2);
		XSSFSheet breachFileSheet2 = breachFileHwb2.getSheetAt(2);
		ArrayList<OpenNotBreachBean> openNotBreachList = GentleReminderMethods.readOpenNotBreach(breachFileSheet2);
		//System.out.println(Arrays.toString(openNotBreachList.toArray()));
		
		//Working with INC file
		ArrayList<TicketBean> incList = GentleReminderMethods.readFile(incSheet);
		//incCount = GentleReminderMethods.getCount(incList);
		//System.out.println("INC Count: " + incCount);
		ArrayList<TicketBean> incActiveList = GentleReminderMethods.getActiveList(incList);
		ArrayList<TicketBean> incAgingList = GentleReminderMethods.getAgingList(incList);
		
		//Working with RITM file
		ArrayList<TicketBean> ritmList = GentleReminderMethods.readFile(ritmSheet);
		//ritmCount = GentleReminderMethods.getCount(ritmList);
		//System.out.println("RITM count: " + ritmCount);
		ArrayList<TicketBean> ritmActiveList = GentleReminderMethods.getActiveList(ritmList);
		ArrayList<TicketBean> ritmAgingList = GentleReminderMethods.getAgingList(ritmList);
		
		//combine the lists and sort based on planned due date
		ArrayList<TicketBean> activeList = GentleReminderMethods.combineLists(incActiveList, ritmActiveList);
		ArrayList<TicketBean> agingList = GentleReminderMethods.combineLists(incAgingList, ritmAgingList);
		ArrayList<TicketBean> totalList = GentleReminderMethods.combineLists(agingList, activeList);
		
		//System.out.println(Arrays.toString(openBreachList.toArray()));
		
		totalList = GentleReminderMethods.updateTotalList(openBreachList, openNotBreachList, totalList);
		
		//System.out.println(Arrays.toString(totalList.toArray()));
		
		/*System.out.println("-------------------");
		
		for(TicketBean tkt: activeList)
			System.out.println(tkt.getTktNumber() + " " + tkt.getTktPlannedDueDate());
		
		System.out.println("-------------------");
		
		for(TicketBean tkt: agingList)
			System.out.println(tkt.getTktNumber() + " " + tkt.getTktPlannedDueDate());*/
		
		/*if(GentleReminderMethods.sendMail(activeList, agingList, incCount, ritmCount, totalInc, totalRitm, closedInc, closedRitm) == 1)
			System.out.println("Mail sent successfully");
		else
			System.out.println("Mail not sent");*/
		
		/*GentleReminderMethods.writeToExcel(activeList, agingList);*/
		
		GentleReminderMethods.writeToExcelUpdated(totalList);
		GentleReminderMethods.personalReminder(totalList);
		
		incHwb.close();
		ritmHwb.close();
	}
	
}