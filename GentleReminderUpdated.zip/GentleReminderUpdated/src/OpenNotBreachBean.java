
public class OpenNotBreachBean {

	private String openNotBreachNumber;
	private String openNotBreachState;
	private String openNotBreachShortDescription;
	private String openNotBreachAssignedTo;
	private String openNotBreachCongurationItem;
	private String openNotBreachPlannedDueDate;
	private String openNotBreachActualStatus;
	private String openNotBreachAdjHasBreached;
	private String openNotBreachComments;

	public String getOpenNotBreachNumber() {
		return openNotBreachNumber;
	}

	public void setOpenNotBreachNumber(String openNotBreachNumber) {
		this.openNotBreachNumber = openNotBreachNumber;
	}

	public String getOpenNotBreachState() {
		return openNotBreachState;
	}

	public void setOpenNotBreachState(String openNotBreachState) {
		this.openNotBreachState = openNotBreachState;
	}

	public String getOpenNotBreachShortDescription() {
		return openNotBreachShortDescription;
	}

	public void setOpenNotBreachShortDescription(String openNotBreachShortDescription) {
		this.openNotBreachShortDescription = openNotBreachShortDescription;
	}

	public String getOpenNotBreachAssignedTo() {
		return openNotBreachAssignedTo;
	}

	public void setOpenNotBreachAssignedTo(String openNotBreachAssignedTo) {
		this.openNotBreachAssignedTo = openNotBreachAssignedTo;
	}

	public String getOpenNotBreachCongurationItem() {
		return openNotBreachCongurationItem;
	}

	public void setOpenNotBreachCongurationItem(String openNotBreachCongurationItem) {
		this.openNotBreachCongurationItem = openNotBreachCongurationItem;
	}

	public String getOpenNotBreachPlannedDueDate() {
		return openNotBreachPlannedDueDate;
	}

	public void setOpenNotBreachPlannedDueDate(String openNotBreachPlannedDueDate) {
		this.openNotBreachPlannedDueDate = openNotBreachPlannedDueDate;
	}

	public String getOpenNotBreachActualStatus() {
		return openNotBreachActualStatus;
	}

	public void setOpenNotBreachActualStatus(String openNotBreachActualStatus) {
		this.openNotBreachActualStatus = openNotBreachActualStatus;
	}

	public String getOpenNotBreachAdjHasBreached() {
		return openNotBreachAdjHasBreached;
	}

	public void setOpenNotBreachAdjHasBreached(String openNotBreachAdjHasBreached) {
		this.openNotBreachAdjHasBreached = openNotBreachAdjHasBreached;
	}

	public String getOpenNotBreachComments() {
		return openNotBreachComments;
	}

	public void setOpenNotBreachComments(String openNotBreachComments) {
		this.openNotBreachComments = openNotBreachComments;
	}

	@Override
	public String toString() {
		return "OpenNotBreachBean [openNotBreachNumber=" + openNotBreachNumber + ", openNotBreachActualStatus="
				+ openNotBreachActualStatus + ", openNotBreachComments=" + openNotBreachComments + "]\n";
	}


}
