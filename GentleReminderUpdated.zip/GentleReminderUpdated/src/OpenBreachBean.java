
public class OpenBreachBean {

	private String openBreachNumber;
	private String openBreachState;
	private String openBreachShortDescription;
	private String openBreachAssignedTo;
	private String openBreachConfigurationItem;
	private String openBreachPlannedDueDate;
	private String openBreachAdjustedHasBreached;
	private String openBreachReason;

	public String getOpenBreachNumber() {
		return openBreachNumber;
	}

	public void setOpenBreachNumber(String openBreachNumber) {
		this.openBreachNumber = openBreachNumber;
	}

	public String getOpenBreachState() {
		return openBreachState;
	}

	public void setOpenBreachState(String openBreachState) {
		this.openBreachState = openBreachState;
	}

	public String getOpenBreachShortDescription() {
		return openBreachShortDescription;
	}

	public void setOpenBreachShortDescription(String openBreachShortDescription) {
		this.openBreachShortDescription = openBreachShortDescription;
	}

	public String getOpenBreachAssignedTo() {
		return openBreachAssignedTo;
	}

	public void setOpenBreachAssignedTo(String openBreachAssignedTo) {
		this.openBreachAssignedTo = openBreachAssignedTo;
	}

	public String getOpenBreachConfigurationItem() {
		return openBreachConfigurationItem;
	}

	public void setOpenBreachConfigurationItem(String openBreachConfigurationItem) {
		this.openBreachConfigurationItem = openBreachConfigurationItem;
	}

	public String getOpenBreachPlannedDueDate() {
		return openBreachPlannedDueDate;
	}

	public void setOpenBreachPlannedDueDate(String openBreachPlannedDueDate) {
		this.openBreachPlannedDueDate = openBreachPlannedDueDate;
	}

	public String getOpenBreachAdjustedHasBreached() {
		return openBreachAdjustedHasBreached;
	}

	public void setOpenBreachAdjustedHasBreached(String openBreachAdjustedHasBreached) {
		this.openBreachAdjustedHasBreached = openBreachAdjustedHasBreached;
	}

	public String getOpenBreachReason() {
		return openBreachReason;
	}

	public void setOpenBreachReason(String openBreachReason) {
		this.openBreachReason = openBreachReason;
	}

	@Override
	public String toString() {
		return "OpenBreachBean [openBreachNumber=" + openBreachNumber + ", openBreachState=" + openBreachState
				+ ", openBreachReason=" + openBreachReason + "]\n";
	}

}
