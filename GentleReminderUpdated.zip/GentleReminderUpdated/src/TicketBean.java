public class TicketBean {

	String tktNumber;
	String tktShortDesc;
	String tktState;
	String tktPriority;
	String tktPlannedDueDate;
	String tktElapsedTime;
	String tktAssignedTo;
	String tktAssignedGroup;
	String tktEscalated;
	String tktConfigItem;
	String tktHasBreached;
	String tktAdjustedHasbreached;
	String tktActualStatus;

	public String getTktActualStatus() {
		return tktActualStatus;
	}

	public void setTktActualStatus(String tktActualStatus) {
		this.tktActualStatus = tktActualStatus;
	}

	public String getTktComments() {
		return tktComments;
	}

	public void setTktComments(String tktComments) {
		this.tktComments = tktComments;
	}

	String tktComments;

	public String getTktNumber() {
		return tktNumber;
	}

	public void setTktNumber(String tktNumber) {
		this.tktNumber = tktNumber;
	}

	public String getTktShortDesc() {
		return tktShortDesc;
	}

	public void setTktShortDesc(String tktShortDesc) {
		this.tktShortDesc = tktShortDesc;
	}

	public String getTktState() {
		return tktState;
	}

	public void setTktState(String tktState) {
		this.tktState = tktState;
	}

	public String getTktPriority() {
		return tktPriority;
	}

	public void setTktPriority(String tktPriority) {
		this.tktPriority = tktPriority;
	}

	public String getTktPlannedDueDate() {
		return tktPlannedDueDate;
	}

	public void setTktPlannedDueDate(String tktPlannedDueDate) {
		this.tktPlannedDueDate = tktPlannedDueDate;
	}

	public String getTktElapsedTime() {
		return tktElapsedTime;
	}

	public void setTktElapsedTime(String tktElapsedTime) {
		this.tktElapsedTime = tktElapsedTime;
	}

	public String getTktAssignedTo() {
		return tktAssignedTo;
	}

	public void setTktAssignedTo(String tktAssignedTo) {
		this.tktAssignedTo = tktAssignedTo;
	}

	public String getTktAssignedGroup() {
		return tktAssignedGroup;
	}

	public void setTktAssignedGroup(String tktAssignedGroup) {
		this.tktAssignedGroup = tktAssignedGroup;
	}

	public String getTktEscalated() {
		return tktEscalated;
	}

	public void setTktEscalated(String tktEscalated) {
		this.tktEscalated = tktEscalated;
	}

	public String getTktConfigItem() {
		return tktConfigItem;
	}

	public void setTktConfigItem(String tktConfigItem) {
		this.tktConfigItem = tktConfigItem;
	}

	public String getTktHasBreached() {
		return tktHasBreached;
	}

	public void setTktHasBreached(String tktHasBreached) {
		this.tktHasBreached = tktHasBreached;
	}

	public String getTktAdjustedHasbreached() {
		return tktAdjustedHasbreached;
	}

	public void setTktAdjustedHasbreached(String tktAdjustedHasbreached) {
		this.tktAdjustedHasbreached = tktAdjustedHasbreached;
	}

	@Override
	public String toString() {
		return "TicketBean [tktNumber=" + tktNumber + ", tktActualStatus=" + tktActualStatus + ", tktComments="
				+ tktComments + "]\n";
	}

	

}
