import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataConsolidateFunction;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFPivotTable;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GentleReminderMethods {

	// include offshore team member details
	public static String[] offshoreTeam = { "VELAYUTHAM, GIRIJA (502692452)", "JAYAPRAKASH, VISHNU (502714669)",
			"TUMMALA, RAVI (502658343)", "ANTO, JACOB (502674746)", "GANAPATHY, RAKESH (502706346)",
			"HIMACHALAPATHY, SUSHMITHA (502661444)", "GOPINADHAN, SOWMIA (502563312)", "KUMAR, SURUCHI (502774876)", "JAYAKUMAR, PRIYADHARSHINI (502774877)" };
	public static String[] onsiteTeam = { "KHAN, ANZER (502705836)",
			"RAZA, SYED (502705300)", "AHLQUIST, PAUL (501397787)", "EDELENBOS, CHRISTOPHER (502203749)",
			"RICHARDS, ROBERT (502253792)", "BROWN, PERCY (501361440)", "MILLER, LEO (501281403)",
			"FULLEN, DOUG (502652482)", "MOORES, ROBERT (502335475)", "SIDDIK, ABUBAKKAR (502051926)",
			"PARAMASIVAM, SELVARAJU (501969065)", "WRIGHT, EDWARD (501998236)", "SLISH, MARK (502532855)" };
	public static HashMap<String, String> onsiteEmail = new HashMap<String, String>();

	// get present date and set time to midnight, ie, 00:00:00
	public static LocalTime LtMidnight = LocalTime.MIDNIGHT;
	public static LocalDate LdToday = LocalDate.now(ZoneId.of("Asia/Kolkata")); // because system date will be in IST
	public static LocalDateTime LdtTodayDate = LocalDateTime.of(LdToday, LtMidnight);
	public static Date todayDate = Date.from(LdtTodayDate.atZone(ZoneId.systemDefault()).toInstant());

	// method for reading the excel file
	public static ArrayList<TicketBean> readFile(HSSFSheet sheet) throws Exception {

		Iterator<?> rowItr = sheet.rowIterator();
		ArrayList<TicketBean> ticketList = new ArrayList<TicketBean>();

		while (rowItr.hasNext()) {
			HSSFRow row = (HSSFRow) rowItr.next();

			Iterator<?> cellItr = row.cellIterator();

			TicketBean tkt = new TicketBean();

			if (row.getRowNum() == 0) // skip the first row, contains headings
				continue;

			while (cellItr.hasNext()) {
				HSSFCell cell = (HSSFCell) cellItr.next();

				if (cell.getColumnIndex() == 4) {
					DataFormatter dataFormatter = new DataFormatter();
					String dateStr = dataFormatter.formatCellValue(row.getCell(4));
					tkt.setTktPlannedDueDate(dateStr);
				}

				cell.setCellType(CellType.STRING); // set cell type to string to
													// store data in variables

				if (cell.getColumnIndex() == 0)
					tkt.setTktNumber(cell.getStringCellValue());

				if (cell.getColumnIndex() == 1)
					tkt.setTktShortDesc(cell.getStringCellValue());

				if (cell.getColumnIndex() == 2)
					tkt.setTktState(cell.getStringCellValue());

				if (cell.getColumnIndex() == 3)
					tkt.setTktPriority(cell.getStringCellValue());

				if (cell.getColumnIndex() == 5)
					tkt.setTktElapsedTime(cell.getStringCellValue());

				if (cell.getColumnIndex() == 6)
					tkt.setTktAssignedTo(cell.getStringCellValue());

				if (cell.getColumnIndex() == 7)
					tkt.setTktAssignedGroup(cell.getStringCellValue());

				if (cell.getColumnIndex() == 8)
					tkt.setTktEscalated(cell.getStringCellValue());

				if (cell.getColumnIndex() == 9)
					tkt.setTktConfigItem(cell.getStringCellValue());

				if (cell.getColumnIndex() == 10)
					tkt.setTktHasBreached(cell.getStringCellValue());

				if (cell.getColumnIndex() == 11)
					tkt.setTktAdjustedHasbreached(cell.getStringCellValue());

			}
			ticketList.add(tkt);
		}

		return ticketList;
	}

	public static ArrayList<OpenBreachBean> readOpenBreach(XSSFSheet sheet) {

		Iterator<?> rowItr = sheet.rowIterator();
		ArrayList<OpenBreachBean> openBreachList = new ArrayList<OpenBreachBean>();

		while (rowItr.hasNext()) {
			XSSFRow row = (XSSFRow) rowItr.next();

			Iterator<?> cellItr = row.cellIterator();

			OpenBreachBean openBreachObj = new OpenBreachBean();

			if (row.getRowNum() == 0) // skip the first row, contains headings
				continue;

			while (cellItr.hasNext()) {
				XSSFCell cell = (XSSFCell) cellItr.next();

				cell.setCellType(CellType.STRING);

				if (cell.getColumnIndex() == 0)
					openBreachObj.setOpenBreachNumber(cell.getStringCellValue());

				if (cell.getColumnIndex() == 1)
					openBreachObj.setOpenBreachState(cell.getStringCellValue());

				if (cell.getColumnIndex() == 2)
					openBreachObj.setOpenBreachShortDescription(cell.getStringCellValue());

				if (cell.getColumnIndex() == 3)
					openBreachObj.setOpenBreachAssignedTo(cell.getStringCellValue());

				if (cell.getColumnIndex() == 4)
					openBreachObj.setOpenBreachConfigurationItem(cell.getStringCellValue());

				if (cell.getColumnIndex() == 5)
					openBreachObj.setOpenBreachPlannedDueDate(cell.getStringCellValue());

				if (cell.getColumnIndex() == 6)
					openBreachObj.setOpenBreachAdjustedHasBreached(cell.getStringCellValue());

				if (cell.getColumnIndex() == 7)
					openBreachObj.setOpenBreachReason(cell.getStringCellValue());

			}
			openBreachList.add(openBreachObj);
		}

		return openBreachList;

	}

	public static ArrayList<OpenNotBreachBean> readOpenNotBreach(XSSFSheet sheet) {

		Iterator<?> rowItr = sheet.rowIterator();
		ArrayList<OpenNotBreachBean> openNotBreachList = new ArrayList<OpenNotBreachBean>();

		while (rowItr.hasNext()) {
			XSSFRow row = (XSSFRow) rowItr.next();

			Iterator<?> cellItr = row.cellIterator();

			OpenNotBreachBean openNotBreachObj = new OpenNotBreachBean();

			if (row.getRowNum() == 0) // skip the first row, contains headings
				continue;

			while (cellItr.hasNext()) {
				XSSFCell cell = (XSSFCell) cellItr.next();

				cell.setCellType(CellType.STRING);

				if (cell.getColumnIndex() == 0)
					openNotBreachObj.setOpenNotBreachNumber(cell.getStringCellValue());

				if (cell.getColumnIndex() == 1)
					openNotBreachObj.setOpenNotBreachState(cell.getStringCellValue());

				if (cell.getColumnIndex() == 2)
					openNotBreachObj.setOpenNotBreachShortDescription(cell.getStringCellValue());

				if (cell.getColumnIndex() == 3)
					openNotBreachObj.setOpenNotBreachAssignedTo(cell.getStringCellValue());

				if (cell.getColumnIndex() == 4)
					openNotBreachObj.setOpenNotBreachCongurationItem(cell.getStringCellValue());

				if (cell.getColumnIndex() == 5)
					openNotBreachObj.setOpenNotBreachPlannedDueDate(cell.getStringCellValue());

				if (cell.getColumnIndex() == 7)
					openNotBreachObj.setOpenNotBreachActualStatus(cell.getStringCellValue());

				if (cell.getColumnIndex() == 6)
					openNotBreachObj.setOpenNotBreachAdjHasBreached(cell.getStringCellValue());

				if (cell.getColumnIndex() == 8)
					openNotBreachObj.setOpenNotBreachComments(cell.getStringCellValue());

			}
			openNotBreachList.add(openNotBreachObj);
		}

		return openNotBreachList;

	}

	// method for calculating "Open - SLA Breached(Aging)"
	public static int getCount(ArrayList<TicketBean> ticketList) {
		int count = 0;

		for (TicketBean tkt : ticketList) {
			if (tkt.getTktHasBreached().equals("TRUE") && !tkt.tktState.equals("Resolved Monitoring"))
				count++;
		}

		return count;
	}

	public static ArrayList<TicketBean> updateTotalList(ArrayList<OpenBreachBean> openBreachList,
			ArrayList<OpenNotBreachBean> openNotBreachList, ArrayList<TicketBean> totalList) {

		for (TicketBean tkt : totalList) {
			for (OpenBreachBean openObj : openBreachList) {
				if (tkt.getTktNumber().equals(openObj.getOpenBreachNumber())) {
					tkt.setTktActualStatus(openObj.getOpenBreachState());
					tkt.setTktComments(openObj.getOpenBreachReason());
				} /*else {
					tkt.setTktActualStatus("No Info");
					tkt.setTktComments("No Info");
				}*/
			}
		}

		for (TicketBean tkt : totalList) {
			for (OpenNotBreachBean openNotObj : openNotBreachList) {
				if (tkt.getTktNumber().equals(openNotObj.getOpenNotBreachNumber())) {
					tkt.setTktActualStatus(openNotObj.getOpenNotBreachActualStatus());
					tkt.setTktComments(openNotObj.getOpenNotBreachComments());
				} /*else {
					tkt.setTktActualStatus("No Info");
					tkt.setTktComments("No Info");
				}*/
			}
		}
		
		for (TicketBean tkt : totalList) {
			
			if(tkt.getTktActualStatus() == null)
				tkt.setTktActualStatus("Active");
			
			else if(tkt.getTktActualStatus().equals("Work In Progress"))
				tkt.setTktActualStatus("Active");
			
			if(tkt.getTktComments() == null)
				tkt.setTktComments("No Comments");
			
		}
		
		return totalList;

	}

	// method for getting active tickets
	public static ArrayList<TicketBean> getActiveList(ArrayList<TicketBean> ticketList) throws Exception {

		ArrayList<TicketBean> activeList = new ArrayList<TicketBean>();

		for (TicketBean tkt : ticketList) {
			if (!tkt.tktState.equals("Resolved Monitoring")
					&& !Arrays.asList(offshoreTeam).contains(tkt.getTktAssignedTo())) {
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
				Date tktDate = format.parse(tkt.getTktPlannedDueDate());
				if (tktDate.after(todayDate) || tktDate.equals(todayDate))
					activeList.add(tkt);
			}
		}

		return activeList;
	}

	// method for getting aging tickets
	public static ArrayList<TicketBean> getAgingList(ArrayList<TicketBean> ticketList) throws Exception {

		ArrayList<TicketBean> agingList = new ArrayList<TicketBean>();

		for (TicketBean tkt : ticketList) {
			if (!tkt.tktState.equals("Resolved Monitoring")
					&& !Arrays.asList(offshoreTeam).contains(tkt.getTktAssignedTo())) {
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
				Date tktDate = format.parse(tkt.getTktPlannedDueDate());
				if (tktDate.before(todayDate))
					agingList.add(tkt);
			}
		}

		return agingList;
	}

	// method to combine INC and RITM and sort "planned due date" based on
	// "oldest to newest"
	public static ArrayList<TicketBean> combineLists(ArrayList<TicketBean> incList, ArrayList<TicketBean> ritmList) {

		ArrayList<TicketBean> finalList = new ArrayList<TicketBean>();
		finalList.addAll(incList);
		finalList.addAll(ritmList);

		finalList.sort(Comparator.comparing(TicketBean::getTktPlannedDueDate));

		return finalList;
	}

	// method to send mail
	public static int sendMail(ArrayList<TicketBean> activeList, ArrayList<TicketBean> agingList, int openInc,
			int openRitm, int totalInc, int totalRitm, int closedInc, int closedRitm) {

		String host = "ae.ge.com";
		final String user = "";// change accordingly
		final String password = "";// change accordingly

		String to = "vishnu.jayaprakash@ge.com";// change accordingly
		// String multipleTo = "Christopher.Edelenbos@ge.com,
		// RobertL.Moores@ge.com, Doug.Fullen@ge.com, MARK.SLISH@ge.com,
		// Selvaraju.Paramasivam@ge.com, Abubakkar.Siddik@ge.com,
		// Robert1.Richards@ge.com, Edward1.Wright@ge.com, percy.brown@ge.com,
		// paul.ahlquist@ge.com, leo.miller@ge.com, Leopoldo.J.Gonzalez@ge.com,
		// SyedYASIM.Raza@ge.com, Anzer1.Khan@ge.com";
		// String multipleCc = "harish.ramakrishnan@capgemini.com,
		// Babu.Palani@ge.com, CAPG-DO-Offshore@ge.com";

		StringBuilder mailSb = new StringBuilder();
		mailSb.append("<html>");
		mailSb.append(
				"Hi All,<br><br>Kindly treat this email as gentle reminder for below listed nearing SLA and SLA missed tickets closure request.<br><br><u>DES Percentage:</u><br><br>");

		// First table
		mailSb.append("<table border=\"1\" cellpadding=\"5\" style=\"border-collapse:collapse; font-size:13px\">");
		mailSb.append(
				"<tr><th>Category</th><th>Total Tickets</th><th>Closed SLA Breached</th><th>Open SLA Breached Aging</th></tr>");
		mailSb.append("<tr align=\"center\"><td>INC</td><td>" + totalInc + "</td><td>" + closedInc + "</td><td>"
				+ openInc + "</td></tr>");
		mailSb.append("<tr align=\"center\"><td>RITM</td><td>" + totalRitm + "</td><td>" + closedRitm + "</td><td>"
				+ openRitm + "</td></tr>");
		mailSb.append("</table>");

		// Second table
		mailSb.append("<br><br>1. <u> Contains Active & In Progress Tickets as of Today:</u><br><br>");
		mailSb.append("<table border=\"1\" cellpadding=\"5\" style=\"border-collapse:collapse; font-size:13px\" >");
		mailSb.append(
				"<tr><th>Number</th><th>State</th><th>Configuration Item</th><th>Assigned To</th><th>Planned Due Date</th></tr>");
		for (TicketBean tkt : activeList) {
			mailSb.append("<tr align=\"center\"><td>" + tkt.getTktNumber() + "</td><td>" + tkt.getTktState()
					+ "</td><td>" + tkt.getTktConfigItem() + "</td><td>" + tkt.getTktAssignedTo() + "</td><td>"
					+ tkt.getTktPlannedDueDate() + "</td></tr>");
		}
		mailSb.append("</table>");

		// Third table
		mailSb.append("<br><br>2. <u> Aging Tickets:</u><br><br>");
		mailSb.append("<table border=\"1\" cellpadding=\"5\" style=\"border-collapse:collapse; font-size:13px\" >");
		mailSb.append(
				"<tr><th>Number</th><th>State</th><th>Configuration Item</th><th>Assigned To</th><th>Planned Due Date</th></tr>");
		for (TicketBean tkt : agingList) {
			mailSb.append("<tr align=\"center\"><td>" + tkt.getTktNumber() + "</td><td>" + tkt.getTktState()
					+ "</td><td>" + tkt.getTktConfigItem() + "</td><td>" + tkt.getTktAssignedTo() + "</td><td>"
					+ tkt.getTktPlannedDueDate() + "</td></tr>");
		}
		mailSb.append("</table>");

		mailSb.append("<br><br>Thank you,<br>Vishnu");
		mailSb.append("</html>");

		// Get the session object
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.auth", "true");

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);
			}
		});

		try {

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(user));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			// message.addRecipients(Message.RecipientType.TO,
			// InternetAddress.parse(multipleTo));
			// message.addRecipient(Message.RecipientType.CC, new
			// InternetAddress("girija.velayutham@ge.com"));
			// message.addRecipients(Message.RecipientType.CC,
			// InternetAddress.parse(multipleCc));

			// Set Subject: header field
			message.setSubject("Nearing and SLA missed tickets closure request - DES");

			// Now set the actual message
			message.setContent(mailSb.toString(), "text/html");

			// Send message
			Transport.send(message);

			return 1;

		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return 0;
	}

	public static void personalReminder(ArrayList<TicketBean> totalList) throws Exception {

		// System.out.println(totalList);

		ArrayList<TicketBean> tempList = new ArrayList<TicketBean>();
		int i = 0;

		while (i < onsiteTeam.length) {
			for (TicketBean tkt : totalList) {
				if (tkt.getTktAssignedTo().equals(onsiteTeam[i])) {
					tempList.add(tkt);
				}
			}
			if (!tempList.isEmpty()) {
				sendPersonalMail(tempList, onsiteTeam[i]);
				tempList = new ArrayList<TicketBean>();
			}
			i++;
		}
	}

	public static int sendPersonalMail(ArrayList<TicketBean> tempList, String userName) throws Exception {

		// adding Onsite Team's emails
		onsiteEmail.put("KHAN, ANZER (502705836)", "Anzer1.Khan@ge.com");
		onsiteEmail.put("RAZA, SYED (502705300)", "SyedYASIM.Raza@ge.com");
		onsiteEmail.put("AHLQUIST, PAUL (501397787)", "paul.ahlquist@ge.com");
		onsiteEmail.put("EDELENBOS, CHRISTOPHER (502203749)", "Christopher.Edelenbos@ge.com");
		onsiteEmail.put("RICHARDS, ROBERT (502253792)", "Robert1.Richards@ge.com");
		onsiteEmail.put("BROWN, PERCY (501361440)", "percy.brown@ge.com");
		onsiteEmail.put("MILLER, LEO (501281403)", "leo.miller@ge.com");
		onsiteEmail.put("FULLEN, DOUG (502652482)", "Doug.Fullen@ge.com");
		onsiteEmail.put("MOORES, ROBERT (502335475)", "RobertL.Moores@ge.com");
		onsiteEmail.put("SIDDIK, ABUBAKKAR (502051926)", "Abubakkar.Siddik@ge.com");
		onsiteEmail.put("PARAMASIVAM, SELVARAJU (501969065)", "Selvaraju.Paramasivam@ge.com");
		onsiteEmail.put("WRIGHT, EDWARD (501998236)", "Edward1.Wright@ge.com");
		onsiteEmail.put("SLISH, MARK (502532855)", "MARK.SLISH@ge.com");

		System.out.println(userName + ":");
		int breachAlert = 0;

		// sending mail
		String host = "ae.ge.com";
		final String user = "";// change accordingly
		final String password = "";// change accordingly

		String to = onsiteEmail.get(userName);
		String multipleCc = "Sowmia.Gopinadhan@ge.com, Babu.Palani@ge.com, Selvaraju.Paramasivam@ge.com, Abubakkar.Siddik@ge.com, Anzer1.Khan@ge.com, SyedYASIM.Raza@ge.com";

		StringBuilder mailSb = new StringBuilder();
		mailSb.append("<html>");
		mailSb.append(
				"Hi,<br><br>Please take care of below tickets in your queue.<br>Kindly let me know if there are any concerns. Thanks<br><br>");

		// table
		mailSb.append("<table border=\"1\" cellpadding=\"5\" style=\"border-collapse:collapse; font-size:13px\" >");
		mailSb.append(
				"<tr><th>Number</th><th>State</th><th>Configuration Item</th><th>Assigned To</th><th>Planned Due Date</th><th>Actual Status</th><th>Comments</th></tr>");
		for (TicketBean tkt : tempList) {
			mailSb.append("<tr align=\"center\"><td>" + tkt.getTktNumber() + "</td><td>" + tkt.getTktState()
					+ "</td><td>" + tkt.getTktConfigItem() + "</td><td>" + tkt.getTktAssignedTo() + "</td><td>"
					+ tkt.getTktPlannedDueDate() + "</td><td>" + tkt.getTktActualStatus() + "</td><td>" + tkt.getTktComments() + "</td></tr>");
		}
		mailSb.append("</table>");

		mailSb.append("<br><br>Thank you,<br>Vishnu");
		mailSb.append("</html>");

		// Get the session object
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.auth", "true");

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);
			}
		});

		try {

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(user));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(multipleCc));
			message.addRecipient(Message.RecipientType.BCC, new InternetAddress("vishnu.jayaprakash@ge.com"));

			// Set Subject: header field
			for (TicketBean tkt : tempList) {
				if (tkt.getTktState().equals("Active")) {
					DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
					Date tktDate = format.parse(tkt.getTktPlannedDueDate());
					Date tomorrow = new Date(todayDate.getTime() + (1000 * 60 * 60 * 24));
					if (tktDate.equals(todayDate) || tktDate.equals(tomorrow))
						breachAlert++;
				}
			}

			if (breachAlert > 0)
				message.setSubject("BREACH ALERT [ for today and tomorrow tickets] - " + userName);
			else
				message.setSubject("Gentle Reminder " + userName + " - Your tickets - " + tempList.size());

			// Now set the actual message
			message.setContent(mailSb.toString(), "text/html");

			// Send message
			Transport.send(message);

			return 1;

		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return 0;
	}

	public static void writeToExcel(ArrayList<TicketBean> activeList, ArrayList<TicketBean> agingList)
			throws IOException {

		// creating sheet
		HSSFWorkbook hwb = new HSSFWorkbook();
		HSSFSheet sheet = hwb.createSheet();
		HSSFRow row = sheet.createRow((short) 0);

		// setting styles for the report
		HSSFCellStyle style = hwb.createCellStyle();
		HSSFFont font = hwb.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short) 10);
		font.setBold(true);
		style.setFont(font);

		// table headings
		row.createCell((short) 0).setCellValue("Number");
		row.createCell((short) 1).setCellValue("State");
		row.createCell((short) 2).setCellValue("Short Description");
		row.createCell((short) 3).setCellValue("Assigned to");
		row.createCell((short) 4).setCellValue("Conguration item");
		row.createCell((short) 5).setCellValue("Planned Due Date");
		row.createCell((short) 6).setCellValue("Adj");

		short i = 1;
		for (TicketBean tkt : activeList) {
			// row.getCell(j).setCellStyle(style);
			HSSFRow row1 = sheet.createRow((short) i);
			row1.createCell((short) 0).setCellValue(tkt.getTktNumber());
			row1.createCell((short) 1).setCellValue(tkt.getTktState());
			row1.createCell((short) 2).setCellValue(tkt.getTktShortDesc());
			row1.createCell((short) 3).setCellValue(tkt.getTktAssignedTo());
			row1.createCell((short) 4).setCellValue(tkt.getTktConfigItem());
			row1.createCell((short) 5).setCellValue(tkt.getTktPlannedDueDate());
			row1.createCell((short) 6).setCellValue(tkt.getTktAdjustedHasbreached());
			i++;
		}

		for (TicketBean tkt : agingList) {
			HSSFRow row1 = sheet.createRow((short) i);
			row1.createCell((short) 0).setCellValue(tkt.getTktNumber());
			row1.createCell((short) 1).setCellValue(tkt.getTktState());
			row1.createCell((short) 2).setCellValue(tkt.getTktShortDesc());
			row1.createCell((short) 3).setCellValue(tkt.getTktAssignedTo());
			row1.createCell((short) 4).setCellValue(tkt.getTktConfigItem());
			row1.createCell((short) 5).setCellValue(tkt.getTktPlannedDueDate());
			row1.createCell((short) 6).setCellValue(tkt.getTktAdjustedHasbreached());
			i++;
		}

		FileOutputStream fileOut = new FileOutputStream("finalReport.xls");
		hwb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		hwb.close();

	}

	public static void writeToExcelUpdated(ArrayList<TicketBean> totalList) throws Exception {
		
		System.out.println("writing to excel");
		
		// creating sheet
		HSSFWorkbook hwb = new HSSFWorkbook();
		HSSFSheet sheet = hwb.createSheet();
		HSSFRow row = sheet.createRow((short)0);
				
		//setting styles for the report
		HSSFCellStyle style = hwb.createCellStyle();
		HSSFFont font = hwb.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setFontHeightInPoints((short)10);
		font.setBold(true);
		style.setFont(font);
				
		//table headings
		row.createCell((short) 0).setCellValue("Number");
		row.createCell((short) 1).setCellValue("State");
		row.createCell((short) 2).setCellValue("Short Description");
		row.createCell((short) 3).setCellValue("Assigned to");
		row.createCell((short) 4).setCellValue("Conguration item");
		row.createCell((short) 5).setCellValue("Planned Due Date");
		row.createCell((short) 6).setCellValue("Adj");
		row.createCell((short) 7).setCellValue("Actual Status");
		row.createCell((short) 8).setCellValue("Comments");
		
		short i = 1;
		for (TicketBean tkt : totalList) {
			// row.getCell(j).setCellStyle(style);
			HSSFRow row1 = sheet.createRow((short) i);
			row1.createCell((short) 0).setCellValue(tkt.getTktNumber());
			row1.createCell((short) 1).setCellValue(tkt.getTktState());
			row1.createCell((short) 2).setCellValue(tkt.getTktShortDesc());
			row1.createCell((short) 3).setCellValue(tkt.getTktAssignedTo());
			row1.createCell((short) 4).setCellValue(tkt.getTktConfigItem());
			row1.createCell((short) 5).setCellValue(tkt.getTktPlannedDueDate());
			row1.createCell((short) 6).setCellValue(tkt.getTktAdjustedHasbreached());
			row1.createCell((short) 7).setCellValue(tkt.getTktActualStatus());
			row1.createCell((short) 8).setCellValue(tkt.getTktComments());
			i++;
		}
		
		FileOutputStream fileOut = new FileOutputStream("finalReportUpdated.xls");
		hwb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		hwb.close();
		
	}

}
